# nov-es-framework-core
This repository contains building blocks for DDD and Microservice based architecture in .NET 6
