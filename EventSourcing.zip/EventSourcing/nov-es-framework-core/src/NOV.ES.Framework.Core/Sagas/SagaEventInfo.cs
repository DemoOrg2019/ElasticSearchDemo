﻿namespace NOV.ES.Framework.Core.Sagas
{
    public class SagaEventInfo
    {
        public Type SuccessEvent { get; }
        public Type CompensationEvent { get; }

        public SagaEventInfo(Type successEvent, Type compensationEvent)
        {
            SuccessEvent = successEvent;
            CompensationEvent = compensationEvent;
        }
    }
}
