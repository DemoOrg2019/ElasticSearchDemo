﻿using Microsoft.Extensions.Logging;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas.Attributes;
using NOV.ES.Framework.Core.Sagas.Store;
using System.Reflection;

namespace NOV.ES.Framework.Core.Sagas
{
    public abstract class SagaOrchestratorBase
    {
        protected readonly ILogger<SagaOrchestratorBase> logger;
        protected readonly IIntegrationEventBus integrationEventBus;
        protected readonly ISagaStore store;
        protected readonly Dictionary<string, SagaEventInfo> handlers;

        public SagaOrchestratorBase(ILogger<SagaOrchestratorBase> logger, IIntegrationEventBus integrationEventBus, ISagaStore sagaStore)
        {
            this.logger = logger;
            this.integrationEventBus = integrationEventBus;
            store = sagaStore;
            handlers = new Dictionary<string, SagaEventInfo>();
        }

        public void SubscribeSagaEvents(Type TE, Type TS, Type TC)
        {
            handlers.Add(TE.Name, new SagaEventInfo(TS, TC));
            SubscribeToEventBus(TE);
        }

        public void SubscribeSagaEvents<TE, TS, TC>()
            where TE : SagaEvent
            where TS : SagaEvent
            where TC : SagaEvent
        {
            handlers.Add(typeof(TE).Name, new SagaEventInfo(typeof(TS), typeof(TC)));
            SubscribeToEventBus(typeof(TE));
        }

        protected virtual void ProcessSagaEvent(string eventName, SagaEvent @event, Type eventDataType)
        {
            SagaEventInfo eventInfo = handlers[eventName];
            bool sagaStartEvent = IsSagaStartEvent(@event);
            bool sagaEndEvent = IsSagaEndEvent(@event);

            Guid corelationId = sagaStartEvent ? Guid.NewGuid() : @event.CorelationId;

            logger.LogInformation($"Processing Saga Event Detail : {@event.GetType().Name} with Id {corelationId}");

            // Store Received Saga Event Details
            if (store != null)
            {
                logger.LogInformation($"Saving Received Event details in Saga Store.");
                store.SaveSagaEvent(new SagaEventEntity(@event, sagaStartEvent ? SagaRunningStatus.New : SagaRunningStatus.Running));
                logger.LogInformation($"Saved Received Event details in Saga Store.");
            }

            if (@event.SagaEventExecutionResult == SagaEventExecutionResult.Success)
            {
                logger.LogInformation($"Publishing a Success Event {eventInfo.SuccessEvent.Name}");

                var @publishSuccessEvent = (SagaEvent)Activator.CreateInstance(eventInfo.SuccessEvent,
                   corelationId,
                    @event.JsonStringData);

                integrationEventBus.Publish(@publishSuccessEvent);

                logger.LogInformation($"Published a Success Event {eventInfo.SuccessEvent.Name}");

                if (store != null)
                {
                    logger.LogInformation($"Saving Ppublished Success Event details in Saga Store.");
                    store.SaveSagaEvent(new SagaEventEntity(@publishSuccessEvent, sagaEndEvent ? SagaRunningStatus.Running : SagaRunningStatus.CompletedWithSuccess));
                    logger.LogInformation($"Saved Published Success Event details in Saga Store.");
                }
            }
            else
            {
                if (eventInfo.CompensationEvent != null)
                {
                    var @publishedCompansetingEvent = (SagaEvent)Activator.CreateInstance(eventInfo.CompensationEvent,
                        corelationId,
                        @event.JsonStringData);

                    logger.LogInformation($"----- Publishing a Failure Event {eventInfo.CompensationEvent.Name}");
                    integrationEventBus.Publish(@publishedCompansetingEvent);
                    logger.LogInformation($"----- Published a Failure Event {eventInfo.CompensationEvent.Name}");

                    if (store != null)
                    {
                        logger.LogInformation($"Saving Ppublished Companseting Event details in Saga Store.");
                        store.SaveSagaEvent(new SagaEventEntity(@publishedCompansetingEvent, sagaEndEvent ? SagaRunningStatus.Running : SagaRunningStatus.CompletedWithSuccess));
                        logger.LogInformation($"Saved Published Companseting Event details in Saga Store.");
                    }
                }
            }
        }

        protected void SubscribeToEventBus(Type sagaEventType)
        {
            MethodInfo method = typeof(IIntegrationEventBus).GetMethod("Subscribe");
            MethodInfo eventBusSubscriptionMethod = method.MakeGenericMethod(sagaEventType, this.GetType());
            eventBusSubscriptionMethod.Invoke(this.integrationEventBus, null);
        }

        private bool IsSagaStartEvent(SagaEvent @event)
        {
            return @event.GetType().GetCustomAttributes(typeof(SagaStartAttribute), false).Length > 0;
        }

        private bool IsSagaEndEvent(SagaEvent @event)
        {
            return @event.GetType().GetCustomAttributes(typeof(SagaEndAttribute), false).Length > 0;
        }
    }
}
