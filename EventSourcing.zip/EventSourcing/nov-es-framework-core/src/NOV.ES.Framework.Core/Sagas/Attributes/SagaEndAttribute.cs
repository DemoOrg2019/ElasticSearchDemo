﻿namespace NOV.ES.Framework.Core.Sagas.Attributes
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    public class SagaEndAttribute : Attribute
    {
    }
}
