﻿using NOV.ES.Framework.Core.Messaging.IntegrationEvents;

namespace NOV.ES.Framework.Core.Sagas
{
    public enum SagaEventExecutionResult
    {
        Failure = 0,
        Success
    }

    public class SagaEvent : IntegrationEvent
    {
        public Guid CorelationId { get; set; }

        public string JsonStringData { get; set; }

        public SagaEventExecutionResult SagaEventExecutionResult { get; set; }
    }


}
