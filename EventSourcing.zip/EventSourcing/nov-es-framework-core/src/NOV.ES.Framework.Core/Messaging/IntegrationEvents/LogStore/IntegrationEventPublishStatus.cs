﻿namespace NOV.ES.Framework.Core.Messaging.IntegrationEvents.LogStore
{
    public enum IntegrationEventPublishStatus
    {
        NotPublished = 0,
        InProgress = 1,
        Published = 2,
        PublishedFailed = 3
    }
}

