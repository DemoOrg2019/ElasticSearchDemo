﻿using System.Reflection;

namespace NOV.ES.Framework.Core.Messaging.IntegrationEvents.LogStore
{
    public class MemoryIntegrationEventLogService : IIntegrationEventLogService
    {
        private readonly List<IntegrationEventLogEntry> integrationEventLogs = new List<IntegrationEventLogEntry>();
        private readonly List<Type> eventTypes;

        public MemoryIntegrationEventLogService()
        {
            eventTypes = Assembly.Load(Assembly.GetEntryAssembly().FullName)
                .GetTypes()
                .Where(t => t.Name.EndsWith(nameof(IntegrationEvent)))
                .ToList();
        }
        public Task<IEnumerable<IntegrationEventLogEntry>> RetrieveEventLogsPendingToPublishAsync(Guid transactionId)
        {
            var tid = transactionId.ToString();

            var result = integrationEventLogs
                .Where(e => e.TransactionId == tid && e.State == IntegrationEventPublishStatus.NotPublished)
                .OrderBy(o => o.CreationTime)
                .Select(e => e.DeserializeJsonContent(eventTypes.Find(t => t.Name == e.EventTypeShortName)))
                .ToList();

            return Task.FromResult<IEnumerable<IntegrationEventLogEntry>>(result);
        }

        public Task SaveEventAsync(IntegrationEvent @event, Guid transactionId)
        {
            var eventLogEntry = new IntegrationEventLogEntry(@event, transactionId);


            integrationEventLogs.Add(eventLogEntry);

            return Task.CompletedTask;
        }

        public Task MarkEventAsFailedAsync(Guid eventId)
        {
            return UpdateEventStatus(eventId, IntegrationEventPublishStatus.PublishedFailed);
        }

        public Task MarkEventAsInProgressAsync(Guid eventId)
        {
            return UpdateEventStatus(eventId, IntegrationEventPublishStatus.InProgress);
        }

        public Task MarkEventAsPublishedAsync(Guid eventId)
        {
            return UpdateEventStatus(eventId, IntegrationEventPublishStatus.PublishedFailed);
        }

        private Task UpdateEventStatus(Guid eventId, IntegrationEventPublishStatus status)
        {
            var eventLogEntry = integrationEventLogs.Single(ie => ie.EventId == eventId);
            eventLogEntry.State = status;

            if (status == IntegrationEventPublishStatus.InProgress)
                eventLogEntry.TimesSent++;

            // _integrationEventLogs.up

            return Task.CompletedTask;
        }

    }
}
