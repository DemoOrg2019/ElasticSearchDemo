﻿namespace NOV.ES.Framework.Core.Messaging.IntegrationEvents
{
    public interface IDynamicIntegrationEventHandler
    {
        Task Handle(dynamic eventData);
    }
}
