﻿using MediatR;

namespace NOV.ES.Framework.Core.CQRS.Events
{
    public interface IEvent : INotification
    {
    }
}
