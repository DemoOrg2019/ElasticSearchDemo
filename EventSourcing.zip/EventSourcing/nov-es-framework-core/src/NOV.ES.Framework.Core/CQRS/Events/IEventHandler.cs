﻿using MediatR;

namespace NOV.ES.Framework.Core.CQRS.Events
{
    public interface IEventHandler<in TEvent> : INotificationHandler<TEvent>
           where TEvent : IEvent
    {
    }
}
