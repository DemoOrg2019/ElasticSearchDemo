﻿using System.Reflection;

namespace NOV.ES.Framework.Core.ScheduledJobs
{
    public class ScheduledJobDefinition
    {
        public int Version { get; }
        public Type Type { get; }
        public string Name { get; }

        public ScheduledJobDefinition(int version, Type type, string name)
        {
            Version = version;
            Type = type;
            Name = name;
        }

        public override string ToString()
        {
            var assemblyName = Type.GetTypeInfo().Assembly.GetName();
            return $"{Name} v{Version} ({assemblyName.Name} - {Type.GetGenericTypeDefinition()})";
        }
    }
}
