﻿namespace NOV.ES.Framework.Core.ScheduledJobs.Attributes
{
    [AttributeUsage(AttributeTargets.Class)]
    public class ScheduledJobAttribute : Attribute
    {
        public string Name { get; }
        public int Version { get; }

        public ScheduledJobAttribute(string name, int version)
        {
            if (string.IsNullOrEmpty(name)) throw new ArgumentNullException(nameof(name));
            if (version <= 0) throw new ArgumentOutOfRangeException(nameof(version), "Version must be greater than 0");

            Name = name;
            Version = version;
        }
    }
}
