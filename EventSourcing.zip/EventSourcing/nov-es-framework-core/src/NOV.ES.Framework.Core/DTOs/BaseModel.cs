﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace NOV.ES.Framework.Core.DTOs
{
    public class BaseModel<T>
    {
        public T Id { get; set; }
        public bool IsActive { get; set; }
        public DateTime DateCreated { get; set; }
        public string CreatedBy { get; set; }
        public DateTime DateModified { get; set; }
        public string ModifiedBy { get; set; }
        public string CreatedSource { get; set; }
        public string ModifiedSource { get; set; }

    }
}



