﻿namespace NOV.ES.Framework.Core.Domain
{
    public class DomainEvent<T>
        : IDomainEvent<T> where T : new()
    {
        public Guid EventId { get; set; }

        public string EventType { get; set; }

        public T AggregateRootId { get; set; }

        public long AggregateVersion { get; set; }

        public DateTime EventDate { get; set; }

        public DomainEvent()
        {
            EventId = Guid.NewGuid();
            EventDate = DateTime.UtcNow;
            EventType = String.Empty;
            AggregateRootId = default;
        }

        public DomainEvent(T aggregateId) : this()
        {
            AggregateRootId = aggregateId;
        }

        public DomainEvent(T aggregateId, long aggregateVersion) : this(aggregateId)
        {
            AggregateVersion = aggregateVersion;
        }

    }
}
