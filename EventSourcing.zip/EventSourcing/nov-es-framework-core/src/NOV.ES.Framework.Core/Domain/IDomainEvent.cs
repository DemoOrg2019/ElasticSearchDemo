﻿namespace NOV.ES.Framework.Core.Domain
{
    public interface IDomainEvent<T>
    {
        /// <summary>
        /// The event identifier
        /// </summary>
        Guid EventId { get; }

        string EventType { get; set; }

        /// <summary>
        /// The identifier of the aggregate which has generated the event
        /// </summary>
        T AggregateRootId { get; set; }

        /// <summary>
        /// The version of the aggregate when the event has been generated
        /// </summary>
        long AggregateVersion { get; set; }

        /// <summary>
        /// DateTime Stamp when an event has been generated
        /// </summary>
        DateTime EventDate { get; }
    }
}
