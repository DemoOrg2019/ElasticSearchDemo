﻿using NOV.ES.Framework.Core.Entities;

namespace NOV.ES.Framework.Core.Domain
{
    public interface IAggregateRoot<T>
        : IEntity<T>, IAuditEntity where T : new()
    {

    }
}
