﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.API.Application.Queries;
using NOV.ES.TAT.CustomerTransfer.API.Controllers;
using NOV.ES.TAT.CustomerTransfer.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Domain;
using NOV.ES.TAT.CustomerTransfer.DomainService;
using NOV.ES.TAT.CustomerTransfer.Infrastructure;
using NOV.ES.TAT.CustomerTransfer.Test;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NOV.ES.TAT.Admin.Test
{
    [TestClass]
    public class CustomerTransferSlipTest : TestBase
    {
        private readonly ICustomerTransferSlipService customerTransferSlipService;
        private Paging pagingParameters;
        private CustomerTransferSlipsController customerTransferSlipsController;
        private readonly ILogger<CustomerTransferSlipsController> logger;
        private IEnumerable<CustomerTransferSlipDto> customerTransferSlipDtos = new List<CustomerTransferSlipDto>();
        private IEnumerable<CustomerTransferSlipDetailDto> customerTransferSlipDetailDtos = new List<CustomerTransferSlipDetailDto>();
        public CustomerTransferSlipTest() : base()
        {
            customerTransferSlipService = new CustomerTransferSlipService
                (new CustomerTransferSlipQueryRepository(CustomerTransferSlipDBContext));
            pagingParameters = new Paging();

            logger = new Mock<ILogger<CustomerTransferSlipsController>>().Object;
            IQueryBus queryBus = new Mock<IQueryBus>().Object;

            customerTransferSlipsController = new CustomerTransferSlipsController(logger, queryBus);
        }

        [TestInitialize]
        public void SetUp()
        {
            ClearAndSeedTestData();
        }

        #region Controller unit Tests

        [TestMethod]
        public void ShouldReturnsServiceNameWithOkStatus_ServiceName()
        {
            var result = customerTransferSlipsController.ServiceName();

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            Assert.AreEqual("CustomerTransferSlips CustomerTransfer Service.", ((OkObjectResult)result).Value);
        }

        [TestMethod]
        public async Task ShouldReturnsEmptyListofCustomerTransferSlipsWithOkStatus_GetCustomerTransferSlips()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();
            customerTransferSlipDtos = new List<CustomerTransferSlipDto>();
            mockQueryBus.Setup(x => x.Send<GetPaginationCustomerTransferSlipsQuery, PagedResult<CustomerTransferSlipDto>>(It.IsAny<GetPaginationCustomerTransferSlipsQuery>()))
                .ReturnsAsync(new PagedResult<CustomerTransferSlipDto>(customerTransferSlipDtos, customerTransferSlipDtos.Count(), pagingParameters));

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipsController = new CustomerTransferSlipsController(logger, queryBus);

            customerTransferSlipsController.ControllerContext.HttpContext = new DefaultHttpContext();
            customerTransferSlipsController.ControllerContext.HttpContext.Request.QueryString = new QueryString();
            var result = await customerTransferSlipsController.GetCustomerTransferSlips(new Paging());

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsListofCustomerTransferSlipsWithOkStatus_GetCustomerTransferSlips()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();

            mockQueryBus.Setup(x => x.Send<GetPaginationCustomerTransferSlipsQuery, PagedResult<CustomerTransferSlipDto>>(It.IsAny<GetPaginationCustomerTransferSlipsQuery>()))
                .ReturnsAsync(new PagedResult<CustomerTransferSlipDto>(customerTransferSlipDtos, customerTransferSlipDtos.Count(), new Paging()));

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipsController = new CustomerTransferSlipsController(logger, queryBus);

            customerTransferSlipsController.ControllerContext.HttpContext = new DefaultHttpContext();
            customerTransferSlipsController.ControllerContext.HttpContext.Request.QueryString = new QueryString();

            var result = await customerTransferSlipsController.GetCustomerTransferSlips(new Paging());
            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsNotFoundResult_GetCustomerTransferSlipById()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();
            /*
            * suppressed Possible null reference return warning ,
            * test case intended to check returning null value by method
            * */
            mockQueryBus.Setup(x => x.Send<GetCustomerTransferSlipByIdQuery, CustomerTransferSlipDto>(It.IsAny<GetCustomerTransferSlipByIdQuery>()))
#pragma warning disable CS8603 // Possible null reference return.
                .ReturnsAsync(() => null);
#pragma warning restore CS8603 // Possible null reference return.

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipsController = new CustomerTransferSlipsController(logger, queryBus);
            var result = await customerTransferSlipsController.GetCustomerTransferSlipById(Guid.Parse("94DA11D8-72C7-49BC-B191-5E7106498D63"));

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(NotFoundObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsCustomerTransferSlipWithOkStatus_GetCustomerTransferSlipId()
        {
            Mock<IQueryBus> mockQueryBus = new();

            Guid id = customerTransferSlipDtos.First().Id;
            var customerTransferSlipDto = customerTransferSlipDtos.FirstOrDefault(o => o.Id == id);

            Assert.IsNotNull(customerTransferSlipDto);

            mockQueryBus.Setup(x => x.Send<GetCustomerTransferSlipByIdQuery, CustomerTransferSlipDto>(It.IsAny<GetCustomerTransferSlipByIdQuery>()))
                .ReturnsAsync(customerTransferSlipDto);

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipsController = new CustomerTransferSlipsController(logger, queryBus);
            var result = await customerTransferSlipsController.GetCustomerTransferSlipById(id);

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));

            OkObjectResult actualResult = ((OkObjectResult)result.Result);
            Assert.IsNotNull(actualResult.Value);
            Assert.AreEqual(typeof(CustomerTransferSlipDto), actualResult.Value.GetType());
        }

        [TestMethod]
        public async Task ShouldReturnsNotFoundResult_GetCustomerTransferSlipsByNumber()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();
            /*
            * suppressed Possible null reference return warning ,
            * test case intended to check returning null value by method
            * */
            mockQueryBus.Setup(x => x.Send<GetCustomerTransferSlipByNumberQuery, IEnumerable<CustomerTransferSlipDto>>(It.IsAny<GetCustomerTransferSlipByNumberQuery>()))
#pragma warning disable CS8603 // Possible null reference return.
                .ReturnsAsync(() => null);
#pragma warning restore CS8603 // Possible null reference return.

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipsController = new CustomerTransferSlipsController(logger, queryBus);
            var result = await customerTransferSlipsController.GetCustomerTransferSlipsByNumber(101);

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(NotFoundObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsCustomerTransferSlipWithOkStatus_GetCustomerTransferSlipsByNumber()
        {
            Mock<IQueryBus> mockQueryBus = new();

            int customerTransferNumber = customerTransferSlipDtos.First().CustomerTransferNumber;
            IEnumerable<CustomerTransferSlipDto> customerTransferSlipDto = customerTransferSlipDtos.ToList();
            Assert.IsNotNull(customerTransferSlipDto);

            mockQueryBus.Setup(x => x.Send<GetCustomerTransferSlipByNumberQuery, IEnumerable<CustomerTransferSlipDto>>(It.IsAny<GetCustomerTransferSlipByNumberQuery>()))
                .ReturnsAsync(customerTransferSlipDto);

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipsController = new CustomerTransferSlipsController(logger, queryBus);
            var result = await customerTransferSlipsController.GetCustomerTransferSlipsByNumber(customerTransferNumber);

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));

            OkObjectResult actualResult = ((OkObjectResult)result.Result);
            Assert.IsNotNull(actualResult.Value);
            Assert.AreEqual(typeof(List<CustomerTransferSlipDto>), actualResult.Value.GetType());
        }

        [TestMethod]
        public async Task ShouldReturnsNotFoundResult_GetCustomerTransferSlipDetailsById()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();
            /*
            * suppressed Possible null reference return warning ,
            * test case intended to check returning null value by method
            * */
            mockQueryBus.Setup(x => x.Send<GetCustomerTransferSlipDetailsByIdQuery, IEnumerable<CustomerTransferSlipDto>>(It.IsAny<GetCustomerTransferSlipDetailsByIdQuery>()))
#pragma warning disable CS8603 // Possible null reference return.
                .ReturnsAsync(() => null);
#pragma warning restore CS8603 // Possible null reference return.

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipsController = new CustomerTransferSlipsController(logger, queryBus);
            var result = await customerTransferSlipsController.GetCustomerTransferSlipDetailsById(Guid.Parse("94DA11D8-72C7-49BC-B191-5E7106498D63"));

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(NotFoundObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsCustomerTransferSlipWithOkStatus_GetCustomerTransferSlipDetailsById()
        {
            Mock<IQueryBus> mockQueryBus = new();

            Guid id = customerTransferSlipDtos.First().Id;
            IEnumerable<CustomerTransferSlipDto> customerTransferSlipDto = customerTransferSlipDtos.ToList();
            Assert.IsNotNull(customerTransferSlipDto);

            mockQueryBus.Setup(x => x.Send<GetCustomerTransferSlipDetailsByIdQuery, IEnumerable<CustomerTransferSlipDto>>(It.IsAny<GetCustomerTransferSlipDetailsByIdQuery>()))
                .ReturnsAsync(customerTransferSlipDto);

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipsController = new CustomerTransferSlipsController(logger, queryBus);
            var result = await customerTransferSlipsController.GetCustomerTransferSlipDetailsById(id);

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));

            OkObjectResult actualResult = ((OkObjectResult)result.Result);
            Assert.IsNotNull(actualResult.Value);
            Assert.AreEqual(typeof(List<CustomerTransferSlipDto>), actualResult.Value.GetType());
        }
        #endregion

        #region DomainService unit tests
        [TestMethod]
        public void ShouldReturnAllCustomerTransferSlips_GetCustomerTransferSlips()
        {
            var customerTransferSlips = customerTransferSlipService.GetCustomerTransferSlips(null);
            var customerTransferSlip = customerTransferSlips.FirstOrDefault();

            Assert.IsNotNull(customerTransferSlip);
            Assert.AreEqual(2, customerTransferSlips.Count());
            Assert.IsNotNull(customerTransferSlip);
            Assert.AreEqual(Guid.Parse("58b0b9b9-6548-4785-a687-8103383fc01a"), customerTransferSlip.Id);
            Assert.AreEqual(101, customerTransferSlip.CustomerTransferNumber);
            Assert.AreEqual("SID", customerTransferSlip.CustomerName);
            Assert.AreEqual("9768", customerTransferSlip.CustomerContact);
            Assert.AreEqual("USD", customerTransferSlip.Currency);
        }

        [TestMethod]
        public void ShouldReturnCustomerTransferSlipForGivenId_GetCustomerTransferSlipById()
        {
            var customerTransferSlip = customerTransferSlipService.GetCustomerTransferSlipById(new Guid("9ce0c723-1345-4d6d-a700-098bbd1d90cd"));

            Assert.IsNotNull(customerTransferSlip);
            Assert.AreEqual(Guid.Parse("9ce0c723-1345-4d6d-a700-098bbd1d90cd"), customerTransferSlip.Id);
            Assert.AreEqual(102, customerTransferSlip.CustomerTransferNumber);
            Assert.AreEqual("Sid", customerTransferSlip.CustomerName);
            Assert.AreEqual("9619", customerTransferSlip.CustomerContact);
            Assert.AreEqual("Curr", customerTransferSlip.Currency);
        }

        [TestMethod]
        public void ShouldReturnCustomerTransferSlipForGivenId_GetCustomerTransferSlipByNumber()
        {
            var customerTransferSlips = customerTransferSlipService.GetCustomerTransferSlipsByNumber(102);
            var customerTransferSlip = customerTransferSlips.FirstOrDefault();
            Assert.IsNotNull(customerTransferSlip);
            Assert.AreEqual(102, customerTransferSlip.CustomerTransferNumber);
            Assert.AreEqual("Sid", customerTransferSlip.CustomerName);
            Assert.AreEqual("9619", customerTransferSlip.CustomerContact);
            Assert.AreEqual("Curr", customerTransferSlip.Currency);
        }

        [TestMethod]
        public void ShouldReturnCustomerTransferSlipForGivenId_GetCustomerTransferSlipDetailsById()
        {
            var customerTransferSlips = customerTransferSlipService.GetCustomerTransferSlipDetailsById(new Guid("9ce0c723-1345-4d6d-a700-098bbd1d90cd"));
            var customerTransferSlip = customerTransferSlips.FirstOrDefault();
            Assert.IsNotNull(customerTransferSlip);
            Assert.AreEqual(102, customerTransferSlip.CustomerTransferNumber);
            Assert.AreEqual("Sid", customerTransferSlip.CustomerName);
            Assert.AreEqual("9619", customerTransferSlip.CustomerContact);
            Assert.AreEqual("Curr", customerTransferSlip.Currency);
        }

        #region Pagination
        /// <summary>
        ///  test Pagination with valid pagingParameters
        /// </summary>
        [TestMethod]
        public void ShouldReturnsCustomerTransferSlips_GetCustomerTransferSlips()
        {
            pagingParameters = new Paging()
            {
                PageIndex = 1,
                PageSize = 1,
                SortColumn = "Id"
            };

            var customerTransferSlips = customerTransferSlipService.GetCustomerTransferSlips(pagingParameters);
            var customerTransferSlip = customerTransferSlips.FirstOrDefault();

            Assert.IsNotNull(customerTransferSlip);
            Assert.AreEqual(1, customerTransferSlips.Count());
            Assert.AreEqual(2, customerTransferSlips.TotalNumberOfItems);
            Assert.AreEqual(2, customerTransferSlips.TotalNumberOfPages);
            Assert.IsNotNull(customerTransferSlip);
            Assert.AreEqual(Guid.Parse("9ce0c723-1345-4d6d-a700-098bbd1d90cd"), customerTransferSlip.Id);
            Assert.AreEqual(102, customerTransferSlip.CustomerTransferNumber);
            Assert.AreEqual("Sid", customerTransferSlip.CustomerName);
            Assert.AreEqual("9619", customerTransferSlip.CustomerContact);
            Assert.AreEqual("Curr", customerTransferSlip.Currency);
        }

        /// <summary>
        /// test Pagination with invalid SortColumn   .
        /// <returns>
        /// ArgumentException("Value does not have matching column");
        /// </returns>
        /// </summary>
        [TestMethod]
        public void ShouldThrowArgumentExceptionForGivenInvalidSortColumn_GetCustomerTransferSlips()
        {
            pagingParameters = new Paging()
            {
                SortColumn = "SortColumn"
            };
            try
            {
                customerTransferSlipService.GetCustomerTransferSlips(pagingParameters);
                Assert.Fail();
            }
            catch (ArgumentException argumentException)
            {
                Assert.AreEqual("Sort column SortColumn does not exist.", argumentException.Message);
            }
        }

        #endregion

        #endregion

        [TestCleanup]
        public void TestCleanup()
        {
            Dispose();
        }

        private void ClearAndSeedTestData()
        {
            CustomerTransferSlipDBContext.Database.EnsureDeleted();
            CustomerTransferSlipDBContext.Database.EnsureCreated();

            string jsonFilePath = Path.Combine(".", "TestData", "CustomerTransferSlipDetailsSeed.json");
            var customerTransferSlipDetails = DeserializeJsonToObject<CustomerTransferSlipDetail>(jsonFilePath);
            customerTransferSlipDetailDtos = DeserializeJsonToObject<CustomerTransferSlipDetailDto>(jsonFilePath);
            CustomerTransferSlipDBContext.CustomerTransferSlipDetails.AddRange(customerTransferSlipDetails);

            jsonFilePath = Path.Combine(".", "TestData", "CustomerTransferSlipsSeed.json");
            var customerTransferSlips = DeserializeJsonToObject<CustomerTransferSlip>(jsonFilePath);
            customerTransferSlipDtos = DeserializeJsonToObject<CustomerTransferSlipDto>(jsonFilePath);
            CustomerTransferSlipDBContext.CustomerTransferSlips.AddRange(customerTransferSlips);


            CustomerTransferSlipDBContext.SaveChanges();
        }
    }
}