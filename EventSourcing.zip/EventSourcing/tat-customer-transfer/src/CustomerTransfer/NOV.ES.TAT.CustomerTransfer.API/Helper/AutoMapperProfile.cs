﻿using AutoMapper;

namespace NOV.ES.TAT.CustomerTransfer.API.Helper
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {            
        }
    }
}
