﻿using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.CustomerTransfer.Domain;

namespace NOV.ES.TAT.CustomerTransfer.API.Application.Commands
{
    public class CreateCustomerTransferSlipHeaderCommand 
        : CustomerTransferSlipHeader, ICommand<bool>
    {
        // private readonly CustomerTransferSlipHeader header;

        public CreateCustomerTransferSlipHeaderCommand()
        {

        }

        //public CreateCustomerTransferSlipHeaderCommand(CustomerTransferSlipHeader header)
        //{
        //    this.CustomerTransferSlipId = header.CustomerTransferSlipId;
        //    this.CustomerSalesInfo = header.CustomerSalesInfo;
        //    this.ShippingInfo = header.ShippingInfo;
        //    this.RigsWellSiteInfo = header.RigsWellSiteInfo;
        //}

        //public CreateCustomerTransferSlipHeaderCommand(CustomerTransferSlipHeader header)
        //{
        //    this.header.CustomerTransferSlipId = header.CustomerTransferSlipId;
        //    this.header.CustomerSalesInfo = header.CustomerSalesInfo;
        //    this.header.ShippingInfo = header.ShippingInfo;
        //    this.header.RigsWellSiteInfo = header.RigsWellSiteInfo;
        //}
    }
}
