﻿using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.CustomerTransfer.Domain;

namespace NOV.ES.TAT.CustomerTransfer.API.Application.Commands
{
    public class AddItemsCommand 
        : CustomerTransferSlipDetail, ICommand<bool>
    {
        public AddItemsCommand()
        {
        }
    }
}
