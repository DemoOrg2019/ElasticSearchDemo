﻿using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.CustomerTransfer.Domain;
using NOV.ES.TAT.CustomerTransfer.Infrastructure.Interfaces;

namespace NOV.ES.TAT.CustomerTransfer.API.Application.Commands
{
    public class CreateCustomerTransferSlipHeaderCommandHandler
        : ICommandHandler<CreateCustomerTransferSlipHeaderCommand, bool>
    {
        private readonly ILogger<CreateCustomerTransferSlipHeaderCommandHandler> logger;
        private readonly ICustomerTransferSlipEventSourcingRepository customerTransferSlipEventSourcingRepository;

        public CreateCustomerTransferSlipHeaderCommandHandler(
            ILogger<CreateCustomerTransferSlipHeaderCommandHandler> logger,
            ICustomerTransferSlipEventSourcingRepository customerTransferSlipEventSourcingRepository
            )
        {
            this.logger = logger;
            this.customerTransferSlipEventSourcingRepository = customerTransferSlipEventSourcingRepository;
        }

        public Task<bool> Handle(CreateCustomerTransferSlipHeaderCommand request, CancellationToken cancellationToken)
        {
            logger.LogInformation("----- Create Customer Transfer Slip Header Request: {@Header}", request);
            
            var expectedVersion = customerTransferSlipEventSourcingRepository.GetAggregateVersion(request.CustomerTransferSlipId, 0);

            if (expectedVersion > 0)
            {
                logger.LogWarning("----- Cannot create as Customer Transfer Slip already exists: {@slipid}", request.CustomerTransferSlipId);
                return Task.FromResult(false);
            }

            CustomerTransferSlip slip = new CustomerTransferSlip();
            slip.CreateHeader(request);

            customerTransferSlipEventSourcingRepository.Save(slip);

            return Task.FromResult(true);
        }
    }
}
