﻿using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.CustomerTransfer.Domain;
using NOV.ES.TAT.CustomerTransfer.Domain.Events;
using NOV.ES.TAT.CustomerTransfer.Infrastructure.Interfaces;

namespace NOV.ES.TAT.CustomerTransfer.API.Application.Commands
{
    public class AddItemsCommandHandler
        : ICommandHandler<AddItemsCommand, bool>
    {
        private readonly ILogger<CreateCustomerTransferSlipHeaderCommandHandler> logger;
        private readonly ICustomerTransferSlipEventSourcingRepository customerTransferSlipEventSourcingRepository;

        public AddItemsCommandHandler(
            ILogger<CreateCustomerTransferSlipHeaderCommandHandler> logger,
            ICustomerTransferSlipEventSourcingRepository customerTransferSlipEventSourcingRepository)
        {
            this.logger = logger;
            this.customerTransferSlipEventSourcingRepository = customerTransferSlipEventSourcingRepository;

        }

        public Task<bool> Handle(AddItemsCommand request, CancellationToken cancellationToken)
        {
            logger.LogInformation("----- Add Items to Customer Transfer Slip Request: {@slipid} - {@itemscount}", request.CustomerTransferSlipId, request.Items?.Count);

            var lastSequenceNumber = customerTransferSlipEventSourcingRepository.GetAggregateVersion(request.CustomerTransferSlipId, 0);

            if(lastSequenceNumber == 0)
            {
                logger.LogWarning("----- Cannot add Items as Customer Transfer Slip does not exists: {@slipid}", request.CustomerTransferSlipId);
                return Task.FromResult(false);
            }

            
            CustomerTransferSlip slip = new CustomerTransferSlip(request.CustomerTransferSlipId);            
            slip.AddItems(request, lastSequenceNumber);

            customerTransferSlipEventSourcingRepository.Save(slip);

            return Task.FromResult(true);
        }
    }
}
