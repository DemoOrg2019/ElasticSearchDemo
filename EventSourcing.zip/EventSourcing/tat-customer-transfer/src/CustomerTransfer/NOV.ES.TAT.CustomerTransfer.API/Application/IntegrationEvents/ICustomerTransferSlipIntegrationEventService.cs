﻿namespace NOV.ES.TAT.CustomerTransfer.API.Application.IntegrationEvents
{
    public interface ICustomerTransferSlipIntegrationEventService
    {
    }
}
