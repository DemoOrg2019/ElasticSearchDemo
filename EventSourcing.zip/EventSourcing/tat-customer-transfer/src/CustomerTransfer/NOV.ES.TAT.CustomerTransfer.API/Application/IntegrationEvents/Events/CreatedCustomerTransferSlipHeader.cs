﻿using NOV.ES.Framework.Core.Messaging.IntegrationEvents;

namespace NOV.ES.TAT.CustomerTransfer.API.Application.IntegrationEvents.Events
{
    public class CreatedCustomerTransferSlipHeaderIntegrationEvent
        : IntegrationEvent
    {
        public Guid CustomerTransferSlipId { get; init; }

        public CreatedCustomerTransferSlipHeaderIntegrationEvent(Guid cuustomerTransferSlipId)
            => CustomerTransferSlipId = cuustomerTransferSlipId;
    }
}
