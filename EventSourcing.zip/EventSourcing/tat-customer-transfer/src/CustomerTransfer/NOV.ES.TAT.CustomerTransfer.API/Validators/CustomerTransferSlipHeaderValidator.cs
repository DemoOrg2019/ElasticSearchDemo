﻿using FluentValidation;
using FluentValidation.Results;
using NOV.ES.TAT.CustomerTransfer.API.Application.Commands;
using NOV.ES.TAT.CustomerTransfer.API.DTOs;

namespace NOV.ES.TAT.CustomerTransfer.API.Validators
{
    public class CustomerTransferSlipHeaderValidator
    : AbstractValidator<CustomerTransferSlipDto>
    {
        public CustomerTransferSlipHeaderValidator()
        {
        }
        public new ValidationResult Validate(CustomerTransferSlipDto instance)
        {
            return instance == null
                ? new ValidationResult(new[] { new ValidationFailure("CustomerTransferSlipHeaderDto", "CustomerTransferSlipHeaderDto cannot be null") })
                : base.Validate(instance);
        }

        public ValidationResult Validate(CreateCustomerTransferSlipCommand instance)
        {
            return instance == null
                ? new ValidationResult(new[] { new ValidationFailure("CreateCustomerTransferSlipCommand", "CreateCustomerTransferSlipCommand cannot be null") })
                : Validate(instance.CustomerTransferSlipHeaderDto);
        }

        public ValidationResult Validate(UpdateCustomerTransferSlipCommand instance)
        {
            return instance == null
                ? new ValidationResult(new[] { new ValidationFailure("UpdateCustomerTransferSlipCommand", "UpdateCustomerTransferSlipCommand cannot be null") })
                : Validate(instance.CustomerTransferSlipHeaderDto);
        }
    }
}