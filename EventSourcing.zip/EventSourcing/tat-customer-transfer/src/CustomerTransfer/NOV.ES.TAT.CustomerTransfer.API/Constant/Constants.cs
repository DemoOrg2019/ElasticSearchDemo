﻿namespace NOV.ES.TAT.CustomerTransfer.API
{
    public static class Constants
    {
    }
}
