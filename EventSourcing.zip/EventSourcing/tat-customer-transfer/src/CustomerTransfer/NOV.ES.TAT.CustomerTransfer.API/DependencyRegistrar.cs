﻿using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.Framework.Core.CQRS.Events;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.EventStore;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Serializer;
using NOV.ES.Infrastructure.EventStore.EFCore;
using NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq;
using NOV.ES.TAT.CustomerTransfer.API.Filters;
using NOV.ES.TAT.CustomerTransfer.Infrastructure.Interfaces;
using NOV.ES.TAT.CustomerTransfer.Infrastructure.Repositories;
using Swashbuckle.AspNetCore.Filters;
using System.Reflection;

namespace NOV.ES.TAT.CustomerTransfer.API
{
    public static class DependencyRegistrar
    {
        public static IServiceCollection AddCustomMvc(this IServiceCollection services)
        {
            services.AddControllers(
               options => options.Filters.Add(typeof(HttpGlobalExceptionFilter))
           ).AddNewtonsoftJson(
               joptions =>
               {
                   joptions.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                   joptions.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                   joptions.SerializerSettings.Converters.Add(new StringEnumConverter());
               }
           );
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                    .SetIsOriginAllowed((host) => true)
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });
            return services;
        }
        public static IServiceCollection AddHealthChecks(this IServiceCollection services, IConfiguration configuration)
        {
            var hcBuilder = services.AddHealthChecks();
            hcBuilder.AddCheck("self", () => HealthCheckResult.Healthy());
            return services;
        }
        public static IServiceCollection AddCustomDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            //services.AddDbContext<CustomerTransferSlipDBContext>(options =>
            //{
            //    options.UseSqlServer(configuration["CustomerTransferDBConnString"],
            //        sqlServerOptionsAction: sqlOptions =>
            //        {
            //            sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
            //            sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
            //        });
            //},
            //ServiceLifetime.Scoped
            //);
            return services;
        }
        public static IServiceCollection AddCustomSwagger(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "TAT Customer Transfer REST API",
                    Version = "v1",
                    Description = "The Customer Transfer Service REST API"
                });
                options.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
                {
                    Description = "Standard Authorization header using the Bearer scheme. Example: \"bearer {token}\"",
                    In = ParameterLocation.Header,
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey
                });

                options.OperationFilter<SecurityRequirementsOperationFilter>();
            });
            return services;
        }
        public static IServiceCollection AddDomainCoreDependecy(this IServiceCollection services)
        {
            services.AddScoped<ICommandBus, CommandBus>();
            services.AddScoped<IQueryBus, QueryBus>();
            services.AddScoped<IEventBus, EventBus>();
            //services.AddScoped<ICustomerTransferSlipService, CustomerTransferSlipService>();
            services.AddScoped<ICustomerTransferSlipEventSourcingRepository, CustomerTransferSlipEventSourcingRepository>();

            services.AddScoped<IDomainEventSerializer<Guid>, JsonDomainEventSerializer<Guid>>();
            return services;
        }
        public static IServiceCollection RegistorMediatR(this IServiceCollection services)
        {
            services.AddMediatR(typeof(Startup).GetTypeInfo().Assembly);
            services.AddValidatorsFromAssembly(typeof(Startup).Assembly);
            return services;
        }
        public static IServiceCollection AddAutoMapper(this IServiceCollection services)
        {
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            return services;
        }

        public static IServiceCollection AddEventStoreConfiguration(this IServiceCollection services, IConfiguration configuration)
        {
            // Event Store
            //services.AddDbContext<EventStoreContext<Guid>>(options =>
            //{

            //    options.UseSqlServer(configuration["CustomerTransferDBConnString"]);

            //});

            services.AddDbContext<EventStoreContext>(options =>
            {
                options.UseSqlServer(configuration["CustomerTransferDBConnString"],
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
                        sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                    });
            },
            ServiceLifetime.Scoped
            );

            services.AddScoped<IEventStore, EFEventStore>();
            //services.AddScoped<ISnapshotStore, NullSnapshotStore>();
            return services;
        }

        public static IServiceCollection AddIntegrationEventBus(this IServiceCollection services)
        {
            services.AddSingleton<IIntegrationEventBus, EventBusRabbitMq>();
            // services.AddScoped<IEventHandler<MovieCreatedEvent>, MovieCreatedEventHandler>();

            return services;
        }
    }
}
