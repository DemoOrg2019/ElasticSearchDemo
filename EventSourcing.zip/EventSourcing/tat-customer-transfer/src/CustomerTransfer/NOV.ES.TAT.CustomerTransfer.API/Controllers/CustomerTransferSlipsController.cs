﻿using Microsoft.AspNetCore.Mvc;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Common.Exception;
using NOV.ES.TAT.CustomerTransfer.API.Application.Commands;
using NOV.ES.TAT.CustomerTransfer.Domain;
using System.Net;

namespace NOV.ES.TAT.CustomerTransfer.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerTransferSlipsController : ControllerBase
    {
        private readonly ILogger<CustomerTransferSlipsController> logger;
        private readonly ICommandBus commandBus;
        public CustomerTransferSlipsController(
            ILogger<CustomerTransferSlipsController> logger,
            ICommandBus commandBus)
        {
            this.logger = logger;
            this.commandBus = commandBus;
        }

        /// <summary>
        /// This method returns service name.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("ServiceName")]
        public IActionResult ServiceName()
        {
            return Ok("CustomerTransferSlips CustomerTransfer Service.");
        }

        [HttpPost]
        [Route("headers")]
        [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<bool>> AddCustomerTransferSlipHeader([FromBody] CreateCustomerTransferSlipHeaderCommand command)
        {

            var result = await commandBus.Send<CreateCustomerTransferSlipHeaderCommand, bool>(command);

            return Ok(result);
        }

        [HttpPost]
        [Route("items")]
        [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<bool>> AddItems([FromBody] AddItemsCommand command)
        {

            var result = await commandBus.Send<AddItemsCommand, bool>(command);

            return Ok(result);
        }

    }
}
