﻿namespace NOV.ES.TAT.CustomerTransfer.Domain
{
    public class CustomerTransferSlipHeader
    {
        public Guid CustomerTransferSlipId { get; set; }
        public CustomerSalesInfo CustomerSalesInfo { get; set; }
        public RigsWellSiteInfo RigsWellSiteInfo { get; set; }
        public ShippingInfo ShippingInfo { get; set; }
        public CustomerTransferSlipHeader()
        {
        }
    }

    public class CustomerSalesInfo
    {
        public int? ErpJobNumber { get; set; }
        public Guid CompanyId { get; set; }
        public Guid RevenuBuId { get; set; } // OilCompanyId
        public Guid SendingBuId { get; set; } // 
        public int SendingLocationId { get; set; } //        
        public Guid CustomerId { get; set; }
        public string ShipTo { get; set; } // Ship To Address
        public Guid? ActualCustomerId { get; set; } // EffectiveCustomerId
        public Guid SalesZoneId { get; set; }
        public string CustomerPONumber { get; set; }
        public string CustomerContactPerson { get; set; }
        public string CustomerContactNumber { get; set; }
        public string CustomerJobNumber { get; set; }
        public Guid? SalesPersonId { get; set; }
        public DateTime SlipDate { get; set; }
        public string RentalAgreement { get; set; }
        public CommericialInfo CommericialInfo { get; set; }
        public CustomerSalesInfo()
        {
        }
    }

    public class CommericialInfo
    {
        public string Currency { get; set; }
        public string Verbiage { get; set; }
        public string VatNo { get; set; }
        public string Comments { get; set; }

        public CommericialInfo()
        {
        }

    }

    public class RigsWellSiteInfo
    {
        public int? RigId { get; set; }
        public string RigJDEName { get; set; }
        public bool IsUseIntendOnLand { get; set; }
        public int? WellSiteId { get; set; }
        public string CountyLsd { get; set; }
        public Guid Operator { get; set; } // Oil Company Id
        public string OcsgNumber { get; set; }
        public Guid? DrillingApplicationId { get; set; }
        public Guid? BillingApplicationId { get; set; }

        public RigsWellSiteInfo()
        {
        }

    }

    public class ShippingInfo
    {
        public string PreparedBy { get; set; }
        public string BillOfLading { get; set; }
        public string CheckedBy { get; set; }
        public string WayBill { get; set; }
        public Guid FreightTypeId { get; set; }
        public string FreightType { get; set; }
        public string FieldTicket { get; set; }
        public string ShippingInstruction { get; set; }
        public string ForwardingInstruction { get; set; }

        public ShippingInfo()
        {

        }

    }
}
