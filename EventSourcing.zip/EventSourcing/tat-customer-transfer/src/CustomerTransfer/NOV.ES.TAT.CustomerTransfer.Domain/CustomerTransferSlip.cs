﻿using NOV.ES.Framework.Core.Domain;
using NOV.ES.Framework.Core.Entities;
using NOV.ES.TAT.CustomerTransfer.Domain.Events;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NOV.ES.TAT.CustomerTransfer.Domain
{
    public class CustomerTransferSlip : AggregateRoot<Guid>
    {
        public CustomerTransferSlipHeader Header { get; private set; }
        public CustomerTransferSlipDetail Detail { get; private set; }
        public CustomerTransferSlip()
        {

        }

        public CustomerTransferSlip(Guid aggregateRootId)
            : base()
        {
            Id = aggregateRootId;
            Detail = new CustomerTransferSlipDetail();
            Detail.CustomerTransferSlipId = aggregateRootId;
        }

        public void CreateHeader(CustomerTransferSlipHeader header)
        {
            Id = header.CustomerTransferSlipId;
            Header = header;
            Apply(new CreatedCustomerTransferSlipHeader(Header));
        }

        public void AddItems(CustomerTransferSlipDetail detail, long aggregateVersion)
        {
            LastEventSequence = aggregateVersion;
            if(Detail == null)
            {
                Detail = new CustomerTransferSlipDetail(detail.CustomerTransferSlipId);
            }

            Detail.Items.AddRange(detail.Items);

            Apply(new AddedItemsToCustomerTransferSlip(Detail, aggregateVersion));
        }
    }

    //[Table("CustomerTransferSlip")]
    //public class CustomerTransferSlip : BaseEntity<Guid>
    //{
    //    [Required]
    //    public int CustomerTransferNumber { get; set; }
    //    [Required]
    //    public Guid CompanyId { get; set; }
    //    [MaxLength(40)]
    //    [Required]
    //    public string CompanyName { get; set; }
    //    [Required]
    //    public DateTime SlipDate { get; set; }
    //    [Required]
    //    public DateTime UsageDate { get; set; }
    //    public Guid? OilCompanyId { get; set; }
    //    [MaxLength(50)]
    //    public string OilCompanyName { get; set; }
    //    public int? RigId { get; set; }
    //    public Guid? CorpRigId { get; set; }
    //    [MaxLength(100)]
    //    public string RigName { get; set; }
    //    [MaxLength(100)]
    //    public string RigJDEName { get; set; }
    //    public int? WellSiteId { get; set; }
    //    public Guid? CorpWellSiteId { get; set; }
    //    [MaxLength(30)]
    //    public string WellName { get; set; }
    //    [MaxLength(30)]
    //    public string WellLocation { get; set; }
    //    [MaxLength(10)]
    //    public string WellNameSource { get; set; }
    //    public int? ErpJobNumber { get; set; }
    //    [MaxLength(20)]
    //    public string CustomerJobNumber { get; set; }
    //    public string ShipVia { get; set; }
    //    [MaxLength(100)]
    //    public string ShippedBy { get; set; }
    //    public Guid? CustomerId { get; set; }
    //    [MaxLength(100)]
    //    public string CustomerName { get; set; }
    //    public Guid? EffectiveCustomerId { get; set; }
    //    [MaxLength(100)]
    //    public string EffectiveCustomerName { get; set; }
    //    public Guid? DrillingApplicationId { get; set; }
    //    [MaxLength(20)]
    //    public string DrillingApplicationName { get; set; }
    //    public Guid? BillingApplicationId { get; set; }
    //    [MaxLength(20)]
    //    public string BillingApplicationName { get; set; }
    //    public Guid? BusinessUnitId { get; set; }
    //    [MaxLength(50)]
    //    public string BusinessUnitName { get; set; }
    //    [MaxLength(500)]
    //    public string HeaderAddress { get; set; }
    //    [MaxLength(100)]
    //    public string HeaderPhone { get; set; }
    //    [MaxLength(100)]
    //    public string HeaderFax { get; set; }
    //    [MaxLength(30)]
    //    public string CustomerContact { get; set; }
    //    [MaxLength(20)]
    //    public string CustomerPhoneNumber { get; set; }
    //    public Guid? FreightTypeId { get; set; }
    //    [MaxLength(10)]
    //    public string FreightType { get; set; }
    //    [MaxLength(30)]
    //    public string BillOfLading { get; set; }
    //    [MaxLength(30)]
    //    public string WayBill { get; set; }
    //    [MaxLength(30)]
    //    public string GLCode { get; set; }
    //    public Guid? SalesPersonId { get; set; }
    //    [MaxLength(50)]
    //    public string SalesPersonName { get; set; }
    //    [MaxLength(100)]
    //    public string CheckedBy { get; set; }
    //    public Guid? SendingLocationId { get; set; }
    //    [MaxLength(50)]
    //    public string SendingLocationName { get; set; }
    //    public Guid? SendingBuId { get; set; }
    //    [MaxLength(50)]
    //    public string SendingBuName { get; set; }
    //    public Guid? SendingBuTempId { get; set; }
    //    [MaxLength(50)]
    //    public string SendingBuTempName { get; set; }
    //    [MaxLength(30)]
    //    public string LsdCounty { get; set; }
    //    [MaxLength(20)]
    //    public string OcsgNumber { get; set; }
    //    [MaxLength(200)]
    //    public string Verbiage { get; set; }
    //    public string Comments { get; set; }
    //    [MaxLength(10)]
    //    public string Currency { get; set; }
    //    [MaxLength(25)]
    //    public string VatNo { get; set; }
    //    [MaxLength(5)]
    //    public string SlipType { get; set; }
    //    public string ErrorMessage { get; set; }
    //    [MaxLength(25)]
    //    public string CustomerPoAfe { get; set; }
    //    public string ShipToAddress { get; set; }
    //    [MaxLength(25)]
    //    public string OtherDocInfo { get; set; }
    //    [MaxLength(25)]
    //    public string OtherDocNumber { get; set; }
    //    public bool? IsIntendedUseOnLand { get; set; }
    //    [MaxLength(200)]
    //    public string RentalAgreement { get; set; }
    //    public bool? ShowChildItemOnCommercialInvoice { get; set; }
    //    public Guid? SalesZoneId { get; set; }
    //    public string Consignee { get; set; }
    //    public string ForwardingInstruction { get; set; }
    //    [MaxLength(10)]
    //    public string ErpDocType { get; set; }
    //    [MaxLength(40)]
    //    public string ErpDocNumber { get; set; }
    //    public bool? IsCompleted { get; set; }
    //    public virtual ICollection<CustomerTransferSlipDetail> CustomerTransferSlipDetails { get; set; }
    //}
}