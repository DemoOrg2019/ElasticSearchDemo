﻿using NOV.ES.Framework.Core.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.CustomerTransfer.Domain.Events
{
    public class AddedItemsToCustomerTransferSlip
        : DomainEvent<Guid>
    {
        public CustomerTransferSlipDetail Detail { get; private set; }
        public AddedItemsToCustomerTransferSlip(CustomerTransferSlipDetail detail, long aggregateVersion)
            : base(detail.CustomerTransferSlipId, aggregateVersion)
        {
            EventType = this.GetType().FullName + ", " + this.GetType().Assembly.GetName().Name;
            Detail = detail;
        }
    }
}
