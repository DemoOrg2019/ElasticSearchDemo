﻿using NOV.ES.Framework.Core.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.CustomerTransfer.Domain.Events
{
    public class CreatedCustomerTransferSlipHeader 
        : DomainEvent<Guid>
    {
        public CustomerTransferSlipHeader Header { get; private set; }
        public CreatedCustomerTransferSlipHeader(CustomerTransferSlipHeader header)
            : base(header.CustomerTransferSlipId)
        {
            EventType = this.GetType().FullName + ", " + this.GetType().Assembly.GetName().Name;
            Header = header;
        }
    }
}
