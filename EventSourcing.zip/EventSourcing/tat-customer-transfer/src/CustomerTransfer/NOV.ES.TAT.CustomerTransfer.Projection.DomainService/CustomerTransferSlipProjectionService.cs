﻿using Microsoft.Extensions.Logging;
using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.Framework.Core.Domain;
using NOV.ES.Framework.Core.EventStore;
using NOV.ES.TAT.CustomerTransfer.Domain;
using NOV.ES.TAT.CustomerTransfer.Domain.Events;
using NOV.ES.TAT.CustomerTransfer.Projection.Infrastructure;

namespace NOV.ES.TAT.CustomerTransfer.Projection.DomainService
{
    public class CustomerTransferSlipProjectionService 
        : ICustomerTransferSlipProjectionService
    {
        private readonly ILogger<CustomerTransferSlipProjectionService> logger;
        private readonly IEventStore eventStore;
        private readonly ICustomerTransferSlipProjectionRepository customerTransferSlipProjectionRepository;

        private readonly Dictionary<string, 
            Func<DomainEvent<Guid>, 
                Domain.CustomerTransferSlip, 
                Domain.CustomerTransferSlip>> eventProcessors = 
            new Dictionary<string, 
                Func<DomainEvent<Guid>, 
                    Domain.CustomerTransferSlip,
                     Domain.CustomerTransferSlip>>();

        public CustomerTransferSlipProjectionService(
            ILogger<CustomerTransferSlipProjectionService> logger,
            IEventStore eventStore,
            ICustomerTransferSlipProjectionRepository customerTransferSlipProjectionRepository)
        {
            this.logger = logger;
            this.eventStore = eventStore;
            this.customerTransferSlipProjectionRepository = customerTransferSlipProjectionRepository;

            InitEventProcessors();
        }

        private void InitEventProcessors()
        {
            //eventProcessors = new Dictionary<string, Action>();
            eventProcessors.Add(GetTypeName(typeof(CreatedCustomerTransferSlipHeader)), ProcessCreatedCustomerTransferSlipHeader);
            eventProcessors.Add(GetTypeName(typeof(AddedItemsToCustomerTransferSlip)), ProcessAddedItemsToCustomerTransferSlip);
            //eventProcessors.Add(nameof(CreatedCustomerTransferSlipHeader), ProcessCreatedCustomerTransferSlipHeader);
            //eventProcessors.Add(nameof(AddedItemsToCustomerTransferSlip), ProcessAddedItemsToCustomerTransferSlip);
        }

        private string GetTypeName(Type type)
        {
            return type.FullName + ", " + type.Assembly.GetName().Name;
        }

        public Task CreateCustomerTransferProjectionAsync(Guid customerTransferSlipId)
        {
            //CreatedCustomerTransferSlipHeader headerEvent = new CreatedCustomerTransferSlipHeader(new CustomerTransferSlipHeader());

            // TODO: Ensure a single instnace/Process will be processing CustomerTransferSlipId -- Maintain Status in Table as Processing with TimeStamp
            var existingCustomerTransferSlip = customerTransferSlipProjectionRepository.GetById(customerTransferSlipId).Result;
            var lastSequence = existingCustomerTransferSlip == null ? 0 : existingCustomerTransferSlip.AggregateVersion;

            var events = eventStore.GetEvents(customerTransferSlipId, lastSequence);
            Domain.CustomerTransferSlip customerTransferSlip = existingCustomerTransferSlip;

            if (events != null)
            {
                var sequentialEvents = events.OrderBy(e => e.AggregateVersion);

                foreach (var domainEvent in sequentialEvents)
                {
                    if (eventProcessors.ContainsKey(domainEvent.EventType))
                    {
                        customerTransferSlip = eventProcessors[domainEvent.EventType](domainEvent, customerTransferSlip);
                    }
                }
            }

            if (customerTransferSlip == null)
            {
                return Task.CompletedTask;
            }

            if (existingCustomerTransferSlip == null)
            { 
                 customerTransferSlipProjectionRepository.Create(customerTransferSlip);
                
            }
            else
            {
                 customerTransferSlipProjectionRepository.UpdateCustomerTransferSlip(customerTransferSlip);
            }

            customerTransferSlipProjectionRepository.SaveChanges();

            return Task.CompletedTask;
        }

        protected Domain.CustomerTransferSlip ProcessCreatedCustomerTransferSlipHeader(DomainEvent<Guid> domainEvent, 
            Domain.CustomerTransferSlip customerTransferSlip)
        {
            var newCustomerTransferSlip = new Domain.CustomerTransferSlip();
            CreatedCustomerTransferSlipHeader headerEvent = domainEvent as CreatedCustomerTransferSlipHeader;

            if (headerEvent != null)
            {
                newCustomerTransferSlip.Id = headerEvent.Header.CustomerTransferSlipId;
                newCustomerTransferSlip.AggregateVersion = headerEvent.AggregateVersion;
                newCustomerTransferSlip.CustomerTransferNumber = 1;
                newCustomerTransferSlip.CompanyId = headerEvent.Header.CustomerSalesInfo.CompanyId;
                newCustomerTransferSlip.CompanyName = "";
                newCustomerTransferSlip.SlipDate = headerEvent.Header.CustomerSalesInfo.SlipDate;
                newCustomerTransferSlip.UsageDate = DateTime.Now;
                newCustomerTransferSlip.OilCompanyId = headerEvent.Header.CustomerSalesInfo.SendingBuId;
                newCustomerTransferSlip.OilCompanyName = "";
                newCustomerTransferSlip.ErpJobNumber = headerEvent.Header.CustomerSalesInfo.ErpJobNumber;
                newCustomerTransferSlip.CustomerJobNumber = headerEvent.Header.CustomerSalesInfo.CustomerJobNumber;
                newCustomerTransferSlip.CustomerId = headerEvent.Header.CustomerSalesInfo.CustomerId;
                newCustomerTransferSlip.CustomerName = "";
                newCustomerTransferSlip.EffectiveCustomerId = headerEvent.Header.CustomerSalesInfo.ActualCustomerId;
                newCustomerTransferSlip.EffectiveCustomerName = "";

                newCustomerTransferSlip.BusinessUnitId = headerEvent.Header.CustomerSalesInfo.SendingBuId;
                newCustomerTransferSlip.BusinessUnitName = "";

                newCustomerTransferSlip.HeaderAddress = "";
                newCustomerTransferSlip.HeaderPhone = "";
                newCustomerTransferSlip.HeaderFax = "";
                newCustomerTransferSlip.CustomerContact = headerEvent.Header.CustomerSalesInfo.CustomerContactPerson;
                newCustomerTransferSlip.CustomerPhoneNumber = headerEvent.Header.CustomerSalesInfo.CustomerContactNumber;



                newCustomerTransferSlip.RigId = headerEvent.Header.RigsWellSiteInfo.RigId;
                newCustomerTransferSlip.CorpRigId = null;
                newCustomerTransferSlip.RigName = "";
                newCustomerTransferSlip.RigJDEName = headerEvent.Header.RigsWellSiteInfo.RigJDEName;
                newCustomerTransferSlip.WellSiteId = headerEvent.Header.RigsWellSiteInfo.WellSiteId;
                newCustomerTransferSlip.CorpWellSiteId = null;
                newCustomerTransferSlip.WellName = "";
                newCustomerTransferSlip.WellLocation = "";
                newCustomerTransferSlip.WellNameSource = "";
                newCustomerTransferSlip.DrillingApplicationId = headerEvent.Header.RigsWellSiteInfo.DrillingApplicationId;
                newCustomerTransferSlip.DrillingApplicationName = "";
                newCustomerTransferSlip.BillingApplicationId = headerEvent.Header.RigsWellSiteInfo.BillingApplicationId;
                newCustomerTransferSlip.BillingApplicationName = "";


                newCustomerTransferSlip.ShipVia = "";
                newCustomerTransferSlip.ShippedBy = "";





                newCustomerTransferSlip.FreightTypeId = headerEvent.Header.ShippingInfo.FreightTypeId;
                newCustomerTransferSlip.FreightType = headerEvent.Header.ShippingInfo.FreightType;
                newCustomerTransferSlip.BillOfLading = headerEvent.Header.ShippingInfo.BillOfLading;
                newCustomerTransferSlip.WayBill = headerEvent.Header.ShippingInfo.WayBill;
                newCustomerTransferSlip.GLCode = "";
                        
                newCustomerTransferSlip.SalesPersonId = headerEvent.Header.CustomerSalesInfo.SalesPersonId;
                newCustomerTransferSlip.SalesPersonName = "";
                newCustomerTransferSlip.CheckedBy = headerEvent.Header.ShippingInfo.CheckedBy;
                newCustomerTransferSlip.SendingLocationId = null;
                newCustomerTransferSlip.SendingLocationName = "";
                newCustomerTransferSlip.SendingBuId = headerEvent.Header.CustomerSalesInfo.SendingBuId;
                newCustomerTransferSlip.SendingBuName = "";
                newCustomerTransferSlip.SendingBuTempId = null;
                newCustomerTransferSlip.SendingBuTempName = "";
                newCustomerTransferSlip.LsdCounty = headerEvent.Header.RigsWellSiteInfo.CountyLsd;
                newCustomerTransferSlip.OcsgNumber = headerEvent.Header.RigsWellSiteInfo.OcsgNumber;
                newCustomerTransferSlip.Verbiage = "";
                newCustomerTransferSlip.Comments = headerEvent.Header.CustomerSalesInfo.CommericialInfo.Comments;
                newCustomerTransferSlip.Currency = headerEvent.Header.CustomerSalesInfo.CommericialInfo?.Currency;
                newCustomerTransferSlip.VatNo = headerEvent.Header.CustomerSalesInfo.CommericialInfo?.VatNo;
                newCustomerTransferSlip.SlipType = "";
                newCustomerTransferSlip.ErrorMessage = "";
                newCustomerTransferSlip.CustomerPoAfe = "";
                newCustomerTransferSlip.ShipToAddress = "";
                newCustomerTransferSlip.OtherDocInfo = "";
                newCustomerTransferSlip.OtherDocNumber = "";
                newCustomerTransferSlip.IsIntendedUseOnLand = headerEvent.Header.RigsWellSiteInfo.IsUseIntendOnLand;
                newCustomerTransferSlip.RentalAgreement = "";
                newCustomerTransferSlip.ShowChildItemOnCommercialInvoice = null;
                newCustomerTransferSlip.SalesZoneId = headerEvent.Header.CustomerSalesInfo?.SalesZoneId;
                newCustomerTransferSlip.Consignee = headerEvent.Header.ShippingInfo.ShippingInstruction;
                newCustomerTransferSlip.ForwardingInstruction = headerEvent.Header.ShippingInfo?.ForwardingInstruction;
                newCustomerTransferSlip.ErpDocType = "";
                newCustomerTransferSlip.ErpDocNumber = "";
                newCustomerTransferSlip.IsCompleted = false;

            }
            return newCustomerTransferSlip;
        }

        protected Domain.CustomerTransferSlip ProcessAddedItemsToCustomerTransferSlip(DomainEvent<Guid> domainEvent, 
            Domain.CustomerTransferSlip customerTransferSlip)
        {
                var newCustomerTransferSlip = new Domain.CustomerTransferSlip();
                AddedItemsToCustomerTransferSlip addedItemsToCustomerTransferSlip = domainEvent as AddedItemsToCustomerTransferSlip;

                customerTransferSlip.AggregateVersion = addedItemsToCustomerTransferSlip.AggregateVersion;

                if(customerTransferSlip.CustomerTransferSlipDetails == null)
                {
                    customerTransferSlip.CustomerTransferSlipDetails = new List<Domain.CustomerTransferSlipDetail>();
                }

                foreach(var item in addedItemsToCustomerTransferSlip.Detail.Items)
                {
                    var customerTransferSlipDetail = new Domain.CustomerTransferSlipDetail();
                    //customerTransferSlipDetail.Id = Guid.NewGuid();
                    customerTransferSlipDetail.CustomerTransferId = addedItemsToCustomerTransferSlip.Detail.CustomerTransferSlipId;
                    customerTransferSlipDetail.ItemId = item.ItemId;
                    customerTransferSlipDetail.ErrorMessage = "";
                    customerTransferSlipDetail.IsCompleted = item.IsCompleted;
                    customerTransferSlipDetail.ItemType = "T";
                    customerTransferSlipDetail.LineType = "";

                    customerTransferSlip.CustomerTransferSlipDetails.Add(customerTransferSlipDetail);

                }

                return customerTransferSlip;
            }

    }
}