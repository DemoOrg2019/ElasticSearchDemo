﻿using NOV.ES.TAT.CustomerTransfer.Projection.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.CustomerTransfer.Projection.DomainService
{
    public interface ICustomerTransferSlipProjectionService
    {
        
        Task CreateCustomerTransferProjectionAsync(Guid customerTransferSlipId);
    }
}
