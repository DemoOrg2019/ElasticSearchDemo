﻿using NOV.ES.Framework.Core.Domain;

namespace NOV.ES.TAT.CustomerTransfer.Infrastructure.Interfaces
{
    public interface ICustomerTransferSlipEventSourcingRepository
    {
        long GetAggregateVersion(Guid aggregateRootId,
            long startSequence);
        void Save(AggregateRoot<Guid> aggregateRoot);
    }
}
