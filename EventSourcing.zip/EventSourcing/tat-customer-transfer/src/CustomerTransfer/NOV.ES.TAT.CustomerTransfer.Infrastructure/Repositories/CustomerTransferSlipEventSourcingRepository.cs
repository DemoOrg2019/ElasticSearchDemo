﻿using NOV.ES.Framework.Core.CQRS.Events;
using NOV.ES.Framework.Core.Domain;
using NOV.ES.Framework.Core.EventStore;
using NOV.ES.TAT.CustomerTransfer.Infrastructure.Interfaces;

namespace NOV.ES.TAT.CustomerTransfer.Infrastructure.Repositories
{
    public class CustomerTransferSlipEventSourcingRepository
        : ICustomerTransferSlipEventSourcingRepository
    {
        private readonly IEventStore eventStore;
        private readonly IEventBus eventBus;

        public CustomerTransferSlipEventSourcingRepository(
            IEventStore eventStore,
            IEventBus eventBus)
        {
            this.eventStore = eventStore;
            this.eventBus = eventBus;
        }

        public long GetAggregateVersion(Guid aggregateRootId,
            long startSequence)
        {
            long ver = 0;
            var result = eventStore.GetEvents(aggregateRootId, startSequence);

            if(result != null && result.Count() > 0)
            {
                ver = result.OrderByDescending(x => x.AggregateVersion).First().AggregateVersion;
            }
            return ver;
        }

        public void Save(AggregateRoot<Guid> aggregateRoot)
        {
            var domainEvents = aggregateRoot.UncommittedEvents;
            eventStore.Insert(domainEvents);

            eventBus.Publish(domainEvents.ToArray());

            aggregateRoot.CommitEvents();
        }
    }
}
