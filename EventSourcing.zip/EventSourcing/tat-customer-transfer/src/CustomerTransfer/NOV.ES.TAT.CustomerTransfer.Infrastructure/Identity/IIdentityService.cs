﻿namespace NOV.ES.TAT.CustomerTransfer.Infrastructure;

public interface IIdentityService
{
    string GetUserIdentity();

    string GetUserName();
}

