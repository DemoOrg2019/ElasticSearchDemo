﻿using NOV.ES.Framework.Core.Messaging.IntegrationEvents;

namespace NOV.ES.TAT.CustomerTransfer.Projection.Application.IntegrationEvents
{
    public class AddedItemsToCustomerTransferSlipNotification
        : IntegrationEvent
    {
        public Guid CustomerTransferSlipId { get; init; }

        public AddedItemsToCustomerTransferSlipNotification(Guid cuustomerTransferSlipId)
            => CustomerTransferSlipId = cuustomerTransferSlipId;
    }
}
