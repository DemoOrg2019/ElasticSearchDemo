﻿using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.TAT.CustomerTransfer.Projection.DomainService;

namespace NOV.ES.TAT.CustomerTransfer.Projection.Application.IntegrationEvents
{
    public class AddedItemsToCustomerTransferSlipNotificationHandler
        : IIntegrationEventHandler<AddedItemsToCustomerTransferSlipNotification>
    {
        ILogger<AddedItemsToCustomerTransferSlipNotificationHandler> logger;
        private readonly ICustomerTransferSlipProjectionService customerTransferSlipProjectionService;
        public AddedItemsToCustomerTransferSlipNotificationHandler(
            ILogger<AddedItemsToCustomerTransferSlipNotificationHandler> logger,
            ICustomerTransferSlipProjectionService customerTransferSlipProjectionService)
        {
            this.logger = logger;
            this.customerTransferSlipProjectionService = customerTransferSlipProjectionService;
        }

        public Task Handle(AddedItemsToCustomerTransferSlipNotification @event)
        {
            logger.LogInformation("----- Consuming Event: Added Items to Customer Transfer Slip Integration Event");
            logger.LogInformation("----- Customer Transfer Slip Id is {id}", @event.CustomerTransferSlipId);

            customerTransferSlipProjectionService.CreateCustomerTransferProjectionAsync(@event.CustomerTransferSlipId).Wait();

            return Task.CompletedTask;
        }
    }
}
