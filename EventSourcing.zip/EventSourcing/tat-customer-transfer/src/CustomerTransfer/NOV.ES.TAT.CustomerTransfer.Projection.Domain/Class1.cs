﻿namespace NOV.ES.TAT.CustomerTransfer.Projection.Domain
{
    public class Class1
    {

    }
}