﻿using NOV.ES.Framework.Core.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NOV.ES.TAT.CustomerTransfer.Projection.Domain
{

    [Table("CustomerTransferSlipDetail")]
    public class CustomerTransferSlipDetail : BaseEntity<Guid>
    {
        [Required]
        public Guid CustomerTransferId { get; set; }
        [MaxLength(1)]
        [Required]
        public string ItemType { get; set; }
        [MaxLength(1)]
        [Required]
        public string LineType { get; set; }
        [Required]
        public Guid ItemId { get; set; }
        [MaxLength(30)]
        public string ItemSerialNumber { get; set; }
        [MaxLength(50)]
        public string ItemName { get; set; }
        [MaxLength(100)]
        public string ItemDescription { get; set; }
        public Guid? UsageId { get; set; }
        public Guid? LocationId { get; set; }
        [MaxLength(100)]
        public string LocationName { get; set; }
        public Guid? SizeId { get; set; }
        [MaxLength(10)]
        public string SizeValue { get; set; }
        public Guid? LobeId { get; set; }
        [MaxLength(10)]
        public string Lobe { get; set; }
        public Guid? StageId { get; set; }
        [MaxLength(10)]
        public string Stage { get; set; }
        [Column(TypeName = "decimal(11,3)")]
        public decimal? QuantityShipped { get; set; }
        public string Comments { get; set; }
        public bool? NonInventoryItem { get; set; }
        public bool? IsDisplayOnPrint { get; set; }
        public Guid? TopConnJointTypeId { get; set; }
        [MaxLength(15)]
        public string TopConnJointTypeDesc { get; set; }
        public Guid? TopConnTypeId { get; set; }
        [MaxLength(15)]
        public string TopConnTypeDesc { get; set; }
        public Guid? BottomConnJointTypeId { get; set; }
        [MaxLength(15)]
        public string BottomConnJointTypeDesc { get; set; }
        public Guid? BottomConnTypeId { get; set; }
        [MaxLength(15)]
        public string BottomConnTypeDesc { get; set; }
        public bool? LongTermLease { get; set; }
        public bool? MonthlyLease { get; set; }
        [MaxLength(10)]
        public string Currency { get; set; }
        [DataType(DataType.Currency)]
        public decimal? ItemValue { get; set; }
        public int? CommunityFlag { get; set; }
        [MaxLength(30)]
        public string FieldTicket { get; set; }
        [MaxLength(30)]
        public string RotorHeatNumber { get; set; }
        [MaxLength(30)]
        public string StatorHeatNumber { get; set; }
        public double? RotorOD { get; set; }
        public double? StatorID { get; set; }
        public bool? IsIntendedUseOnLand { get; set; }
        [MaxLength(30)]
        public string BitType { get; set; }
        [MaxLength(15)]
        public string HTS { get; set; }
        public string ErrorMessage { get; set; }
        [MaxLength(25)]
        public string PartNumber { get; set; }
        [MaxLength(100)]
        public string PartDescription { get; set; }
        [MaxLength(25)]
        public string NewPartNumber { get; set; }
        [MaxLength(100)]
        public string NewPartDescription { get; set; }
        [Required]
        public int SequenceNumber { get; set; }
        public bool? IsThresholdOverride { get; set; }
        [MaxLength(100)]
        public string ThresholdOverridenBy { get; set; }
        [MaxLength(5)]
        public string ErpDocType { get; set; }
        [MaxLength(40)]
        public string ErpDocNumber { get; set; }
        [MaxLength(40)]
        public string ErpLocation { get; set; }
        [MaxLength(10)]
        public string ErpLocationZone { get; set; }
        [MaxLength(1)]
        public string ErpLotStatus { get; set; }
        public Guid? LastErpSoftCommitmentId { get; set; }
        public bool? LastActionCompleted { get; set; }
        public bool? IsCompleted { get; set; }

        //        [ForeignKey("CustomerTransferId")]
        // public virtual CustomerTransferSlip CustomerTransferSlip{ get; set; }

    }
}
