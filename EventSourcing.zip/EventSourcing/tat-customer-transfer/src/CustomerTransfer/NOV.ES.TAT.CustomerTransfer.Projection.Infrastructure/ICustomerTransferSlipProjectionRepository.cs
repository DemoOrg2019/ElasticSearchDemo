﻿using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.CustomerTransfer.Projection.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.CustomerTransfer.Projection.Infrastructure
{
    public interface ICustomerTransferSlipProjectionRepository
        : IWriteRepository<CustomerTransferSlip>
    {
        bool UpdateCustomerTransferSlip(CustomerTransferSlip saveCustomerTransferSlip);
        Task<CustomerTransferSlip> GetById(Guid id);
        int SaveChanges();
        Task<int> SaveChangesAsync(CancellationToken cancellationToken);
    }
}
