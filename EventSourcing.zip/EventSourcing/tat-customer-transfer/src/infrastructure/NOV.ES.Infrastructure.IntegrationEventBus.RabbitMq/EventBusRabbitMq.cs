﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NOV.ES.Framework.Core.Extensions;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents.Subscription;
using NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq.Infrastructure;
using System.Text;

namespace NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq
{
    public class EventBusRabbitMq : IIntegrationEventBus
    {
        private readonly ILogger<EventBusRabbitMq> logger;
        private readonly IRabbitMqManager manager;
        private readonly IEventBusSubscriptionsManager subsManager;
        private readonly IServiceProvider serviceProvider;
        private readonly IntegrationEventBusConfig integrationEventBusConfig;
        public EventBusRabbitMq(IOptions<IntegrationEventBusConfig> configs,
            IRabbitMqManager manager,
            IEventBusSubscriptionsManager subsManager,
            ILogger<EventBusRabbitMq> logger,
            IServiceProvider serviceProvider)
        {
            integrationEventBusConfig = configs.Value;
            this.manager = manager;
            this.subsManager = subsManager;
            this.logger = logger;
            this.serviceProvider = serviceProvider;
            this.subsManager.OnEventRemoved += SubsManager_OnEventRemoved;
            this.manager.OnMessageRecieved += _manager_OnMessageRecieved;
        }
        public void Publish(IntegrationEvent @event)
        {
            var eventName = @event.GetType().Name;
            var message = JsonConvert.SerializeObject(@event);
            var body = Encoding.UTF8.GetBytes(message);

            logger.LogTrace("Creating RabbitMQ channel to publish event: {EventId} ({EventName})", @event.Id, eventName);

            // _manager.Publish(body, _exchangeName, EXCHANGE_TYPE, eventName);
            manager.Publish(body, integrationEventBusConfig.BrokerName, integrationEventBusConfig.ExchangeType, eventName);

        }

        public void Subscribe<T, TH>()
            where T : IntegrationEvent
            where TH : IIntegrationEventHandler<T>
        {
            var eventName = subsManager.GetEventKey<T>();
            DoInternalSubscription(eventName);

            logger.LogInformation("Subscribing to event {EventName} with {EventHandler}", eventName, typeof(TH).GetGenericTypeName());

            subsManager.AddSubscription<T, TH>();
            manager.StartBasicConsume(integrationEventBusConfig.QueueName);
        }

        public void SubscribeDynamic<TH>(string eventName) where TH : IDynamicIntegrationEventHandler
        {
            logger.LogInformation("Subscribing to dynamic event {EventName} with {EventHandler}", eventName, typeof(TH).GetGenericTypeName());

            DoInternalSubscription(eventName);
            subsManager.AddDynamicSubscription<TH>(eventName);
            manager.StartBasicConsume(integrationEventBusConfig.QueueName);
        }

        public void UnsubscribeDynamic<TH>(string eventName) where TH : IDynamicIntegrationEventHandler
        {
            subsManager.RemoveDynamicSubscription<TH>(eventName);
        }

        public void Unsubscribe<T, TH>()
            where T : IntegrationEvent
            where TH : IIntegrationEventHandler<T>
        {
            var eventName = subsManager.GetEventKey<T>();

            logger.LogInformation("Unsubscribing from event {EventName}", eventName);

            subsManager.RemoveSubscription<T, TH>();
        }

        private void DoInternalSubscription(string eventName)
        {
            var containsKey = subsManager.HasSubscriptionsForEvent(eventName);
            if (!containsKey)
            {
                manager.DoSubscription(integrationEventBusConfig.QueueName, integrationEventBusConfig.BrokerName, eventName);
            }
        }

        private void SubsManager_OnEventRemoved(object sender, string eventName)
        {
            manager.DoUnSubscription(integrationEventBusConfig.QueueName, integrationEventBusConfig.BrokerName, eventName);
        }
        private async void _manager_OnMessageRecieved(object sender, RabbitMQ.Client.Events.BasicDeliverEventArgs eventArgs)
        {
            var eventName = eventArgs.RoutingKey;
            var messageb64 = Encoding.UTF8.GetString(eventArgs.Body.ToArray());
            byte[] data = Convert.FromBase64String(messageb64.Replace("\"", string.Empty));
            string message = Encoding.UTF8.GetString(data);

            try
            {
                if (message.ToLowerInvariant().Contains("throw-fake-exception"))
                {
                    throw new InvalidOperationException($"Fake exception requested: \"{message}\"");
                }

                await ProcessEvent(eventName, message);
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "----- ERROR Processing message \"{Message}\"", message);
            }

            // Even on exception we take the message off the queue.
            // in a REAL WORLD app this should be handled with a Dead Letter Exchange (DLX). 
            // For more information see: https://www.rabbitmq.com/dlx.html
            // _consumerChannel.BasicAck(eventArgs.DeliveryTag, multiple: false);
            if (subsManager.HasSubscriptionsForEvent(eventName))
            {
                manager.BasicAck(eventArgs.DeliveryTag);
            }
            else
            {
                manager.BasicNack(eventArgs.DeliveryTag);
            }
        }

        private async Task ProcessEvent(string eventName, string message)
        {
            logger.LogTrace("Processing RabbitMQ event: {EventName}", eventName);
            logger.LogTrace("message is: {Message}", message);

            if (subsManager.HasSubscriptionsForEvent(eventName))
            {
                // using (var scope = _autofac.BeginLifetimeScope(AUTOFAC_SCOPE_NAME))
                // {
                var subscriptions = subsManager.GetHandlersForEvent(eventName);
                foreach (var subscription in subscriptions)
                {
                    if (subscription.IsDynamic)
                    {
                        var handler = serviceProvider.GetService(subscription.HandlerType) as IDynamicIntegrationEventHandler; // scope.ResolveOptional(subscription.HandlerType) as IDynamicIntegrationEventHandler;
                        if (handler == null) continue;
                        dynamic eventData = JObject.Parse(message);

                        await Task.Yield();
                        // await handler.Handle(eventData);
                    }
                    else
                    {
                        
                        var handler = serviceProvider.GetService(subscription.HandlerType); //scope.ResolveOptional(subscription.HandlerType);
                        if (handler == null) continue;
                        var eventType = subsManager.GetEventTypeByName(eventName);
                        var integrationEvent = JsonConvert.DeserializeObject(message, eventType);
                        var concreteType = typeof(IIntegrationEventHandler<>).MakeGenericType(eventType);

                        await Task.Yield();
                        await (Task)concreteType.GetMethod("Handle").Invoke(handler, new object[] { integrationEvent });
                    }
                }
                //}
            }
            else
            {
                logger.LogWarning("No subscription for RabbitMQ event: {EventName}", eventName);
            }
        }

        /*
        public async Task Publish<TEvent>(TEvent @event) where TEvent : IEvent
        {
            var eventName = @event.GetType().Name;
            var message = JsonConvert.SerializeObject(@event);
            var body = Encoding.UTF8.GetBytes(message);

            // publish message  
            _manager.Publish(body, eventName, EXCHANGE_TYPE, string.Empty);
        }

        public async Task Publish<TEvent>(params TEvent[] events) where TEvent : IEvent
        {
            foreach (var @event in events)
            {
                await Publish(@event);
            }
        }
        */
    }
}
