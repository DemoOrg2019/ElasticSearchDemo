﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.ObjectPool;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using Polly;
using Polly.Retry;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RabbitMQ.Client.Exceptions;
using System.Net.Sockets;
using System.Text;

namespace NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq.Infrastructure
{
    public class RabbitMqManager : IRabbitMqManager, IDisposable
    {
        private readonly ILogger<RabbitMqManager> logger;
        private readonly DefaultObjectPool<IModel> objectPool;
        private IModel _consumerChannel;
        private const int POOL_COUNT_FACTOR = 2;
        private readonly int _retryCount = 5;
        private bool _disposed;
        public event EventHandler<BasicDeliverEventArgs> OnMessageRecieved;
        private readonly IntegrationEventBusConfig _integrationEventBusConfig;

        public RabbitMqManager(IOptions<IntegrationEventBusConfig> configs, IPooledObjectPolicy<IModel> objectPolicy, ILogger<RabbitMqManager> logger)
        {
            _integrationEventBusConfig = configs.Value;
            objectPool = new DefaultObjectPool<IModel>(objectPolicy, Environment.ProcessorCount * POOL_COUNT_FACTOR);
            CreateConsumerChannel(); //_consumerChannel = _objectPool.Get();
            this.logger = logger;
        }

        public void Publish<T>(T message, string exchangeName, string exchangeType, string routeKey)
            where T : class
        {
            if (message == null)
                return;

            var channel = objectPool.Get();

            try
            {
                // channel.ExchangeDeclare(exchangeName, exchangeType, true, false, null);
                channel.ExchangeDeclare(exchange: exchangeName, type: exchangeType);

                var sendBytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));

                var properties = channel.CreateBasicProperties();
                properties.Persistent = true;

                // channel.QueueBind(_integrationEventBusConfig.QueueName, exchangeName, routeKey);

                var policy = RetryPolicy.Handle<BrokerUnreachableException>()
                .Or<SocketException>()
                .WaitAndRetry(_retryCount, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)), (ex, time) =>
                {
                    logger.LogWarning(ex, "Could not publish event: {EventId} after {Timeout}s ({ExceptionMessage})", exchangeName, $"{time.TotalSeconds:n1}", ex.Message);
                });

                // publish message
                policy.Execute(() =>
                {
                    // channel.BasicPublish(exchangeName, routeKey, properties, sendBytes);
                    channel.BasicPublish(
                        exchange: exchangeName,
                        routingKey: routeKey,
                        mandatory: true,
                        basicProperties: properties,
                        body: sendBytes);
                });
            }
            finally
            {
                objectPool.Return(channel);
            }
        }

        public void DoSubscription(string queueName, string exchangeName, string routeKey)
        {
            //_consumerChannel.QueueBind(queue: queueName,
            //                          exchange: exchangeName,
            //                          routingKey: routeKey);

            var channel = objectPool.Get();
            try
            {
                channel.QueueBind(queue: queueName,
                                      exchange: exchangeName,
                                      routingKey: routeKey);
            }
            finally
            {
                objectPool.Return(channel);
            }
        }

        public void DoUnSubscription(string queueName, string exchangeName, string routeKey)
        {
            //_consumerChannel.QueueUnbind(queue: queueName,
            //                      exchange: exchangeName,
            //                      routingKey: routeKey);

            var channel = objectPool.Get();
            try
            {
                channel.QueueUnbind(queue: queueName,
                                      exchange: exchangeName,
                                      routingKey: routeKey);
            }
            finally
            {
                objectPool.Return(channel);
            }
        }



        public void StartBasicConsume(string queueName)
        {
            logger.LogTrace("Starting RabbitMQ basic consume");

            if (_consumerChannel != null)
            {
                //_consumerChannel.QueueBind(_integrationEventBusConfig.QueueName, _integrationEventBusConfig.BrokerName, routeKey);

                var consumer = new AsyncEventingBasicConsumer(_consumerChannel);

                consumer.Received += Consumer_Received;

                _consumerChannel.BasicConsume(
                    queue: queueName,
                    autoAck: false,
                    consumer: consumer);
            }
            else
            {
                logger.LogError("StartBasicConsume can't call on _consumerChannel == null");
            }
        }

        public void BasicAck(ulong deliveryTag)
        {
            _consumerChannel.BasicAck(deliveryTag, false);
        }

        public void BasicNack(ulong deliveryTag)
        {
            _consumerChannel.BasicNack(deliveryTag, false, true); ;
        }

        private void CreateConsumerChannel()
        {
            _consumerChannel = objectPool.Get();

            _consumerChannel.ExchangeDeclare(exchange: _integrationEventBusConfig.BrokerName, //BROKER_NAME,
                                    type: "direct");

            _consumerChannel.QueueDeclare(queue: _integrationEventBusConfig.QueueName, // _queueName,
                                 durable: true,
                                 exclusive: false,
                                 autoDelete: false,
                                 arguments: null);

            _consumerChannel.CallbackException += (sender, ea) =>
            {
                logger.LogWarning(ea.Exception, "Recreating RabbitMQ consumer channel");

                _consumerChannel.Dispose();
                CreateConsumerChannel();
                StartBasicConsume(_integrationEventBusConfig.QueueName);
            };

        }

        private async Task Consumer_Received(object sender, BasicDeliverEventArgs eventArgs)
        {
            var handler = OnMessageRecieved;
            handler?.Invoke(this, eventArgs);

            await Task.CompletedTask;
        }
        public void Dispose()
        {
            if (_disposed) return;

            _disposed = true;

            objectPool.Return(_consumerChannel);
        }

    }
}
