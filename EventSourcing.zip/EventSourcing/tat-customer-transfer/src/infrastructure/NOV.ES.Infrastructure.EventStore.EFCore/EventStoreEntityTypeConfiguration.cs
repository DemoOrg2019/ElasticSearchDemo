﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace NOV.ES.Infrastructure.EventStore.EFCore
{
    //internal class EventStoreEntityTypeConfiguration<T>
    //    : IEntityTypeConfiguration<EventStoreEntity<T>>
    //    where T : new()
    //{
    //    public void Configure(EntityTypeBuilder<EventStoreEntity<T>> builder)
    //    {
    //        builder.ToTable("EventStore", "dbo");

    //        builder.HasKey(e => e.EventId);
    //        builder.Property(e => e.AggregateRootId).IsRequired();
    //        builder.Property(e => e.AggregateVersion).IsRequired();
    //        builder.Property(e => e.EventType).IsRequired();
    //        builder.Property(e => e.EventDate).IsRequired();
    //        builder.Property(e => e.Data);
    //    }
    //}

    public class EventStoreEntityTypeConfiguration
        : IEntityTypeConfiguration<EventStoreEntity>
    {
        public void Configure(EntityTypeBuilder<EventStoreEntity> builder)
        {
            builder.ToTable("EventStore", "dbo");

            builder.HasKey(e => e.EventId);
            builder.Property(e => e.AggregateRootId).IsRequired();
            builder.Property(e => e.AggregateVersion).IsRequired();
            builder.Property(e => e.EventType).IsRequired();
            builder.Property(e => e.EventDate).IsRequired();
            builder.Property(e => e.Data);
        }
    }
}