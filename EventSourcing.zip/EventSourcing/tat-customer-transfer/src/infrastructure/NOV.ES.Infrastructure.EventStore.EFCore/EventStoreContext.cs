﻿using Microsoft.EntityFrameworkCore;

namespace NOV.ES.Infrastructure.EventStore.EFCore
{
    //public class EventStoreContext<T>
    //    : DbContext
    //    where T : new()
    //{
    //    public const string DEFAULT_SCHEMA = "dbo";

    //    public DbSet<EventStoreEntity<T>> EventStoreEntities { get; set; }


    //    public EventStoreContext(DbContextOptions<EventStoreContext<T>> options)
    //        : base(options)
    //    {
    //    }

    //    protected override void OnModelCreating(ModelBuilder modelBuilder)
    //    {
    //        modelBuilder.ApplyConfiguration(new EventStoreEntityTypeConfiguration<T>());
    //    }
    //}

    public class EventStoreContext
        : DbContext
    {
        public const string DEFAULT_SCHEMA = "dbo";

        public DbSet<EventStoreEntity> EventStoreEntities { get; set; }


        public EventStoreContext(DbContextOptions<EventStoreContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new EventStoreEntityTypeConfiguration());
        }
    }

}

