﻿using NOV.ES.Framework.Core.Entities;
using System.Collections.ObjectModel;
using System.Reflection;

namespace NOV.ES.Framework.Core.Domain
{
    public class AggregateRoot<T>
        : BaseEntity<T>, IAggregateRoot<T>
        where T : new()
    {
        private readonly Queue<DomainEvent<T>> uncommittedEvents = new Queue<DomainEvent<T>>();

        public long LastEventSequence { get; protected internal set; }

        public ReadOnlyCollection<DomainEvent<T>> UncommittedEvents
        {
            get { return new ReadOnlyCollection<DomainEvent<T>>(uncommittedEvents.ToList()); }
        }

        public void LoadFromHistoricalEvents(params IDomainEvent<T>[] domainEvents)
        {
            if (domainEvents.Length == 0) return;

            var domainEventList = domainEvents.OrderBy(domainEvent => domainEvent.AggregateVersion).ToList();
            LastEventSequence = domainEventList.Last().AggregateVersion;

            domainEventList.ForEach(ApplyEventToInternalState);
        }

        public void Apply(DomainEvent<T> domainEvent)
        {
            domainEvent.AggregateVersion = ++LastEventSequence;
            ApplyEventToInternalState(domainEvent);
            domainEvent.AggregateRootId = Id;
            // domainEvent.EventDate = DateTime.Now;

            // EventModifier.Modify(domainEvent);

            uncommittedEvents.Enqueue(domainEvent);
        }

        public void CommitEvents()
        {
            uncommittedEvents.Clear();
        }

        private void ApplyEventToInternalState(IDomainEvent<T> domainEvent)
        {
            var domainEventType = domainEvent.GetType();
            var domainEventTypeName = domainEventType.FullName; // domainEventType.Name;
            var aggregateRootType = GetType();

            var eventHandlerMethodName = GetEventHandlerMethodName(domainEventTypeName);
            var methodInfo = aggregateRootType.GetMethod(eventHandlerMethodName,
                                                         BindingFlags.Instance | BindingFlags.Public |
                                                         BindingFlags.NonPublic, null, new[] { domainEventType }, null);

            if (methodInfo != null && EventHandlerMethodInfoHasCorrectParameter(methodInfo, domainEventType))
            {
                methodInfo.Invoke(this, new[] { domainEvent });
            }


            // ApplyEventToEntities(domainEvent);
        }

        private static string GetEventHandlerMethodName(string domainEventTypeName)
        {
            var eventIndex = domainEventTypeName.LastIndexOf("Event");
            return "On" + (eventIndex < 0 ? domainEventTypeName : domainEventTypeName.Remove(eventIndex, 5));
        }

        private static bool EventHandlerMethodInfoHasCorrectParameter(MethodInfo eventHandlerMethodInfo, Type domainEventType)
        {
            var parameters = eventHandlerMethodInfo.GetParameters();
            return parameters.Length == 1 && parameters[0].ParameterType == domainEventType;
        }
    }
}
