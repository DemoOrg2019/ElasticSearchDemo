﻿using Microsoft.EntityFrameworkCore;
using NOV.ES.Framework.Core.Entities;

namespace NOV.ES.Framework.Core.Data
{
    public class BaseContext : DbContext
    {
        public BaseContext(DbContextOptions options) : base(options) { }
        public virtual string UserProvider { get; set; }
        public override int SaveChanges()
        {
            TrackChanges();
            return base.SaveChanges();
        }
        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = new CancellationToken())
        {
            TrackChanges();
            return await base.SaveChangesAsync(cancellationToken);
        }
        public Func<DateTime> TimestampProvider { get; set; } = ()
             => DateTime.UtcNow;
        private void TrackChanges()
        {
            foreach (var entry in ChangeTracker.Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified))
            {
                if (entry.Entity is IAuditEntity )
                {
                    var auditable = entry.Entity as IAuditEntity;

                    if (entry.State == EntityState.Added)
                    {
                        auditable.CreatedBy = UserProvider;
                        auditable.ModifiedBy = UserProvider;
                        auditable.DateCreated = TimestampProvider();
                        auditable.DateModified = TimestampProvider();
                    }
                    else
                    {
                        auditable.ModifiedBy = UserProvider;
                        auditable.DateModified = TimestampProvider();
                    }
                }
            }
        }
    }
}
