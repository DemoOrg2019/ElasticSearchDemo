﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.Caching;
using StackExchange.Redis;

namespace NOV.ES.Infrastructure.Caching.Redis
{
    public class RedisCache : ICache
    {
        private readonly ILogger<RedisCache> _logger;
        private readonly RedisSettings _config;
        private readonly ConnectionMultiplexer _connection;
        private readonly IDatabase _cache;

        public RedisCache(IOptions<RedisSettings> configs, ILogger<RedisCache> logger)
        {
            _config = configs.Value;
            _logger = logger;
            _connection = GetConnection();
            _cache = _connection.GetDatabase();
        }

        /// <summary>
        /// Get all keys
        /// </summary>
        /// <returns></returns>
        public IEnumerable<RedisKey> GetAllCacheKeys()
        {
            var server = GetDataCacheServer();

            var keys = server.Keys();
            return keys;
        }

        /// <summary>
        /// Add the value and set expiration
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <param name="expiration"></param>
        public void Add(string key, object value, TimeSpan expiration)
        {
            // get key
            string serialized = JsonConvert.SerializeObject(value);
            _cache.StringSet(key, serialized);
        }

        /// <summary>
        /// Add the value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void Add(string key, object value)
        {
            // get key
            string serialized = JsonConvert.SerializeObject(value);
            _cache.StringSet(key, serialized);
        }

        /// <summary>
        /// Get the value by key
        /// </summary>
        /// <typeparam name="TItem"></typeparam>
        /// <param name="key"></param>
        /// <returns></returns>
        public TItem Get<TItem>(string key)
        {
            string value = _cache.StringGet(key);

            return JsonConvert.DeserializeObject<TItem>(value);
        }

        /// <summary>
        /// remove specific key
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool Remove(string key)
        {
            bool isSuccess = false;

            try
            {
                isSuccess = _cache.KeyDelete(key);
            }
            catch
            {

            }

            return isSuccess;
        }

        /// <summary>
        /// Remove all from the cache
        /// </summary>
        public void RemoveAll()
        {
            IEnumerable<RedisKey> keys = GetAllCacheKeys();
            foreach (RedisKey redisKey in keys)
            {
                _cache.KeyDelete(redisKey);
            }
        }


        /// <summary>
        /// Remove all from the cache
        /// </summary>
        public void RemoveAll(string serverTypePrefix)
        {
            IEnumerable<RedisKey> keys = GetAllCacheKeys();
            foreach (RedisKey redisKey in keys)
            {
                string keyName = redisKey.ToString();
                if (keyName.StartsWith(serverTypePrefix) == true)
                {
                    _cache.KeyDelete(redisKey);
                }
            }
        }

        private ConnectionMultiplexer GetConnection()
        {
            return ConnectionMultiplexer.Connect(_config.ConnectionSting);
        }

        private IServer GetDataCacheServer()
        {

            var endpoints = _connection.GetEndPoints();
            var server = _connection.GetServer(endpoints.First());

            return server;
        }
    }
}
