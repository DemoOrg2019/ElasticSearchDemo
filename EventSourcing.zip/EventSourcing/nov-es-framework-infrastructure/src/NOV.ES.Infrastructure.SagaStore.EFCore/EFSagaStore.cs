﻿using NOV.ES.Framework.Core.Sagas.Store;

namespace NOV.ES.Infrastructure.SagaStore.EFCore
{
    public class EFSagaStore : ISagaStore
    {
        private readonly SagaStoreContext context;

        public EFSagaStore(SagaStoreContext context)
        {
            this.context = context;
        }

        public Task<IEnumerable<SagaEventEntity>> GetSagaEvent(Guid sagaEventId)
        {
            var result = context.SagaEventEntities
                .Where(se => se.CorelationId == sagaEventId);

            return Task.FromResult(result.ToList().AsEnumerable());
        }

        public Task SaveSagaEvent(SagaEventEntity eventEntry)
        {
            context.SagaEventEntities.Add(eventEntry);
            context.SaveChanges();

            return Task.CompletedTask;
        }
    }
}
