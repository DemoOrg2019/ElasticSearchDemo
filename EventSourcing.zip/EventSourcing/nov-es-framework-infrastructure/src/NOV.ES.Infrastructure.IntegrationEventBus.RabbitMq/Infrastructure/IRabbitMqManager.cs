﻿using RabbitMQ.Client.Events;

namespace NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq.Infrastructure
{
    public interface IRabbitMqManager
    {
        void Publish<T>(T message, string exchangeName, string exchangeType, string routeKey)
        where T : class;

        void DoSubscription(string queueName, string exchangeName, string routeKey);
        void DoUnSubscription(string queueName, string exchangeName, string routeKey);
        void BasicAck(ulong deliveryTag);
        void BasicNack(ulong deliveryTag);
        void StartBasicConsume(string queueName);

        event EventHandler<BasicDeliverEventArgs> OnMessageRecieved;
    }
}
