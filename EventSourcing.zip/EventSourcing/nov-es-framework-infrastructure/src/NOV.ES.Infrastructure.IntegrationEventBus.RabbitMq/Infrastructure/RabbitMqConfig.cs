﻿namespace NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq.Infrastructure
{
    public class RabbitMqConfig
    {
        public RabbitMqConnection RabbitMqConnection { get; set; }
        public string Topic { get; set; }
    }
}
