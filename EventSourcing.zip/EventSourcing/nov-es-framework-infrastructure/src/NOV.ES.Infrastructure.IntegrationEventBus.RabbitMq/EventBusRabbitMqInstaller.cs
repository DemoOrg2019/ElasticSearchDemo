﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.ObjectPool;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents.Subscription;
using NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq.Infrastructure;
using RabbitMQ.Client;

namespace NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq
{
    public static class EventBusRabbitMqInstaller
    {
        public static IServiceCollection AddRabbitMqEventBus(this IServiceCollection services, IConfiguration configuration, string integrationEventBusConfigKey, string rabbitMqConfigKey)
        {
            var integrationEventBusConfig = configuration.GetSection(integrationEventBusConfigKey);
            var rabbitConfig = configuration.GetSection(rabbitMqConfigKey);

            services.Configure<IntegrationEventBusConfig>(integrationEventBusConfig);
            services.Configure<RabbitMqConfig>(rabbitConfig);

            services.AddSingleton<ObjectPoolProvider, DefaultObjectPoolProvider>();
            services.AddSingleton<IPooledObjectPolicy<IModel>, RabbitMqModelPooledObjectPolicy>();
            services.AddSingleton<IEventBusSubscriptionsManager, InMemoryEventBusSubscriptionsManager>();


            services.AddSingleton<IRabbitMqManager, RabbitMqManager>();

            return services;
        }

    }
}
