﻿using NOV.ES.Framework.Core.Domain;
using NOV.ES.Framework.Core.EventStore;
using NOV.ES.Framework.Core.Extensions;
using NOV.ES.Framework.Core.Serializer;

namespace NOV.ES.Infrastructure.EventStore.EFCore
{
    public class EFEventStore<T>
        : IEventStore<T>
        where T : new()
    {
        private readonly EventStoreContext<T> context;
        private readonly IDomainEventSerializer<T> serializer;

        public EFEventStore(EventStoreContext<T> context,
            IDomainEventSerializer<T> serializer)
        {
            this.context = context;
            this.serializer = serializer;
        }



        public IEnumerable<DomainEvent<T>> GetEvents(T aggregateRootId,
            long startSequence)
        {
            var result = context.EventStoreEntities
                .Where(es => es.AggregateRootId.Equals(aggregateRootId) &&
                es.AggregateVersion == startSequence);

            return result.ToList();
        }

        public IEnumerable<DomainEvent<T>> GetEventsByEventTypes(IEnumerable<Type> domainEventTypes)
        {
            var eventParameters = domainEventTypes.Select(e => e.GetTypeString()).ToList();

            var result = context.EventStoreEntities
                .Where(es => eventParameters.Contains(es.EventType));

            return result.ToList();
        }

        public IEnumerable<DomainEvent<T>> GetEventsByEventTypes(IEnumerable<Type> domainEventTypes, Guid aggregateRootId)
        {
            var eventParameters = domainEventTypes.Select(e => e.GetTypeString()).ToList();

            var result = context.EventStoreEntities
                .Where(es => es.AggregateRootId.Equals(aggregateRootId) &&
                eventParameters.Contains(es.EventType));

            return result.ToList();
        }

        public IEnumerable<DomainEvent<T>> GetEventsByEventTypes(IEnumerable<Type> domainEventTypes, DateTime startDate, DateTime endDate)
        {
            var eventParameters = domainEventTypes.Select(e => e.GetTypeString()).ToList();

            var result = context.EventStoreEntities
                .Where(es => eventParameters.Contains(es.EventType)
                && (es.EventDate >= startDate && es.EventDate <= endDate));

            return result.ToList();

        }

        public void Insert(IEnumerable<DomainEvent<T>> domainEvents)
        {
            foreach (var domainEvent in domainEvents)
            {
                context.EventStoreEntities.Add(new EventStoreEntity<T>()
                {
                    EventId = domainEvent.EventId,
                    EventType = domainEvent.EventType,
                    AggregateRootId = domainEvent.AggregateRootId,
                    AggregateVersion = domainEvent.AggregateVersion,
                    Data = serializer.Serialize(domainEvent),
                    EventDate = DateTime.UtcNow
                });
            }

            context.SaveChanges();
        }
    }
}
