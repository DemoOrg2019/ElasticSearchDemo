﻿using NOV.ES.Framework.Core.Domain;

namespace NOV.ES.Infrastructure.EventStore.EFCore
{
    public class EventStoreEntity<T>
        : DomainEvent<T>
        where T : new()
    {
        public string Data { get; set; }

        public EventStoreEntity()
        {

        }

        public EventStoreEntity(Guid eventId, string eventType, T aggregateRootId, long aversion, string data)
        {
            this.EventId = eventId;
            this.EventType = eventType;
            this.AggregateRootId = aggregateRootId;
            this.AggregateVersion = aversion;
            this.EventDate = DateTime.UtcNow;
            this.Data = data;
        }
    }
}
