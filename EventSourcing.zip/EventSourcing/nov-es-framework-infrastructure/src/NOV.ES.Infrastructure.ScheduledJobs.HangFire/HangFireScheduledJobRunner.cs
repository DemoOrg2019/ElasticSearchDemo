﻿using NOV.ES.Framework.Core.ScheduledJobs;

namespace NOV.ES.Infrastructure.ScheduledJobs.HangFire
{
    public class HangFireScheduledJobRunner : IHangFireScheduledJobRunner
    {
        private readonly IScheduledJobRunner scheduledJobRunner;

        public HangFireScheduledJobRunner(IScheduledJobRunner scheduledJobRunner)
        {
            this.scheduledJobRunner = scheduledJobRunner;
        }

        public void Execute(string scheduledJobName, int version, string scheduledJobJson)
        {
            scheduledJobRunner.Execute(scheduledJobName, version, scheduledJobJson);
        }
    }
}
