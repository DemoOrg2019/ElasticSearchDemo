﻿using Hangfire;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.ScheduledJobs;
using NOV.ES.Framework.Core.ScheduledJobs.Attributes;
using System.Reflection;

namespace NOV.ES.Infrastructure.ScheduledJobs.HangFire
{
    public class HangfireScheduledJobScheduler : IScheduledJobScheduler
    {
        private readonly ILogger<HangfireScheduledJobScheduler> logger;
        private readonly IBackgroundJobClient backgroundJobClient;
        private readonly IScheduledJobRegistry scheduledJobRegistry;

        public HangfireScheduledJobScheduler(ILogger<HangfireScheduledJobScheduler> logger,
            IBackgroundJobClient backgroundJobClient,
            IScheduledJobRegistry scheduledJobRegistry)
        {
            this.logger = logger;
            this.backgroundJobClient = backgroundJobClient;
            this.scheduledJobRegistry = scheduledJobRegistry;
        }

        public Task<Guid> ScheduleAsync(IScheduledJob scheduledJob, DateTimeOffset runAt, CancellationToken cancellationToken)
        {
            return ScheduleAsync(
                scheduledJob,
                cancellationToken,
                (c, d, j) => backgroundJobClient.Schedule<IHangFireScheduledJobRunner>(r => r.Execute(d.Name, d.Version, j), runAt));
        }

        public Task<Guid> ScheduleAsync(IScheduledJob scheduledJob, TimeSpan delay, CancellationToken cancellationToken)
        {
            return ScheduleAsync(
                scheduledJob,
                cancellationToken,
                (c, d, j) => backgroundJobClient.Schedule<IHangFireScheduledJobRunner>(r => r.Execute(d.Name, d.Version, j), delay));
        }

        public Task<Guid> ScheduleNowAsync(IScheduledJob scheduledJob, CancellationToken cancellationToken)
        {
            return ScheduleAsync(
               scheduledJob,
               cancellationToken,
               (c, d, j) => backgroundJobClient.Enqueue<IHangFireScheduledJobRunner>(r => r.Execute(d.Name, d.Version, j)));
        }

        private async Task<Guid> ScheduleAsync(
            IScheduledJob scheduledJob,
            CancellationToken cancellationToken,
            Func<IBackgroundJobClient, ScheduledJobDefinition, string, string> schedule)
        {


            var scheduledJobDefinition = scheduledJobRegistry.GetScheduledDefinition(scheduledJob.GetType());

            var jsonSerializerSettings = new JsonSerializerSettings()
            {
                TypeNameHandling = TypeNameHandling.All
            };

            var scheduledJobJson = JsonConvert.SerializeObject(scheduledJob);

            var attribute = (ScheduledJobAttribute)scheduledJob.GetType().GetCustomAttributes(typeof(ScheduledJobAttribute)).FirstOrDefault();

            var id = schedule(backgroundJobClient, scheduledJobDefinition, scheduledJobJson);

            return Guid.Parse(id);
        }
    }
}
