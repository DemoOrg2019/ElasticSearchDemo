# nov-es-framework-infrastructure
This repository contains building blocks Microservice based architecture in .NET 6
