﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NOV.ES.Framework.Core.Sagas.Store;

namespace NOV.ES.Infrastructure.SagaStore.EFCore
{
    internal class SagaEventEntityTypeConfiguration : IEntityTypeConfiguration<SagaEventEntity>
    {
        public void Configure(EntityTypeBuilder<SagaEventEntity> builder)
        {
            builder.ToTable("SagaEventStore", SagaStoreContext.DEFAULT_SCHEMA);

            builder.HasKey(e => e.RowId);
            builder.Property(e => e.RowId).ValueGeneratedOnAdd();
            builder.Property(e => e.CorelationId).IsRequired();
            builder.Property(e => e.SourceEventId).IsRequired();
            builder.Property(e => e.KeyId);
            builder.Property(e => e.SagaEventTypeName).IsRequired();
            builder.Property(e => e.Data).IsRequired();
            builder.Property(e => e.ExecutionResult);
            builder.Property(e => e.Status).IsRequired();
            builder.Property(e => e.TimeStamp);
            builder.Property(e => e.ActionBy).IsRequired();
        }
    }
}
