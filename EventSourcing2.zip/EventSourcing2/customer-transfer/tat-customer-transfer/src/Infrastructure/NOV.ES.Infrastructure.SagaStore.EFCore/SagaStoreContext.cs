﻿using Microsoft.EntityFrameworkCore;
using NOV.ES.Framework.Core.Sagas.Store;

namespace NOV.ES.Infrastructure.SagaStore.EFCore
{
    public class SagaStoreContext : DbContext
    {
        public const string DEFAULT_SCHEMA = "dbo";
        public DbSet<SagaEventEntity> SagaEventEntities { get; set; }

        public SagaStoreContext(DbContextOptions<SagaStoreContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new SagaEventEntityTypeConfiguration());
        }
    }
}
