﻿namespace NOV.ES.Infrastructure.Caching.Redis
{
    public class RedisSettings
    {
        public string ConnectionSting { get; set; }
    }
}
