﻿using RabbitMQ.Client;

namespace NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq.Infrastructure
{
    public interface IRabbitMQPersistentConnection
        : IDisposable
    {
        bool IsConnected { get; }

        bool TryConnect();

        IModel Create();
    }
}
