﻿namespace NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq.Infrastructure
{
    public class RabbitMqConnection
    {
        public string HostName { get; set; } // "HostName": "localhost",
        public string Username { get; set; } // "Username": "guest",
        public string Password { get; set; } //"Password": "guest",
        public string VirtualHost { get; set; } //"VirtualHost": "/",
        public bool AutomaticRecoveryEnabled { get; set; } //"AutomaticRecoveryEnabled": true,
        public int RequestedHeartbeat { get; set; } //"RequestedHeartbeat": 30
    }

}
