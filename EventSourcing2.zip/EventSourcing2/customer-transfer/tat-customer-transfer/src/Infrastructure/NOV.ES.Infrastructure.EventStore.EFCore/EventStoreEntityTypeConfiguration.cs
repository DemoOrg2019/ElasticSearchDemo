﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace NOV.ES.Infrastructure.EventStore.EFCore
{
    internal class EventStoreEntityTypeConfiguration
        : IEntityTypeConfiguration<EventStoreEntity>
    {
        public void Configure(EntityTypeBuilder<EventStoreEntity> builder)
        {
            builder.ToTable("EventStore", "dbo");

            builder.HasKey(e => e.EventId);
            builder.Property(e => e.AggregateRootId).IsRequired();
            builder.Property(e => e.AggregateVersion).IsRequired();
            builder.Property(e => e.EventType).IsRequired();
            builder.Property(e => e.EventDate).IsRequired();
            builder.Property(e => e.Data);
            builder.Property(e => e.ActionBy).IsRequired();
            builder.Property(e => e.ClientAppId).IsRequired(false);
            builder.Property(e => e.RequestId).IsRequired(false);
        }
    }
}