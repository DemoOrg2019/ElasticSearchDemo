﻿using NOV.ES.Framework.Core.Domain;

namespace NOV.ES.Infrastructure.EventStore.EFCore
{
    public class EventStoreEntity
        : DomainEvent<Guid>
    {
        public string Data { get; set; }

        public EventStoreEntity()
        {

        }

        public EventStoreEntity(Guid eventId, string eventType, Guid aggregateRootId, 
            long aversion, string data, string actionBy="",
            Guid? clientAppId = null, Guid? requestId = null)
        {
            this.EventId = eventId;
            this.EventType = eventType;
            this.AggregateRootId = aggregateRootId;
            this.AggregateVersion = aversion;
            this.EventDate = DateTime.UtcNow;
            this.Data = data;
            this.ActionBy = actionBy;
            this.ClientAppId = clientAppId;
            this.RequestId = requestId;
        }
    }
}
