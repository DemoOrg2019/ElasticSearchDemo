﻿namespace NOV.ES.Infrastructure.ScheduledJobs.HangFire
{
    public interface IHangFireScheduledJobRunner
    {
        void Execute(string scheduledJobName, int version, string scheduledJobJson);
    }
}
