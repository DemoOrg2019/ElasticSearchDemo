﻿using Microsoft.AspNetCore.Http;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using NOV.ES.Infrastructure.EventStore.EFCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Claims;

namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.Test
{
    public class TestBase : IDisposable
    {
        public EventStoreContext EventStoreContext { get; set; }
        public TestBase()
        {
            EventStoreContext = CreateDbContext();
        }

        private EventStoreContext CreateDbContext()
        {
            return new EventStoreContext(CreateDbContextOptions<EventStoreContext>());
        }

        private static HttpContextAccessor GetHttpContextAccessor()
        {
            HttpContextAccessor httpContextAccessor = new HttpContextAccessor();
            httpContextAccessor.HttpContext = new DefaultHttpContext()
            {
                User = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, "Test User"),
                    new Claim(ClaimTypes.Role, "Role")
                }))
            };
            return httpContextAccessor;
        }

        public DbContextOptions<T> CreateDbContextOptions<T>() where T : EventStoreContext
        {
            var connection = new SqliteConnection("DataSource=:memory:");
            connection.Open();
            connection.CreateFunction("newid", () => { return Guid.NewGuid(); });
            return new DbContextOptionsBuilder<T>().UseSqlite(connection).Options;

        }
        public IEnumerable<T> DeserializeJsonToObject<T>(string jsonDataPath)
        {
            return JsonConvert.DeserializeObject<List<T>>
                           (File.ReadAllText(jsonDataPath)) ?? new List<T>();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            EventStoreContext.Dispose();
        }
    }

}
