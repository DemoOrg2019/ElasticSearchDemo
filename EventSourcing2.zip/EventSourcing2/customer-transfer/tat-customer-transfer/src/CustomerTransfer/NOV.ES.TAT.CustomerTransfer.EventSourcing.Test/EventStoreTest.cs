﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.Framework.Core.CQRS.Events;
using NOV.ES.Framework.Core.EventStore;
using NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.Commands;
using NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Controllers;
using NOV.ES.TAT.CustomerTransfer.EventSourcing.Infrastructure;
using NOV.ES.TAT.CustomerTransfer.EventSourcing.Test;
using System;
using System.Net;
using System.Net.Mime;
using System.Threading.Tasks;

namespace NOV.ES.TAT.Admin.Test
{
    [TestClass]
    public class EventStoreTest : TestBase
    {
        private CustomerTransferSlipsController customerTransferSlipsController;
        private readonly ILogger<CustomerTransferSlipsController> logger;
        public EventStoreTest() : base()
        {
            logger = new Mock<ILogger<CustomerTransferSlipsController>>().Object;
            ICommandBus commandBus = new Mock<ICommandBus>().Object;
            customerTransferSlipsController = new CustomerTransferSlipsController(logger, commandBus);
        }

        [TestInitialize]
        public void SetUp()
        {
            ClearAndSeedTestData();
        }

        #region Controller unit Tests

        [TestMethod]
        public void ShouldReturnsServiceNameWithOkStatus_ServiceName()
        {
            var result = customerTransferSlipsController.ServiceName();

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            Assert.AreEqual("CustomerTransferSlips EventStore CustomerTransfer Service.", ((OkObjectResult)result).Value);
        }

        [TestMethod]
        public async Task ShouldReturnsOkObjectResultForGivenValidInput_AddCustomerTransferSlipHeader()
        {
            Mock<ICommandBus> mockCommandBus = new Mock<ICommandBus>();
            ContentResult contentResult = new()
            {
                ContentType = MediaTypeNames.Application.Json,
                StatusCode = (int)HttpStatusCode.OK
            };
            mockCommandBus.Setup(x => x.Send<CreateCustomerTransferSlipHeaderCommand, ContentResult>(It.IsNotNull<CreateCustomerTransferSlipHeaderCommand>()))
                .ReturnsAsync(contentResult);

            ICommandBus commandBus = mockCommandBus.Object;

            customerTransferSlipsController = new CustomerTransferSlipsController(logger, commandBus);

            CreateCustomerTransferSlipHeaderCommand createCustomerTransferSlipHeaderCommand = new CreateCustomerTransferSlipHeaderCommand();
            var result = await customerTransferSlipsController.AddCustomerTransferSlipHeader(createCustomerTransferSlipHeaderCommand);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
        }

        #endregion

        #region Repository

        [TestMethod]
        public void ShouldCreateEventForGivenData_Save()
        {
            try
            {
                Mock<IEventStore> mockEventStore = new Mock<IEventStore>();
                Mock<IEventBus> mockIEventBus = new Mock<IEventBus>();
                Mock<CustomerTransferSlipEventSourcingRepository> mockCustomerTransferSlipEventSourcingRepository =
                new Mock<CustomerTransferSlipEventSourcingRepository>(mockEventStore, mockIEventBus);

                //mockCustomerTransferSlipEventSourcingRepository
                //    .Setup(x => x.Save(mockAggregateRoot));

                Assert.IsTrue(true);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        #endregion


        [TestCleanup]
        public void TestCleanup()
        {
            Dispose();
        }

        private void ClearAndSeedTestData()
        {
            EventStoreContext.Database.EnsureDeleted();
            EventStoreContext.Database.EnsureCreated();
        }
    }
}