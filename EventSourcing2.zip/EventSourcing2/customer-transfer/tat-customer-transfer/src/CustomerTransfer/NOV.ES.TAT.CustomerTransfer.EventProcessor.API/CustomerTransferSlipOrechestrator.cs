﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.Framework.Core.Sagas.Store;
using NOV.ES.TAT.CustomerTransfer.EventProcessor.API.SagaEvents.PublishEvents;
using NOV.ES.TAT.CustomerTransfer.EventProcessor.API.SagaEvents.SubscribedEvents;

namespace NOV.ES.TAT.CustomerTransfer.EventProcessor.API
{
    public class CustomerTransferSlipOrechestrator
         : SagaOrchestratorBase,
           IIntegrationEventHandler<CreatedCustomerTransferHeaderProjectionAuditSaveSuccess>
    {
        public CustomerTransferSlipOrechestrator(ILogger<CustomerTransferSlipOrechestrator> logger,
            IIntegrationEventBus integrationEventBus,
            ISagaStore sagaStore)
            : base(logger, integrationEventBus, sagaStore)
        {
            
        }

        public Task Handle(CreatedCustomerTransferHeaderProjectionAuditSaveSuccess @event)
        {
            logger.LogInformation($"---- Handling Saga Start Event: { @event.Id} at CustomerTransferSlipOrechestrator.");
            logger.LogInformation($"---- Event Detail: {@event}");

            // Publish Save Customer Transfer Header Event Info Command
            //CreateCustomerTransferHeaderEventInfo eventInfo = new(
            //    @event.EventMasterId,
            //    @event.CustomerTransferSlipId,
            //    @event.ChangeDetailJson,
            //    @event.EventDate,
            //    @event.ActionBy);

            //eventInfo.CorelationId = @event.CorelationId;
            //eventInfo.SagaEventExecutionResult = @event.SagaEventExecutionResult;
            //eventInfo.JsonStringData = JsonConvert.SerializeObject(eventInfo);

            ProcessSagaEvent(@event.GetType().Name, @event, typeof(CreatedCustomerTransferHeaderProjectionAuditSaveSuccess));

            return Task.CompletedTask;
        }
    }
}
