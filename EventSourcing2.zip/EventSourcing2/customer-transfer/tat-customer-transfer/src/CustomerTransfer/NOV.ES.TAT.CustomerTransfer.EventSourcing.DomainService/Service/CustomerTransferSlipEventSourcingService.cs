﻿using NOV.ES.Framework.Core.Domain;
using NOV.ES.TAT.CustomerTransfer.EventSourcing.Infrastructure;

namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.DomainService
{
    public class CustomerTransferSlipEventSourcingService
         : ICustomerTransferSlipEventSourcingService
    {
        private readonly ICustomerTransferSlipEventSourcingRepository customerTransferSlipEventSourcingRepository;

        public CustomerTransferSlipEventSourcingService(
            ICustomerTransferSlipEventSourcingRepository customerTransferSlipEventSourcingRepository)
        {
            this.customerTransferSlipEventSourcingRepository = customerTransferSlipEventSourcingRepository;            
        }

        public long GetAggregateVersion(Guid aggregateRootId, long startSequence)
        {
            return customerTransferSlipEventSourcingRepository.GetAggregateVersion(aggregateRootId, startSequence);
        }

        public void Save(AggregateRoot<Guid> aggregateRoot)
        {
            customerTransferSlipEventSourcingRepository.Save(aggregateRoot);
        }
    }
}