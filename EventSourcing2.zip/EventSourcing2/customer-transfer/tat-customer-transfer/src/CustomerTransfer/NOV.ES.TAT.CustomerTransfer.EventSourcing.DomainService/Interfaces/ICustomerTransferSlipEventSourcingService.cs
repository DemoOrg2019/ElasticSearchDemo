﻿using NOV.ES.Framework.Core.Domain;

namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.DomainService
{
    public interface ICustomerTransferSlipEventSourcingService
    {
        long GetAggregateVersion(Guid aggregateRootId,
              long startSequence);
        void Save(AggregateRoot<Guid> aggregateRoot);
    }
}
