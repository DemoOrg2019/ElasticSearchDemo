﻿using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure.Helper;

namespace NOV.ES.TAT.CustomerTransfer.Search.Infrastructure
{
    public interface ICustomerTransferSlipQueryRepository
        : IReadRepository<CustomerTransferSlip>
    {
        IQueryable<CustomerTransferSlip> GetCustomerTransferSlip(SearchRequest searchRequest);
        IQueryable<string> GetDistinctCreatedBy();
    }
}
