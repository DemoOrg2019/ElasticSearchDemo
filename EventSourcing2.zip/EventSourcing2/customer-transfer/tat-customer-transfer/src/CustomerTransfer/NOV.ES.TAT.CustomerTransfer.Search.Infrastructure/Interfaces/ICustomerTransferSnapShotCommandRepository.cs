﻿using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;

namespace NOV.ES.TAT.CustomerTransfer.Search.Infrastructure
{
    public interface ICustomerTransferSnapShotCommandRepository
        : IWriteRepository<CustomerTransferSnapShot>
    {
        public int SaveChanges();
        public Task<int> SaveChangesAsync(CancellationToken cancellationToken);
    }
}
