﻿using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;

namespace NOV.ES.TAT.CustomerTransfer.Search.Infrastructure
{
    public interface ICustomerTransferSlipDetailQueryRepository
        : IReadRepository<CustomerTransferSlipDetail>
    {
    }
}
