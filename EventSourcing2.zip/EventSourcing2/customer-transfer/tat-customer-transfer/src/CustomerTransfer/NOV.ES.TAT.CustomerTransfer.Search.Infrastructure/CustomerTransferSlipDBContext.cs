﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using NOV.ES.Framework.Core.Data;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;

namespace NOV.ES.TAT.CustomerTransfer.Search.Infrastructure
{
    public class CustomerTransferSlipDBContext : BaseContext
    {
        public CustomerTransferSlipDBContext(DbContextOptions<CustomerTransferSlipDBContext> dbContextOptions
            , IHttpContextAccessor httpContextAccessor)
            : base(dbContextOptions)
        {
            if (httpContextAccessor != null && httpContextAccessor.HttpContext != null)
            {
                IIdentityService identityService = new IdentityService(httpContextAccessor);
                UserProvider = identityService.GetUserName();
            }
        }
        public virtual DbSet<CustomerTransferSlip> CustomerTransferSlips{ get; set; }
        public virtual DbSet<CustomerTransferSlipDetail> CustomerTransferSlipDetails { get; set; }
        public virtual DbSet<CustomerTransferSnapShot> CustomerTransferSnapShots { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CustomerTransferSlip>().Property(x => x.Id).HasDefaultValueSql("NEWID()");
            modelBuilder.Entity<CustomerTransferSlip>().Property(x => x.IsActive).HasDefaultValueSql("1");
            modelBuilder.Entity<CustomerTransferSlip>().Property(x => x.DateCreated).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<CustomerTransferSlip>().Property(x => x.DateModified).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<CustomerTransferSlipDetail>().Property(x => x.Id).HasDefaultValueSql("NEWID()");
            modelBuilder.Entity<CustomerTransferSlipDetail>().Property(x => x.IsActive).HasDefaultValueSql("1");
            modelBuilder.Entity<CustomerTransferSlipDetail>().Property(x => x.DateCreated).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<CustomerTransferSlipDetail>().Property(x => x.DateModified).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<CustomerTransferSnapShot>().Property(x => x.Id).HasDefaultValueSql("NEWID()");
            modelBuilder.Entity<CustomerTransferSnapShot>().Property(x => x.IsActive).HasDefaultValueSql("1");
            modelBuilder.Entity<CustomerTransferSnapShot>().Property(x => x.DateCreated).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<CustomerTransferSnapShot>().Property(x => x.DateModified).HasDefaultValueSql("GETUTCDATE()");
        }
    }
}
