﻿using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;

namespace NOV.ES.TAT.CustomerTransfer.Search.Infrastructure
{
    public class CustomerTransferSlipDetailQueryRepository : 
        GenericReadRepository<CustomerTransferSlipDetail>, 
        ICustomerTransferSlipDetailQueryRepository
    {
        public CustomerTransferSlipDetailQueryRepository(CustomerTransferSlipDBContext context)
            : base(context)
        {
        }

    }
}
