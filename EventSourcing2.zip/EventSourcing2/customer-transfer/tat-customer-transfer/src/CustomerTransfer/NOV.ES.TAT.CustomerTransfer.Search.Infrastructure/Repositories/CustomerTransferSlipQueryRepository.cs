﻿using Microsoft.EntityFrameworkCore;
using NOV.ES.Framework.Core.Data;
using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure.Helper;
using System.Linq.Expressions;

namespace NOV.ES.TAT.CustomerTransfer.Search.Infrastructure
{
    public class CustomerTransferSlipQueryRepository : 
        GenericReadRepository<CustomerTransferSlip>, 
        ICustomerTransferSlipQueryRepository
    {
        public readonly CustomerTransferSlipDBContext dbContext;
        public CustomerTransferSlipQueryRepository(CustomerTransferSlipDBContext context)
            : base(context)
        {
            dbContext = context;
        }

        public IQueryable<string> GetDistinctCreatedBy()
        {
            return dbContext.CustomerTransferSlips.Select(a => a.CreatedBy).Distinct();
        }


        public IQueryable<CustomerTransferSlip> GetCustomerTransferSlip(SearchRequest searchRequest)
        {
            return dbContext.CustomerTransferSlips.Include(x => x.CustomerTransferSlipDetails).AsQueryable()
                  .Where(CreateSearchPredicate(searchRequest));
        }

        private Expression<Func<CustomerTransferSlip, bool>> CreateSearchPredicate(SearchRequest searchRequest) 
        {
            var filter = PredicateBuilder.Create<CustomerTransferSlip>(x => x.IsActive);

            if (searchRequest.DateFrom != DateTime.MinValue && searchRequest.DateTo != DateTime.MinValue
                        && searchRequest.SelectedDateInputType == SearchRequest.DateInputType.SlipDate)
            {
                filter = filter.And(x => x.SlipDate.Date >= searchRequest.DateFrom.Date && x.SlipDate.Date <= searchRequest.DateTo.Date);
            }
            if (searchRequest.DateFrom != DateTime.MinValue && searchRequest.DateTo != DateTime.MinValue
                        && searchRequest.SelectedDateInputType == SearchRequest.DateInputType.DateOut)
            {
                filter = filter.And(x => x.UsageDate.Value.Date >= searchRequest.DateFrom.Date && x.UsageDate.Value.Date <= searchRequest.DateTo.Date);
            }
            if (searchRequest.SelectedBUInputType != SearchRequest.BusinessUnitInputType.AllBU
                        && searchRequest.UserBuList != null && searchRequest.UserBuList.Count > 0)
            {
                filter = filter.And(x => searchRequest.UserBuList.Contains(x.BusinessUnitId.ToString()));
            }
            if (searchRequest.SelectedSlipStatusType == SearchRequest.SlipStatusInputType.Open)
            {
                filter = filter.And(x => x.IsCompleted == false);
            }
            else if (searchRequest.SelectedSlipStatusType == SearchRequest.SlipStatusInputType.Completed)
            {
                filter = filter.And(x => x.IsCompleted == true);
            }
            if (searchRequest.SelectedValueInputType == SearchRequest.ValueInputType.Serial && !string.IsNullOrEmpty(searchRequest.SearchText))
            {
                filter = filter.And(x => x.CustomerTransferSlipDetails.Any(d => d.ItemSerialNumber.Contains(searchRequest.SearchText)));
            }
            if (searchRequest.SelectedValueInputType == SearchRequest.ValueInputType.Part && !string.IsNullOrEmpty(searchRequest.SearchText))
            {
                filter = filter.And(x => x.CustomerTransferSlipDetails.Any(d => d.PartNumber.Contains(searchRequest.SearchText)));
            }
            if (searchRequest.SelectedValueInputType == SearchRequest.ValueInputType.Job && !string.IsNullOrEmpty(searchRequest.SearchText))
            {
                filter = filter.And(x => x.ErpJobNumber.ToString().Contains(searchRequest.SearchText));
            }
            if (searchRequest.SelectedValueInputType == SearchRequest.ValueInputType.Slip && !string.IsNullOrEmpty(searchRequest.SearchText))
            {
                filter = filter.And(x => x.CustomerTransferNumber.ToString().Contains(searchRequest.SearchText));
            }
            if (searchRequest.CompanyList != null && searchRequest.CompanyList.Count > 0)
            {
                filter = filter.And(x => searchRequest.CompanyList.Contains(x.CompanyId.ToString()));
            }
            if (searchRequest.RevenueBuList != null && searchRequest.RevenueBuList.Count > 0)
            {
                filter = filter.And(x => searchRequest.RevenueBuList.Contains(x.BusinessUnitId.ToString()));
            }
            if (searchRequest.CustomerList != null && searchRequest.CustomerList.Count > 0)
            {
                filter = filter.And(x => searchRequest.CustomerList.Contains(x.CustomerId.ToString()));
            }
            if (searchRequest.RigList != null && searchRequest.RigList.Count > 0)
            {
                filter = filter.And(x => searchRequest.RigList.Contains(x.RigId.ToString()));
            }
            if (searchRequest.OperatorList != null && searchRequest.OperatorList.Count > 0)
            {
                filter = filter.And(x => searchRequest.OperatorList.Contains(x.OilCompanyId.ToString()));
            }
            if (searchRequest.SendingBuList != null && searchRequest.SendingBuList.Count > 0)
            {
                filter = filter.And(x => searchRequest.SendingBuList.Contains(x.SendingBuId.ToString()));
            }
            if (searchRequest.CreatedByList != null && searchRequest.CreatedByList.Count > 0)
            {
                filter = filter.And(x => searchRequest.CreatedByList.Contains(x.CreatedBy));
            }
            return filter;
        }
    }
}
