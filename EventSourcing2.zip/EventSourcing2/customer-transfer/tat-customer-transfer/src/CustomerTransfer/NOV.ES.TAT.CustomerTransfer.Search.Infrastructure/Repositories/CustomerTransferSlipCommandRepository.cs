﻿using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;

namespace NOV.ES.TAT.CustomerTransfer.Search.Infrastructure
{
    public class CustomerTransferSlipCommandRepository
        : GenericWriteRepository<CustomerTransferSlip>
        , ICustomerTransferSlipCommandRepository
    {
        private readonly CustomerTransferSlipDBContext customerTransferSlipDBContext;

        public CustomerTransferSlipCommandRepository(CustomerTransferSlipDBContext customerTransferSlipDBContext)
            : base(customerTransferSlipDBContext)
        {
            this.customerTransferSlipDBContext = customerTransferSlipDBContext;
        }

        public int SaveChanges()
        {
            return customerTransferSlipDBContext.SaveChanges();
        }

        public Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            return customerTransferSlipDBContext.SaveChangesAsync(cancellationToken);
        }
    }
}