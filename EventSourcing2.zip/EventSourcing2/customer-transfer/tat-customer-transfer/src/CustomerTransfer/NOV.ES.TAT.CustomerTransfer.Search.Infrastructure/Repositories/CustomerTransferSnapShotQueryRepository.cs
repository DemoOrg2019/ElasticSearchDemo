﻿using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure.Helper;

namespace NOV.ES.TAT.CustomerTransfer.Search.Infrastructure
{
    public class CustomerTransferSnapShotQueryRepository :
        GenericReadRepository<CustomerTransferSnapShot>,
        ICustomerTransferSnapShotQueryRepository
    {
        public CustomerTransferSnapShotQueryRepository(CustomerTransferSlipDBContext context)
            : base(context)
        {
        }

    }
}
