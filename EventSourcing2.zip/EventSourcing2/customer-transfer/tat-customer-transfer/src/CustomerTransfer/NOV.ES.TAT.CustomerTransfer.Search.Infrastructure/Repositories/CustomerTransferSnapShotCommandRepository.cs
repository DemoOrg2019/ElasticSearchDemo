﻿using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;

namespace NOV.ES.TAT.CustomerTransfer.Search.Infrastructure
{
    public class CustomerTransferSnapShotCommandRepository
        : GenericWriteRepository<CustomerTransferSnapShot>
        , ICustomerTransferSnapShotCommandRepository
    {
        private readonly CustomerTransferSlipDBContext customerTransferspliDBContext;

        public CustomerTransferSnapShotCommandRepository(CustomerTransferSlipDBContext customerTransferspliDBContext)
            : base(customerTransferspliDBContext)
        {
            this.customerTransferspliDBContext = customerTransferspliDBContext;
        }

        public int SaveChanges()
        {
            return customerTransferspliDBContext.SaveChanges();
        }

        public Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            return customerTransferspliDBContext.SaveChangesAsync(cancellationToken);
        }
    }
}