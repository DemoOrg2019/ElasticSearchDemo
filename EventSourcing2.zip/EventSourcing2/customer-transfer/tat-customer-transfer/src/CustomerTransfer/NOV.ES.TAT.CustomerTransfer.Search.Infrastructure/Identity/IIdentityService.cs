﻿namespace NOV.ES.TAT.CustomerTransfer.Search.Infrastructure;

public interface IIdentityService
{
    string GetUserIdentity();

    string GetUserName();
}

