﻿using NOV.ES.Framework.Core.Pagination;

namespace NOV.ES.TAT.CustomerTransfer.Search.Infrastructure.Helper
{
    public class SearchRequest
    {
        public enum DateInputType { SlipDate, DateOut }
        public enum BusinessUnitInputType { AllBU,  UserBU }
        public enum SlipStatusInputType { Open, Completed, Both  }
        public enum ValueInputType { Slip, Serial, Part, Job }

        public Paging PagingParameters { get; set; }
        public DateInputType SelectedDateInputType { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
        public BusinessUnitInputType SelectedBUInputType { get; set; }
        public List<string> UserBuList { get; set; }
        public SlipStatusInputType SelectedSlipStatusType { get; set; }
        public ValueInputType SelectedValueInputType { get; set; } 
        public string SearchText { get; set; }
        public List<string> CompanyList { get; set; }
        public List<string> RevenueBuList { get; set; }
        public List<string> CustomerList { get; set; }
        public List<string> RigList { get; set; }
        public List<string> OperatorList { get; set; }
        public List<string> SendingBuList { get; set; }
        public List<string> CreatedByList { get; set; }
    }
}
