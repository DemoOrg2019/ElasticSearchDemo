﻿using Microsoft.EntityFrameworkCore;
using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;

namespace NOV.ES.TAT.CustomerTransfer.Projection.Infrastructure
{
    public class CustomerTransferSlipProjectionRepository
        : GenericWriteRepository<CustomerTransferSlip>,
          ICustomerTransferSlipProjectionRepository
    {
        private readonly CustomerTransferSlipProjectionDbContext customerTransferSlipDBContext;

        public CustomerTransferSlipProjectionRepository(CustomerTransferSlipProjectionDbContext context)
            : base(context)
        {
            this.customerTransferSlipDBContext = context;
        }

        public async Task<CustomerTransferSlip?> GetById(Guid id)
        {
            return  await Task.Run(() => customerTransferSlipDBContext.CustomerTransferSlips
                .AsNoTracking()
                .Include(x => x.CustomerTransferSlipDetails)
                .Where(x => x.Id == id)
                .FirstOrDefault());
        }

        public void CreateAuditLog(CustomerTransferSlipAuditLog customerTransferSlipAuditLog)
        {
            customerTransferSlipDBContext.CustomerTransferSlipAuditLogs.Add(customerTransferSlipAuditLog);
        }

        public bool UpdateCustomerTransferSlip(CustomerTransferSlip saveCustomerTransferSlip)
        {
            var existingCts = customerTransferSlipDBContext.CustomerTransferSlips
                //.AsNoTracking()
                .Include(x => x.CustomerTransferSlipDetails)
                .Where(x => x.Id == saveCustomerTransferSlip.Id)
                .FirstOrDefault();

            if (existingCts != null)
            {
                customerTransferSlipDBContext.Entry(existingCts).State = EntityState.Detached;

                // Delete detail records that no longer exist.
                foreach (var existingDetail in existingCts.CustomerTransferSlipDetails.ToList())
                {
                    if (!saveCustomerTransferSlip.CustomerTransferSlipDetails.Any(c => c.Id == existingDetail.Id))
                    {
                        customerTransferSlipDBContext.CustomerTransferSlipDetails.Remove(existingDetail);
                    }
                }

                // customerTransferSlipDBContext.Set<CustomerTransferSlip>().Update(saveCustomerTransferSlip);

                foreach (var detail in saveCustomerTransferSlip.CustomerTransferSlipDetails)
                {
                    var existingDetail = existingCts.CustomerTransferSlipDetails
                        .SingleOrDefault(x => x.Id == detail.Id && 
                                         x.Id != Guid.Empty && 
                                         x.ItemId == detail.ItemId);

                    if (existingDetail != null)
                    {
                        // customerTransferSlipDBContext.Entry(existingDetail).CurrentValues.SetValues(detail);
                        customerTransferSlipDBContext.Entry(existingDetail).State = EntityState.Detached;
                        customerTransferSlipDBContext.CustomerTransferSlipDetails.Update(detail);

                    }
                    else
                    {
                        // customerTransferSlipDBContext.CustomerTransferSlipDetails.Add(detail);
                        existingCts.CustomerTransferSlipDetails.Add(detail);
                    }
                }

                customerTransferSlipDBContext.CustomerTransferSlips.Update(saveCustomerTransferSlip);
            }

            return true;
        }

        public int SaveChanges()
        {
            return customerTransferSlipDBContext.SaveChanges();
        }

        public Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            return customerTransferSlipDBContext.SaveChangesAsync(cancellationToken);
        }

    }
}
