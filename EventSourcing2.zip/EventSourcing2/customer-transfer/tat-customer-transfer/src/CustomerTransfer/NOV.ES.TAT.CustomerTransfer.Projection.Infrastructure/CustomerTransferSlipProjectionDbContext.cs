﻿using Microsoft.EntityFrameworkCore;
using NOV.ES.Framework.Core.Data;
using NOV.ES.TAT.CustomerTransfer.Domain;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;

namespace NOV.ES.TAT.CustomerTransfer.Projection.Infrastructure
{
    public class CustomerTransferSlipProjectionDbContext : BaseContext
    {
        public virtual DbSet<CustomerTransferSlip> CustomerTransferSlips { get; set; }
        public virtual DbSet<CustomerTransferSlipDetail> CustomerTransferSlipDetails { get; set; } 
        public virtual DbSet<CustomerTransferSlipAuditLog> CustomerTransferSlipAuditLogs { get; set; }


        public CustomerTransferSlipProjectionDbContext(DbContextOptions<CustomerTransferSlipProjectionDbContext> dbContextOptions)
            : base(dbContextOptions)
        {
            UserProvider = "tat.system@nov.com";
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CustomerTransferSlip>().Property(x => x.Id).HasDefaultValueSql("NEWID()");
            modelBuilder.Entity<CustomerTransferSlip>().Property(x => x.IsActive).HasDefaultValueSql("1");
            modelBuilder.Entity<CustomerTransferSlip>().Property(x => x.DateCreated).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<CustomerTransferSlip>().Property(x => x.DateModified).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<CustomerTransferSlipDetail>().Property(x => x.Id).HasDefaultValueSql("NEWID()");
            modelBuilder.Entity<CustomerTransferSlipDetail>().Property(x => x.IsActive).HasDefaultValueSql("1");
            modelBuilder.Entity<CustomerTransferSlipDetail>().Property(x => x.DateCreated).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<CustomerTransferSlipDetail>().Property(x => x.DateModified).HasDefaultValueSql("GETUTCDATE()");
            
            modelBuilder.Entity<CustomerTransferSlipAuditLog>().Property(x => x.Id).HasDefaultValueSql("NEWID()");
        }

    }
}