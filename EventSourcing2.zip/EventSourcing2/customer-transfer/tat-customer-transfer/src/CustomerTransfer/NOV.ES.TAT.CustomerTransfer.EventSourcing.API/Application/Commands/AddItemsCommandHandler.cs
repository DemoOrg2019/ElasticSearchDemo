﻿using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.CustomerTransfer.Domain.WriteModels;
using NOV.ES.TAT.CustomerTransfer.EventSourcing.DomainService;

namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.Commands
{
    public class AddItemsCommandHandler
        : ICommandHandler<AddItemsCommand, bool>
    {
        private readonly ILogger<CreateCustomerTransferSlipHeaderCommandHandler> logger;
        private readonly ICustomerTransferSlipEventSourcingService customerTransferSlipEventSourcingService;

        public AddItemsCommandHandler(
            ILogger<CreateCustomerTransferSlipHeaderCommandHandler> logger,
            ICustomerTransferSlipEventSourcingService customerTransferSlipEventSourcingService)
        {
            this.logger = logger;
            this.customerTransferSlipEventSourcingService = customerTransferSlipEventSourcingService;
        }

        public Task<bool> Handle(AddItemsCommand request, CancellationToken cancellationToken)
        {
            logger.LogInformation("----- Add Items to Customer Transfer Slip Request: {@slipid} - {@itemscount}", request.CustomerTransferSlipId, request.Items?.Count);

            var lastSequenceNumber = customerTransferSlipEventSourcingService.GetAggregateVersion(request.CustomerTransferSlipId, 0);

            if(lastSequenceNumber == 0)
            {
                logger.LogWarning("----- Cannot add Items as Customer Transfer Slip does not exists: {@slipid}", request.CustomerTransferSlipId);
                return Task.FromResult(false);
            }

            
            CustomerTransferSlip slip = new CustomerTransferSlip(request.CustomerTransferSlipId);            
            slip.AddItems(request, lastSequenceNumber);

            customerTransferSlipEventSourcingService.Save(slip);

            return Task.FromResult(true);
        }
    }
}
