﻿using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.CustomerTransfer.API.Validators;
using NOV.ES.TAT.CustomerTransfer.Domain.WriteModels;
using NOV.ES.TAT.CustomerTransfer.EventSourcing.DomainService;
using System.Net;
using System.Net.Mime;

namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.Commands
{
    public class CreateCustomerTransferSlipHeaderCommandHandler
        : ICommandHandler<CreateCustomerTransferSlipHeaderCommand, ContentResult>
    {
        private readonly ILogger<CreateCustomerTransferSlipHeaderCommandHandler> logger;
        private readonly ICustomerTransferSlipEventSourcingService customerTransferSlipEventSourcingService;

        public CreateCustomerTransferSlipHeaderCommandHandler(
            ILogger<CreateCustomerTransferSlipHeaderCommandHandler> logger,
            ICustomerTransferSlipEventSourcingService customerTransferSlipEventSourcingService
            )
        {
            this.logger = logger;
            this.customerTransferSlipEventSourcingService = customerTransferSlipEventSourcingService;
        }

        public Task<ContentResult> Handle(CreateCustomerTransferSlipHeaderCommand request, CancellationToken cancellationToken)
        {
            logger.LogInformation("----- Create Customer Transfer Slip Header Request: {@Header}", request);
            ContentResult contentResult = new()
            {
                ContentType = MediaTypeNames.Application.Json
            };
            try
            {               
                ValidationResult validationResult = new CustomerTransferSlipHeaderValidator().Validate(request);
                if (!validationResult.IsValid)
                {
                    contentResult.Content = JsonConvert.SerializeObject(validationResult.Errors);
                    contentResult.StatusCode = (int)HttpStatusCode.BadRequest;
                    return Task.FromResult(contentResult);
                }
                else
                {
                    contentResult.StatusCode = (int)HttpStatusCode.Created;
                    contentResult.Content = "Created";
                }

                var expectedVersion = customerTransferSlipEventSourcingService.GetAggregateVersion(request.CustomerTransferSlipId, 0);
                if (expectedVersion > 0)
                {
                    logger.LogWarning("----- Cannot create as Customer Transfer Slip already exists: {@slipid}", request.CustomerTransferSlipId);
                    contentResult.Content = JsonConvert.SerializeObject(string.Format("Cannot create as Customer Transfer Slip already exists: {0}", request.CustomerTransferSlipId.ToString()));
                    return Task.FromResult(contentResult);
                }
                CustomerTransferSlip slip = new CustomerTransferSlip();
                slip.CreateHeader(request);
                customerTransferSlipEventSourcingService.Save(slip);
                return Task.FromResult(contentResult);

            }
            catch (Exception ex)
            {
                contentResult.Content = JsonConvert.SerializeObject(ex.Message);
                contentResult.StatusCode = (int)HttpStatusCode.BadRequest;
                return Task.FromResult(contentResult);
            }
        }
    }
}
