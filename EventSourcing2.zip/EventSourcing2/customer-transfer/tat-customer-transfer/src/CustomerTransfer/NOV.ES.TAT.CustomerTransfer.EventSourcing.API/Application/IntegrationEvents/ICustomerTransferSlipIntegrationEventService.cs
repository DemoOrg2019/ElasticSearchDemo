﻿namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.IntegrationEvents
{
    public interface ICustomerTransferSlipIntegrationEventService
    {
    }
}
