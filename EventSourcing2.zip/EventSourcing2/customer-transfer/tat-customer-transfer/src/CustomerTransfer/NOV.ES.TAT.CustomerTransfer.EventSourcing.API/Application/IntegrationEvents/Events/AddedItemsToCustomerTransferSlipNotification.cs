﻿using NOV.ES.Framework.Core.Messaging.IntegrationEvents;

namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.IntegrationEvents.Events
{
    public class AddedItemsToCustomerTransferSlipNotification
        : IntegrationEvent
    {
        public Guid CustomerTransferSlipId { get; init; }

        public AddedItemsToCustomerTransferSlipNotification(Guid cuustomerTransferSlipId)
            => CustomerTransferSlipId = cuustomerTransferSlipId;
    }
}
