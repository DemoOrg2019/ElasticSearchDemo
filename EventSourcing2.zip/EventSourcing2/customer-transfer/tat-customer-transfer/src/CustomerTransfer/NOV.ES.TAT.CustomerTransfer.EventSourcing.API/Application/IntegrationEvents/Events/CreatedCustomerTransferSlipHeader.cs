﻿using NOV.ES.Framework.Core.Messaging.IntegrationEvents;

namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.IntegrationEvents.Events
{
    public class CreatedCustomerTransferSlipHeaderIntegrationEvent
        : IntegrationEvent
    {
        public Guid CustomerTransferSlipId { get; init; }

        public CreatedCustomerTransferSlipHeaderIntegrationEvent(Guid cuustomerTransferSlipId, string actionBy)
            : base()
        {
            CustomerTransferSlipId = cuustomerTransferSlipId;
            ActionBy = actionBy;
        }
    }
}
