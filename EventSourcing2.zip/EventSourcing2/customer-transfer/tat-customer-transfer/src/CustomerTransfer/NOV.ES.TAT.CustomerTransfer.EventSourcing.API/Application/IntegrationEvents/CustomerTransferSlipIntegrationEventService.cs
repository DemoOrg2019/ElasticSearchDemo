﻿namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.IntegrationEvents
{
    public class CustomerTransferSlipIntegrationEventService
    {
    }
}
