﻿using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.CustomerTransfer.Domain.WriteModels;

namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.Commands
{
    public class AddItemsCommand 
        : CustomerTransferSlipDetail, ICommand<bool>
    {
        public AddItemsCommand()
        {
        }
    }
}
