﻿using MediatR;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.TAT.CustomerTransfer.Domain.Events;
using NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.IntegrationEvents.Events;

namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.DomainEventHandlers
{
    public class CustomerTransferSlipDomainEventHandler
         : INotificationHandler<CreatedCustomerTransferSlipHeader>,
           INotificationHandler<AddedItemsToCustomerTransferSlip>
    {
        private readonly ILogger<CustomerTransferSlipDomainEventHandler> logger;
        private readonly IIntegrationEventBus integrationEventBus;

        public CustomerTransferSlipDomainEventHandler(
            ILogger<CustomerTransferSlipDomainEventHandler> logger,
            IIntegrationEventBus integrationEventBus)
        {
            this.logger = logger;
            this.integrationEventBus = integrationEventBus;
        }
        public Task Handle(CreatedCustomerTransferSlipHeader notification, CancellationToken cancellationToken)
        {
            logger.LogInformation("----- Consuming Event: Customer Transfer Slip Created Domain Event");
            logger.LogInformation("----- Customer Transfer Slip Id is {id}", notification.AggregateRootId);

            integrationEventBus.Publish(new CreatedCustomerTransferSlipHeaderIntegrationEvent(notification.AggregateRootId, "nov.system@nov.com"));

            return Task.CompletedTask;
        }

        public Task Handle(AddedItemsToCustomerTransferSlip notification, CancellationToken cancellationToken)
        {
            logger.LogInformation("----- Consuming Event: Added Items to Customer Transfer Slip Domain Event");
            logger.LogInformation("----- Customer Transfer Slip Id is {id}", notification.AggregateRootId);

            integrationEventBus.Publish(new AddedItemsToCustomerTransferSlipNotification(notification.AggregateRootId));

            return Task.CompletedTask;
        }
    }
}
