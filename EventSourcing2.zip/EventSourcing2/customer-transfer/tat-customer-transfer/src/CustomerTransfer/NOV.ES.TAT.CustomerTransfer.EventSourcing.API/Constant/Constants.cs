﻿namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.API
{
    public static class Constants
    {
        public const string EX_NULL_REFERENCE = "Null Reference error occurred";

        public const string EX_CONNECTION_TIMEOUT = "Connection Timeout error occurred";

        public const string EX_ARGUMENT_EXCEPTION = "Invalid Argument error occurred";

        public const string EX_INTERNAL_ERROR = "IARGUMENT_EXCEPTIONnternal server error occurred";

        public const string EX_SQL_EXCEPTION = "SQL server error occurred";

        public const int Lookup = 4000;

        public const int NONE = 0;

        public const int UNKNOWN = 1;

        public const int CONNECTION_LOST = 100;

        public const int INTERNAL_ERROR = 200;

        public const int NULL_REFERENCE = 300;

        public const int SQL_EXCEPTION = 400;

        public const int ARGUMENT_EXCEPTION = 500;

        public const int APPLICATION_EXCEPTION = 600;

        public const string ArgumentException = "ArgumentException";

        public const string NullReferenceException = "NullReferenceException";

        public const string TimeoutException = "TimeoutException";

        public const string SqlException = "SqlException";


        #region ValidatorMessages

        public const string EMPTY_MESSAGE = "{0} cannot be empty.";
        public const string LENGTH_MESSAGE = "{0} should not exceed maximum length of {1}";

        #endregion
    }
}
