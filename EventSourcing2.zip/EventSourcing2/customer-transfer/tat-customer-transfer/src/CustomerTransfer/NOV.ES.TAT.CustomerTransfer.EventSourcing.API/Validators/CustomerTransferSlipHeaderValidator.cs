﻿using FluentValidation;
using FluentValidation.Results;
using NOV.ES.TAT.CustomerTransfer.Domain.WriteModels;
using NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.Commands;
using NOV.ES.TAT.CustomerTransfer.EventSourcing.API;

namespace NOV.ES.TAT.CustomerTransfer.API.Validators
{
    public class CustomerTransferSlipHeaderValidator
    : AbstractValidator<CreateCustomerTransferSlipHeaderCommand>
    {
        public CustomerTransferSlipHeaderValidator()
        {
            RuleFor(o => o.CustomerTransferSlipId).NotNull().NotEmpty().WithMessage(string.Format(Constants.EMPTY_MESSAGE, "CustomerTransferSlipId"));           
            RuleFor(o => o.CustomerSalesInfo.CompanyId).NotNull().NotEmpty().WithMessage(string.Format(Constants.EMPTY_MESSAGE, "CompanyId"));           
            RuleFor(o => o.CustomerSalesInfo.RevenuBuId).NotNull().NotEmpty().WithMessage(string.Format(Constants.EMPTY_MESSAGE, "RevenuBuId"));           
            RuleFor(o => o.CustomerSalesInfo.SendingBuId).NotNull().NotEmpty().WithMessage(string.Format(Constants.EMPTY_MESSAGE, "SendingBuId"));           
            RuleFor(o => o.CustomerSalesInfo.CustomerId).NotNull().NotEmpty().WithMessage(string.Format(Constants.EMPTY_MESSAGE, "CustomerId"));           
            RuleFor(o => o.CustomerSalesInfo.SalesZoneId).NotNull().NotEmpty().WithMessage(string.Format(Constants.EMPTY_MESSAGE, "SalesZoneId"));           
            RuleFor(o => o.RigsWellSiteInfo.Operator).NotNull().NotEmpty().WithMessage(string.Format(Constants.EMPTY_MESSAGE, "Operator"));           
        }
    }
}