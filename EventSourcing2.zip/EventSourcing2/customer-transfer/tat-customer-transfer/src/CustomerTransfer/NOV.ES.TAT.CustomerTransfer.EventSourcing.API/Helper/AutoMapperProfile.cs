﻿using AutoMapper;

namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Helper
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {            
        }
    }
}
