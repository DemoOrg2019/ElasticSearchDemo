﻿using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.TAT.CustomerTransfer.Search.API.Filters;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.DomainService;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure;
using Swashbuckle.AspNetCore.Filters;
using System.Reflection;

namespace NOV.ES.TAT.CustomerTransfer.Search.API
{
    public static class DependencyRegistrar
    {
        public static IServiceCollection AddCustomMvc(this IServiceCollection services)
        {
            services.AddControllers(
               options => options.Filters.Add(typeof(HttpGlobalExceptionFilter))
           ).AddNewtonsoftJson(
               joptions =>
               {
                   joptions.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                   joptions.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                   joptions.SerializerSettings.Converters.Add(new StringEnumConverter());
               }
           );
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                    .SetIsOriginAllowed((host) => true)
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });
            return services;
        }
        public static IServiceCollection AddHealthChecks(this IServiceCollection services, IConfiguration configuration)
        {
            var hcBuilder = services.AddHealthChecks();
            hcBuilder.AddCheck("self", () => HealthCheckResult.Healthy());
            return services;
        }
        public static IServiceCollection AddCustomDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<CustomerTransferSlipDBContext>(options =>
            {
                options.UseSqlServer(configuration["CustomerTransferDBConnString"],
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
                        sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                    });
            },
            ServiceLifetime.Scoped
            );
            return services;
        }
        public static IServiceCollection AddCustomSwagger(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "TAT Customer Transfer REST API",
                    Version = "v1",
                    Description = "The Customer Transfer Service REST API"
                });
                options.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
                {
                    Description = "Standard Authorization header using the Bearer scheme. Example: \"bearer {token}\"",
                    In = ParameterLocation.Header,
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey
                });

                options.OperationFilter<SecurityRequirementsOperationFilter>();
            });
            return services;
        }
        public static IServiceCollection AddDomainCoreDependecy(this IServiceCollection services)
        {
            services.AddScoped<IQueryBus, QueryBus>();
            services.AddScoped<ICommandBus, CommandBus>();
            services.AddScoped<ICustomerTransferSlipDetailQueryRepository, CustomerTransferSlipDetailQueryRepository>();
            services.AddScoped<ICustomerTransferSlipDetailService, CustomerTransferSlipDetailService>();
            services.AddScoped<ICustomerTransferSlipService, CustomerTransferSlipService>();
            services.AddScoped<ICustomerTransferSlipCommandRepository, CustomerTransferSlipCommandRepository>();
            services.AddScoped<ICustomerTransferSlipQueryRepository, CustomerTransferSlipQueryRepository>();
            services.AddScoped<ICustomerTransferSnapShotQueryRepository, CustomerTransferSnapShotQueryRepository>();
            services.AddScoped<ICustomerTransferSnapShotService, CustomerTransferSnapShotService>();
            return services;
        }
        public static IServiceCollection RegistorMediatR(this IServiceCollection services)
        {
            services.AddMediatR(typeof(Startup).GetTypeInfo().Assembly);
            services.AddValidatorsFromAssembly(typeof(Startup).Assembly);
            return services;
        }
        public static IServiceCollection AddAutoMapper(this IServiceCollection services)
        {
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            return services;
        }
    }
}
