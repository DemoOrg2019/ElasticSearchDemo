﻿using Microsoft.AspNetCore.Mvc;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Common.Exception;
using NOV.ES.TAT.CustomerTransfer.Search.API.Application.Commands;
using NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure.Helper;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure;
using System.Net;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerTransferSlipsController : ControllerBase
    {
        private readonly ILogger<CustomerTransferSlipsController> logger;
        private readonly IQueryBus queryBus;
        private readonly ICommandBus commandBus;

        public CustomerTransferSlipsController(
            ILogger<CustomerTransferSlipsController> logger,
            IQueryBus queryBus,
            ICommandBus commandBus)
        {
            this.logger = logger;
            this.queryBus = queryBus;
            this.commandBus = commandBus;
        }
        /// <summary>
        /// This method returns service name.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("ServiceName")]
        public IActionResult ServiceName()
        {
            return Ok("CustomerTransferSlips CustomerTransfer Service.");
        }

        // <summary>
        /// This method returns all CustomerTransferSlips 
        /// </summary>
        /// <param name="pagingParameters">Paging</param>
        /// <returns>list of CustomerTransferSlips</returns>
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<CustomerTransferSlipDto>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IAsyncEnumerable<CustomerTransferSlipDto>>> GetCustomerTransferSlips([FromQuery] Paging pagingParameters)
        {
            GetPaginationCustomerTransferSlipsQuery getPaginationCustomerTransferSlipsQuery
                = new GetPaginationCustomerTransferSlipsQuery(HttpContext.Request.Query.Count == 0 ? null : pagingParameters);

            PagedResult<CustomerTransferSlipDto> result = await queryBus.Send<GetPaginationCustomerTransferSlipsQuery
                , PagedResult<CustomerTransferSlipDto>>(getPaginationCustomerTransferSlipsQuery);

            if (result == null || !result.Any())
            {
                List<CustomerTransferSlipDto> customerTransferSlipDtos = new List<CustomerTransferSlipDto>();
                result = new PagedResult<CustomerTransferSlipDto>(customerTransferSlipDtos, customerTransferSlipDtos.Count, null);
            }
            return Ok(result.Items);
        }

        /// <summary>
        ///  This method returns CustomerTransferSlip as per id.
        /// </summary>
        /// <param name="id">Guid</param>
        /// <returns>CustomerTransferSlip as per Id</returns>
        [HttpGet]
        [Route("{id:Guid}")]
        [ProducesResponseType(typeof(CustomerTransferSlipDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<CustomerTransferSlipDto>> GetCustomerTransferSlipById([FromRoute] Guid id)
        {
            GetCustomerTransferSlipByIdQuery getCustomerTransferSlipByIdQuery = new GetCustomerTransferSlipByIdQuery(id);
            var result = await queryBus.Send<GetCustomerTransferSlipByIdQuery, CustomerTransferSlipDto>(getCustomerTransferSlipByIdQuery);

            if (result == null)
                return NotFound($"CustomerTransferSlip with id:{id} not found");

            return Ok(result);
        }

        /// <summary>
        ///  This method returns CustomerTransferNumber as per customerTransferId.
        /// </summary>
        /// <param name="customerTransferNumber">int</param>
        /// <returns>CustomerTransferSlip as per CustomerTransferNumber</returns>
        [HttpGet]
        [Route("Number/{number:int}")]
        [ProducesResponseType(typeof(CustomerTransferSlipDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IAsyncEnumerable<CustomerTransferSlipDto>>> GetCustomerTransferSlipsByNumber([FromRoute] int number)
        {
            GetCustomerTransferSlipByNumberQuery getCustomerTransferSlipByCustomerTransferNumberQuery = new GetCustomerTransferSlipByNumberQuery(number);
            var result = await queryBus.Send<GetCustomerTransferSlipByNumberQuery, IEnumerable<CustomerTransferSlipDto>>(getCustomerTransferSlipByCustomerTransferNumberQuery);

            if (result == null)
                return NotFound($"CustomerTransferSlip with CustomerTransferNumber:{number} not found");

            return Ok(result);
        }

        /// <summary>
        ///  This method returns CustomerTransferSlip as well as CustomerTransferSlipDetail as per id.
        /// </summary>
        /// <param name="id">Guid</param>
        /// <returns>CustomerTransferSlip & CustomerTransferSlipDetail as per Id</returns>
        [HttpGet]
        [Route("Detail/{id:Guid}")]
        [ProducesResponseType(typeof(CustomerTransferSlipDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IAsyncEnumerable<CustomerTransferSlipDto>>> GetCustomerTransferSlipDetailsById([FromRoute] Guid id)
        {
            GetCustomerTransferSlipDetailsByIdQuery getCustomerTransferSlipDetailsByIdQuery = new GetCustomerTransferSlipDetailsByIdQuery(id);
            var result = await queryBus.Send<GetCustomerTransferSlipDetailsByIdQuery, IEnumerable<CustomerTransferSlipDto>>(getCustomerTransferSlipDetailsByIdQuery);

            if (result == null)
                return NotFound($"CustomerTransferSlipDetails with Id:{id} not found");

            return Ok(result);
        }
        /// <summary>
        ///  This method returns CustomerTransferSlips as per CreatedBy.
        /// </summary>
        /// <param name="createdBy">string</param>
        /// <returns>CustomerTransferSlips as per CreatedBy</returns>
        [HttpGet]
        [Route("CreatedBy")]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IAsyncEnumerable<string>>> GetCreatedBy()
        {
            GetCustomerTransferSlipCreatedByQuery getCustomerTransferSlipCreatedByQuery = new GetCustomerTransferSlipCreatedByQuery();
            var result = await queryBus.Send<GetCustomerTransferSlipCreatedByQuery, IEnumerable<string>>(getCustomerTransferSlipCreatedByQuery);

            if (result == null)
                return NotFound($"CustomerTransferSlips CreatedBy not found");

            return Ok(result);
        }
        [HttpPost]
        [Route("search")]
        [ProducesResponseType(typeof(IEnumerable<CustomerTransferSlipSearchDto>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IAsyncEnumerable<CustomerTransferSlipSearchDto>>> GetCustomerTransferSlipSearch([FromBody] SearchRequest searchRequest)
        {
            GetPaginationCustomerTransferSlipsSearchQuery getPaginationCustomerTransferSlipsSearchQuery
               = new GetPaginationCustomerTransferSlipsSearchQuery(searchRequest);
            var result = await queryBus.Send<GetPaginationCustomerTransferSlipsSearchQuery
                , PagedResult<CustomerTransferSlipSearchDto>>(getPaginationCustomerTransferSlipsSearchQuery);
            if (result == null)
                return NotFound($"CustomerTransferSlipDetail cannot found with given input.");

            return Ok(result);
        }
   
        // <summary>
        /// This method deletes CustomerTransferSlips based on requested data.
        /// </summary>
        /// <param name="DeleteCustomerTransferSlipCommand">DeleteCustomerTransferSlipCommand</param>
        /// <returns>OK Result</returns>
        [HttpDelete]
        [Route("{id:Guid}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> DeleteCustomerTransferSlips([FromRoute] Guid id)
        {
            DeleteCustomerTransferSlipCommand deleteCustomerTransferSlipCommand = new DeleteCustomerTransferSlipCommand(id);
            ContentResult result = await commandBus.Send<DeleteCustomerTransferSlipCommand, ContentResult>(deleteCustomerTransferSlipCommand);
            if (result.StatusCode == (int)HttpStatusCode.BadRequest)
                return result;
            return Ok();
        }
    }
}
