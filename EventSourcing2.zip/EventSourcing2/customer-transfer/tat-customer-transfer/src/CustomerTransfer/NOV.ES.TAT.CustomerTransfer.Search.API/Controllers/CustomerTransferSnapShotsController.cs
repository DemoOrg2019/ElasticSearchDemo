﻿using Microsoft.AspNetCore.Mvc;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Common.Exception;
using NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using System.Net;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerTransferSnapShotsController : ControllerBase
    {
        private readonly ILogger<CustomerTransferSnapShotsController> logger;
        private readonly IQueryBus queryBus;

        public CustomerTransferSnapShotsController(
            ILogger<CustomerTransferSnapShotsController> logger,
            IQueryBus queryBus)
        {
            this.logger = logger;
            this.queryBus = queryBus;
        }
        /// <summary>
        /// This method returns service name.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("ServiceName")]
        public IActionResult ServiceName()
        {
            return Ok("CustomerTransferSnapShots CustomerTransfer Service.");
        }

        // <summary>
        /// This method returns all CustomerTransferSnapShots 
        /// </summary>
        /// <param name="pagingParameters">Paging</param>
        /// <returns>list of CustomerTransferSnapShots</returns>
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<CustomerTransferSnapShotDto>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IAsyncEnumerable<CustomerTransferSnapShotDto>>> GetCustomerTransferSnapShots([FromQuery] Paging pagingParameters)
        {
            GetPaginationCustomerTransferSnapShotsQuery getPaginationCustomerTransferSnapShotsQuery
                = new GetPaginationCustomerTransferSnapShotsQuery(HttpContext.Request.Query.Count == 0 ? null : pagingParameters);

            PagedResult<CustomerTransferSnapShotDto> result = await queryBus.Send<GetPaginationCustomerTransferSnapShotsQuery
                , PagedResult<CustomerTransferSnapShotDto>>(getPaginationCustomerTransferSnapShotsQuery);

            if (result == null || !result.Any())
            {
                List<CustomerTransferSnapShotDto> customerTransferSnapShotDtos = new List<CustomerTransferSnapShotDto>();
                result = new PagedResult<CustomerTransferSnapShotDto>(customerTransferSnapShotDtos, customerTransferSnapShotDtos.Count, null);
            }
            return Ok(result.Items);
        }

        /// <summary>
        ///  This method returns CustomerTransferSnapShot as per id.
        /// </summary>
        /// <param name="id">Guid</param>
        /// <returns>CustomerTransferSnapShot as per Id</returns>
        [HttpGet]
        [Route("{id:Guid}")]
        [ProducesResponseType(typeof(CustomerTransferSnapShotDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<CustomerTransferSnapShotDto>> GetCustomerTransferSnapShotById([FromRoute] Guid id)
        {
            GetCustomerTransferSnapShotByIdQuery getCustomerTransferSnapShotByIdQuery = new GetCustomerTransferSnapShotByIdQuery(id);
            var result = await queryBus.Send<GetCustomerTransferSnapShotByIdQuery, CustomerTransferSnapShotDto>(getCustomerTransferSnapShotByIdQuery);

            if (result == null)
                return NotFound($"CustomerTransferSnapShot with id:{id} not found");

            return Ok(result);
        }      
    }
}
