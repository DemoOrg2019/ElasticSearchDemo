﻿using Microsoft.AspNetCore.Mvc;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Common.Exception;
using NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using System.Net;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerTransferSlipDetailsController : ControllerBase
    {
        private readonly ILogger<CustomerTransferSlipDetailsController> logger;
        private readonly IQueryBus queryBus;

        public CustomerTransferSlipDetailsController(
            ILogger<CustomerTransferSlipDetailsController> logger,
            IQueryBus queryBus)
        {
            this.logger = logger;
            this.queryBus = queryBus;
        }
        /// <summary>
        /// This method returns service name.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("ServiceName")]
        public IActionResult ServiceName()
        {
            return Ok("CustomerTransferSlipDetails CustomerTransfer Service.");
        }

        // <summary>
        /// This method returns all CustomerTransferSlipDetails 
        /// </summary>
        /// <param name="pagingParameters">Paging</param>
        /// <returns>list of CustomerTransferSlipDetails</returns>
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<CustomerTransferSlipDetailDto>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IAsyncEnumerable<CustomerTransferSlipDetailDto>>> GetCustomerTransferSlipDetails([FromQuery] Paging pagingParameters)
        {
            GetPaginationCustomerTransferSlipDetailsQuery getPaginationCustomerTransferSlipDetailsQuery
                = new GetPaginationCustomerTransferSlipDetailsQuery(HttpContext.Request.Query.Count == 0 ? null : pagingParameters);

            PagedResult<CustomerTransferSlipDetailDto> result = await queryBus.Send<GetPaginationCustomerTransferSlipDetailsQuery
                , PagedResult<CustomerTransferSlipDetailDto>>(getPaginationCustomerTransferSlipDetailsQuery);

            if (result == null || !result.Any())
            {
                List<CustomerTransferSlipDetailDto> customerTransferSlipDetailDtos = new List<CustomerTransferSlipDetailDto>();
                result = new PagedResult<CustomerTransferSlipDetailDto>(customerTransferSlipDetailDtos, customerTransferSlipDetailDtos.Count, null);
            }
            return Ok(result.Items);
        }

        /// <summary>
        ///  This method returns CustomerTransferSlipDetail as per id.
        /// </summary>
        /// <param name="id">Guid</param>
        /// <returns>CustomerTransferSlipDetail as per Id</returns>
        [HttpGet]
        [Route("{id:Guid}")]
        [ProducesResponseType(typeof(CustomerTransferSlipDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<CustomerTransferSlipDetailDto>> GetCustomerTransferSlipDetailById([FromRoute] Guid id)
        {
            GetCustomerTransferSlipDetailByIdQuery getCustomerTransferSlipDetailByIdQuery = new GetCustomerTransferSlipDetailByIdQuery(id);
            var result = await queryBus.Send<GetCustomerTransferSlipDetailByIdQuery, CustomerTransferSlipDetailDto>(getCustomerTransferSlipDetailByIdQuery);

            if (result == null)
                return NotFound($"CustomerTransferSlipDetail with id:{id} not found");

            return Ok(result);
        }

        /// <summary>
        ///  This method returns CustomerTransferSlipDetail as per customerTransferId.
        /// </summary>
        /// <param name="customerTransferId">Guid</param>
        /// <returns>CustomerTransferSlipDetail as per CustomerTransferId</returns>
        [HttpGet]
        [Route("CustomerTransfer/{customerTransferId:Guid}")]
        [ProducesResponseType(typeof(CustomerTransferSlipDetailDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IAsyncEnumerable<CustomerTransferSlipDetailDto>>> GetCustomerTransferSlipDetailsByCustomerTransferId([FromRoute] Guid customerTransferId)
        {
            GetCustomerTransferSlipDetailByCustomerTransferIdQuery getCustomerTransferSlipDetailByCustomerTransferIdQuery = new GetCustomerTransferSlipDetailByCustomerTransferIdQuery(customerTransferId);
            var result = await queryBus.Send<GetCustomerTransferSlipDetailByCustomerTransferIdQuery, IEnumerable<CustomerTransferSlipDetailDto>>(getCustomerTransferSlipDetailByCustomerTransferIdQuery);

            if (result == null)
                return NotFound($"CustomerTransferSlipDetail with CustomerTransferId:{customerTransferId} not found");

            return Ok(result);
        }

    }
}
