﻿namespace NOV.ES.TAT.CustomerTransfer.Search.API
{
    public static class Constants
    {
    }
}
