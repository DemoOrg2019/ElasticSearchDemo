﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.DomainService;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetCustomerTransferSlipDetailByIdHandler : IQueryHandler<GetCustomerTransferSlipDetailByIdQuery, CustomerTransferSlipDetailDto>
    {
        private readonly IMapper mapper;
        private readonly ICustomerTransferSlipDetailService customerTransferSlipDetailService;
        public GetCustomerTransferSlipDetailByIdHandler(IMapper mapper,
            ICustomerTransferSlipDetailService customerTransferSlipDetailService)
        {
            this.mapper = mapper;
            this.customerTransferSlipDetailService = customerTransferSlipDetailService;
        }
        public Task<CustomerTransferSlipDetailDto> Handle(GetCustomerTransferSlipDetailByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException("Value can not be null or Empty");
            var customerTransferSlipDetail = customerTransferSlipDetailService.GetCustomerTransferSlipDetailById(request.Id);
            return Task.FromResult(mapper.Map<CustomerTransferSlipDetail, CustomerTransferSlipDetailDto>(customerTransferSlipDetail));
        }
        private static bool IsValidRequest(GetCustomerTransferSlipDetailByIdQuery request)
        {
            return (request != null && request.Id != Guid.Empty);
        }
    }
}
