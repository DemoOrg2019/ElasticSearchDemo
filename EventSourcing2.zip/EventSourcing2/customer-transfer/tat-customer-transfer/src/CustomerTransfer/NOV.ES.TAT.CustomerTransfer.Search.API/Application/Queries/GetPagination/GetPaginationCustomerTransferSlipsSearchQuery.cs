﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure.Helper;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetPaginationCustomerTransferSlipsSearchQuery : IQuery<PagedResult<CustomerTransferSlipSearchDto>>
    {
        public SearchRequest SearchRequest { get; private set; }
        public GetPaginationCustomerTransferSlipsSearchQuery(SearchRequest searchRequest)
        {
            this.SearchRequest = searchRequest;
        }
    }
}
