﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetCustomerTransferSlipDetailByIdQuery : IQuery<CustomerTransferSlipDetailDto>
    {
        public Guid Id { get; private set; }
        public GetCustomerTransferSlipDetailByIdQuery(Guid id)
        {
            this.Id = id;
        }
    }
}
