﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.CustomerTransfer.DomainService;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetCustomerTransferSlipCreatedByHandler : IQueryHandler<GetCustomerTransferSlipCreatedByQuery, IEnumerable<string>>
    {
        private readonly IMapper mapper;
        private readonly ICustomerTransferSlipService customerTransferSlipService;
        public GetCustomerTransferSlipCreatedByHandler(IMapper mapper,
            ICustomerTransferSlipService customerTransferSlipService)
        {
            this.mapper = mapper;
            this.customerTransferSlipService = customerTransferSlipService;
        }
        public Task<IEnumerable<string>> Handle(GetCustomerTransferSlipCreatedByQuery request, CancellationToken cancellationToken)
        {
            var customerTransferSlip= customerTransferSlipService.GetCreatedBy();
            return Task.FromResult(mapper.Map<IEnumerable<string>, IEnumerable<string>>(customerTransferSlip));
        }
    }
}
