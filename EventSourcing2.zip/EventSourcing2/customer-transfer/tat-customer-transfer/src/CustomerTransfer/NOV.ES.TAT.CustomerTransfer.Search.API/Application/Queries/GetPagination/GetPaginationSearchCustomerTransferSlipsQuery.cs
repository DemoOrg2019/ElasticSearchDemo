﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Infrastructure.Helper;

namespace NOV.ES.TAT.CustomerTransfer.API.Application.Queries
{
    public class GetPaginationSearchCustomerTransferSlipsQuery : IQuery<PagedResult<SearchCustomerTransferSlipDto>>
    {
        public Paging PagingParameters { get; private set; }
        public SearchRequest SearchRequest { get; private set; }

        public GetPaginationSearchCustomerTransferSlipsQuery(Paging pagingParameters, SearchRequest searchRequest)
        {
            this.PagingParameters = pagingParameters;
            this.SearchRequest = searchRequest;
        }
    }
}
