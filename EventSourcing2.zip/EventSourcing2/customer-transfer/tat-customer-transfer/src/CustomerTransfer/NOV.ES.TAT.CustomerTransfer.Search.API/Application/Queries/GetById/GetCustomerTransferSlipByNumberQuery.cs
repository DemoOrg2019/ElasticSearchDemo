﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetCustomerTransferSlipByNumberQuery : IQuery<IEnumerable<CustomerTransferSlipDto>>
    {
        public int CustomerTransferNumber { get; private set; }
        public GetCustomerTransferSlipByNumberQuery(int customerTransferNumber)
        {
            this.CustomerTransferNumber = customerTransferNumber;
        }
    }
}
