﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetCustomerTransferSlipDetailsByIdQuery : IQuery<IEnumerable<CustomerTransferSlipDto>>
    {
        public Guid Id { get; private set; }
        public GetCustomerTransferSlipDetailsByIdQuery(Guid id)
        {
            this.Id = id;
        }
    }
}
