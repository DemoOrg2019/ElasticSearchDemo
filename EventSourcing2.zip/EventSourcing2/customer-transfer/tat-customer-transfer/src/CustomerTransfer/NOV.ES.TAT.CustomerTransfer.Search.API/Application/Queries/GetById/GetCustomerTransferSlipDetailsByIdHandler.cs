﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.DomainService;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetCustomerTransferSlipDetailsByIdHandler : IQueryHandler<GetCustomerTransferSlipDetailsByIdQuery, IEnumerable<CustomerTransferSlipDto>>
    {
        private readonly IMapper mapper;
        private readonly ICustomerTransferSlipService customerTransferSlipService;
        public GetCustomerTransferSlipDetailsByIdHandler(IMapper mapper,
            ICustomerTransferSlipService customerTransferSlipService)
        {
            this.mapper = mapper;
            this.customerTransferSlipService = customerTransferSlipService;
        }
        public Task<IEnumerable<CustomerTransferSlipDto>> Handle(GetCustomerTransferSlipDetailsByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException("Value can not be null or Empty");
            var customerTransferSlip = customerTransferSlipService.GetCustomerTransferSlipDetailsById(request.Id);
            return Task.FromResult(mapper.Map<IEnumerable<CustomerTransferSlip>, IEnumerable<CustomerTransferSlipDto>>(customerTransferSlip));
        }
        private static bool IsValidRequest(GetCustomerTransferSlipDetailsByIdQuery request)
        {
            return (request != null && request.Id != Guid.Empty);
        }
    }
}
