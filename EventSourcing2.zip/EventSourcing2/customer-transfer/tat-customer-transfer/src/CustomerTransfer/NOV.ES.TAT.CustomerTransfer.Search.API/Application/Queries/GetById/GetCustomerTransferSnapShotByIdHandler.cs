﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.DomainService;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetCustomerTransferSnapShotByIdHandler : IQueryHandler<GetCustomerTransferSnapShotByIdQuery, CustomerTransferSnapShotDto>
    {
        private readonly IMapper mapper;
        private readonly ICustomerTransferSnapShotService customerTransferSnapShotService;
        public GetCustomerTransferSnapShotByIdHandler(IMapper mapper,
            ICustomerTransferSnapShotService customerTransferSnapShotService)
        {
            this.mapper = mapper;
            this.customerTransferSnapShotService = customerTransferSnapShotService;
        }
        public Task<CustomerTransferSnapShotDto> Handle(GetCustomerTransferSnapShotByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException("Value can not be null or Empty");
            var customerTransferSnapShot = customerTransferSnapShotService.GetCustomerTransferSnapShotById(request.Id);
            return Task.FromResult(mapper.Map<CustomerTransferSnapShot, CustomerTransferSnapShotDto>(customerTransferSnapShot));
        }
        private static bool IsValidRequest(GetCustomerTransferSnapShotByIdQuery request)
        {
            return (request != null && request.Id != Guid.Empty);
        }
    }
}
