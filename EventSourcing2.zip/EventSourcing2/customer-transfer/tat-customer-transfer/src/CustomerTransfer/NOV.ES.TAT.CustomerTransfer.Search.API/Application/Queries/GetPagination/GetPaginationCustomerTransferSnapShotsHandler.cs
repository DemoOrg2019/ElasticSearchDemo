﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Search.API.Helper;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.DomainService;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetPaginationCustomerTransferSnapShotsHandler
           : IQueryHandler<GetPaginationCustomerTransferSnapShotsQuery, PagedResult<CustomerTransferSnapShotDto>>
    {
        private readonly IMapper mapper;
        private readonly ICustomerTransferSnapShotService customerTransferSnapShotService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationCustomerTransferSnapShotsHandler(IMapper mapper
            , ICustomerTransferSnapShotService customerTransferSnapShotService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.customerTransferSnapShotService = customerTransferSnapShotService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<CustomerTransferSnapShotDto>> Handle(GetPaginationCustomerTransferSnapShotsQuery request,
          CancellationToken cancellationToken)
        {
            var customerTransferSnapShots = customerTransferSnapShotService.GetCustomerTransferSnapShots(request.PagingParameters);
            var result = mapper.Map<PagedResult<CustomerTransferSnapShot>, PagedResult<CustomerTransferSnapShotDto>>(customerTransferSnapShots);
            PagingHelper.AddPagingMetadata(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}