﻿using Microsoft.AspNetCore.Mvc;
using NOV.ES.Framework.Core.CQRS.Commands;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Commands
{
    public class DeleteCustomerTransferSlipCommand : ICommand<ContentResult>
    {
        public Guid Id { get; private set; }
        public DeleteCustomerTransferSlipCommand(Guid id)
        {
            this.Id = id;
        }
    }
}
