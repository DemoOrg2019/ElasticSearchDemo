﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.DomainService;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetCustomerTransferSlipDetailByCustomerTransferIdHandler : IQueryHandler<GetCustomerTransferSlipDetailByCustomerTransferIdQuery, IEnumerable<CustomerTransferSlipDetailDto>>
    {
        private readonly IMapper mapper;
        private readonly ICustomerTransferSlipDetailService customerTransferSlipDetailService;
        public GetCustomerTransferSlipDetailByCustomerTransferIdHandler(IMapper mapper,
            ICustomerTransferSlipDetailService customerTransferSlipDetailService)
        {
            this.mapper = mapper;
            this.customerTransferSlipDetailService = customerTransferSlipDetailService;
        }
        public Task<IEnumerable<CustomerTransferSlipDetailDto>> Handle(GetCustomerTransferSlipDetailByCustomerTransferIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException("Value can not be null or Empty");
            var customerTransferSlipDetail = customerTransferSlipDetailService.GetCustomerTransferSlipDetailsByCustomerTransferId(request.CustomerTransferId);
            return Task.FromResult(mapper.Map<IEnumerable<CustomerTransferSlipDetail>, IEnumerable<CustomerTransferSlipDetailDto>>(customerTransferSlipDetail));
        }
        private static bool IsValidRequest(GetCustomerTransferSlipDetailByCustomerTransferIdQuery request)
        {
            return (request != null && request.CustomerTransferId != Guid.Empty);

        }
    }
}
