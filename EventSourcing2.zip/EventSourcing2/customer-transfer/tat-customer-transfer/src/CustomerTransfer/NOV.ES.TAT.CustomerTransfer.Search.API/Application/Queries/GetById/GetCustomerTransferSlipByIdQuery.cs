﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetCustomerTransferSlipByIdQuery : IQuery<CustomerTransferSlipDto>
    {
        public Guid Id { get; private set; }
        public GetCustomerTransferSlipByIdQuery(Guid id)
        {
            this.Id = id;
        }
    }
}
