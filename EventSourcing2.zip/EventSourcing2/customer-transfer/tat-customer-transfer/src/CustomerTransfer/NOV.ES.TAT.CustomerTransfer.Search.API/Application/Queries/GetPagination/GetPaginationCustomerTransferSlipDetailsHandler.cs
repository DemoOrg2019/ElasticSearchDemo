﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Search.API.Helper;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.DomainService;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetPaginationCustomerTransferSlipDetailsHandler
           : IQueryHandler<GetPaginationCustomerTransferSlipDetailsQuery, PagedResult<CustomerTransferSlipDetailDto>>
    {
        private readonly IMapper mapper;
        private readonly ICustomerTransferSlipDetailService customerTransferSlipDetailService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationCustomerTransferSlipDetailsHandler(IMapper mapper
            , ICustomerTransferSlipDetailService customerTransferSlipDetailService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.customerTransferSlipDetailService = customerTransferSlipDetailService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<CustomerTransferSlipDetailDto>> Handle(GetPaginationCustomerTransferSlipDetailsQuery request,
          CancellationToken cancellationToken)
        {
            var customerTransferSlipDetails = customerTransferSlipDetailService.GetCustomerTransferSlipDetails(request.PagingParameters);
            var result = mapper.Map<PagedResult<CustomerTransferSlipDetail>, PagedResult<CustomerTransferSlipDetailDto>>(customerTransferSlipDetails);
            PagingHelper.AddPagingMetadata(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}