﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetPaginationCustomerTransferSlipDetailsQuery : IQuery<PagedResult<CustomerTransferSlipDetailDto>>
    {
        public Paging PagingParameters { get; private set; }

        public GetPaginationCustomerTransferSlipDetailsQuery(Paging pagingParameters)
        {
            this.PagingParameters = pagingParameters;
        }
    }
}
