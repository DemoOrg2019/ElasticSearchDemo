﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetCustomerTransferSlipDetailByCustomerTransferIdQuery : IQuery<IEnumerable<CustomerTransferSlipDetailDto>>
    {
        public Guid CustomerTransferId { get; private set; }
        public GetCustomerTransferSlipDetailByCustomerTransferIdQuery(Guid customerTransferId)
        {
            this.CustomerTransferId = customerTransferId;
        }
    }
}
