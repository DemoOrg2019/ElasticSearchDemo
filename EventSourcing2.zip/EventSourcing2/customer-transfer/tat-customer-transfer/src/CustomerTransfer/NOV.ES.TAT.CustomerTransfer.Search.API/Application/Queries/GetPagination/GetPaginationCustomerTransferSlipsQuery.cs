﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetPaginationCustomerTransferSlipsQuery : IQuery<PagedResult<CustomerTransferSlipDto>>
    {
        public Paging PagingParameters { get; private set; }

        public GetPaginationCustomerTransferSlipsQuery(Paging pagingParameters)
        {
            this.PagingParameters = pagingParameters;
        }
    }
}
