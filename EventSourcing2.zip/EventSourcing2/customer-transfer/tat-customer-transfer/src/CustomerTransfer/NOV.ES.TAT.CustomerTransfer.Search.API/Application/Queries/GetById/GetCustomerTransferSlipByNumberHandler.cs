﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.DomainService;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetCustomerTransferSlipByNumberHandler : IQueryHandler<GetCustomerTransferSlipByNumberQuery, IEnumerable<CustomerTransferSlipDto>>
    {
        private readonly IMapper mapper;
        private readonly ICustomerTransferSlipService customerTransferSlipService;
        public GetCustomerTransferSlipByNumberHandler(IMapper mapper,
            ICustomerTransferSlipService customerTransferSlipService)
        {
            this.mapper = mapper;
            this.customerTransferSlipService = customerTransferSlipService;
        }
        public Task<IEnumerable<CustomerTransferSlipDto>> Handle(GetCustomerTransferSlipByNumberQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException("Value can not be null or Empty");
            var customerTransferSlip = customerTransferSlipService.GetCustomerTransferSlipsByNumber(request.CustomerTransferNumber);
            return Task.FromResult(mapper.Map<IEnumerable<CustomerTransferSlip>, IEnumerable<CustomerTransferSlipDto>>(customerTransferSlip));
        }
        private static bool IsValidRequest(GetCustomerTransferSlipByNumberQuery request)
        {
            return (request != null && request.CustomerTransferNumber > 0);
        }
    }
}
