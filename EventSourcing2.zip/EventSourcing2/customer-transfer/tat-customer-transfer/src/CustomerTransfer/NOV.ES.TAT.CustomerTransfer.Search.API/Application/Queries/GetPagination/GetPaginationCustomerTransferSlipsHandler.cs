﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Search.API.Helper;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.DomainService;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetPaginationCustomerTransferSlipsHandler
           : IQueryHandler<GetPaginationCustomerTransferSlipsQuery, PagedResult<CustomerTransferSlipDto>>
    {
        private readonly IMapper mapper;
        private readonly ICustomerTransferSlipService customerTransferSlipService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationCustomerTransferSlipsHandler(IMapper mapper
            , ICustomerTransferSlipService customerTransferSlipService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.customerTransferSlipService = customerTransferSlipService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<CustomerTransferSlipDto>> Handle(GetPaginationCustomerTransferSlipsQuery request,
          CancellationToken cancellationToken)
        {
            var customerTransferSlips = customerTransferSlipService.GetCustomerTransferSlips(request.PagingParameters);
            var result = mapper.Map<PagedResult<CustomerTransferSlip>, PagedResult<CustomerTransferSlipDto>>(customerTransferSlips);
            PagingHelper.AddPagingMetadata(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}