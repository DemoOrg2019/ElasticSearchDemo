﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Search.API.Helper;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.DomainService;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries
{
    public class GetPaginationCustomerTransferSlipsSearchHandler
           : IQueryHandler<GetPaginationCustomerTransferSlipsSearchQuery, PagedResult<CustomerTransferSlipSearchDto>>
    {
        private readonly IMapper mapper;
        private readonly ICustomerTransferSlipService customerTransferSlipService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationCustomerTransferSlipsSearchHandler(IMapper mapper
            , ICustomerTransferSlipService customerTransferSlipService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.customerTransferSlipService = customerTransferSlipService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<CustomerTransferSlipSearchDto>> Handle(GetPaginationCustomerTransferSlipsSearchQuery request,
          CancellationToken cancellationToken)
        {
            var customerTransferSlipsSearch = customerTransferSlipService.GetCustomerTransferSlipsSearch(request.SearchRequest.PagingParameters, request.SearchRequest);
            var result = mapper.Map<PagedResult<CustomerTransferSlip>, PagedResult<CustomerTransferSlipSearchDto>>(customerTransferSlipsSearch);
            PagingHelper.AddPagingMetadata(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}