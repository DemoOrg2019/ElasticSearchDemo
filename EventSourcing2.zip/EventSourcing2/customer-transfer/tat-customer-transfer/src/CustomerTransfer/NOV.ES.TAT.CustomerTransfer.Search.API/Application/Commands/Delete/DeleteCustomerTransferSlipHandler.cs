﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.CustomerTransfer.DomainService;
using System.Net;
using System.Net.Mime;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Application.Commands
{
    public class DeleteCustomerTransferSlipHandler : ICommandHandler<DeleteCustomerTransferSlipCommand, ContentResult>
    {
        private readonly ICustomerTransferSlipService customerTransferSlipService;

        public DeleteCustomerTransferSlipHandler(
            ICustomerTransferSlipService customerTransferSlipService)
        {
            this.customerTransferSlipService = customerTransferSlipService;
        }
        public Task<ContentResult> Handle(DeleteCustomerTransferSlipCommand request, CancellationToken cancellationToken)
        {
            ContentResult contentResult = new()
            {
                ContentType = MediaTypeNames.Application.Json
            };
            if (!IsValidRequest(request))
            {
                contentResult.Content = JsonConvert.SerializeObject("Value can not be null or Empty");
                contentResult.StatusCode = (int)HttpStatusCode.BadRequest;
                return Task.FromResult(contentResult);
            }
            bool result = customerTransferSlipService.DeleteCustomerTransferSlip(request.Id);
            if (result)
                contentResult.StatusCode = (int)HttpStatusCode.OK;

            return Task.FromResult(contentResult);
        }
        private static bool IsValidRequest(DeleteCustomerTransferSlipCommand request)
        {
            return (request != null && request.Id != Guid.Empty);
        }
    }
}