﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.API.Helper;
using NOV.ES.TAT.CustomerTransfer.Domain;
using NOV.ES.TAT.CustomerTransfer.DomainService;
using NOV.ES.TAT.CustomerTransfer.Infrastructure.Helper;

namespace NOV.ES.TAT.CustomerTransfer.API.Application.Queries
{
    public class GetPaginationSearchCustomerTransferSlipsHandler
           : IQueryHandler<GetPaginationSearchCustomerTransferSlipsQuery, PagedResult<SearchCustomerTransferSlipDto>>
    {
        private readonly ILogger<GetPaginationSearchCustomerTransferSlipsHandler> logger;
        private readonly IMapper mapper;
        private readonly ICustomerTransferSlipService customerTransferSlipService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationSearchCustomerTransferSlipsHandler(ILogger<GetPaginationSearchCustomerTransferSlipsHandler> logger
            ,IMapper mapper
            , ICustomerTransferSlipService customerTransferSlipService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.logger = logger;
            this.mapper = mapper;
            this.customerTransferSlipService = customerTransferSlipService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<SearchCustomerTransferSlipDto>> Handle(GetPaginationSearchCustomerTransferSlipsQuery request,
          CancellationToken cancellationToken)
        {
            var customerTransferSlipsSearch = customerTransferSlipService.GetCustomerTransferSlipsSearch(request.PagingParameters, request.SearchRequest);
            var result = mapper.Map<PagedResult<CustomerTransferSlip>, PagedResult<SearchCustomerTransferSlipDto>>(customerTransferSlipsSearch);
            PagingHelper.AddPagingMetadata(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}