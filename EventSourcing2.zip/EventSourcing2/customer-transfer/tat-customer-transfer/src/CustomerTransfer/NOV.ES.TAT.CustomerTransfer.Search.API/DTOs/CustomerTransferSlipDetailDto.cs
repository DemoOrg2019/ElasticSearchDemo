﻿using NOV.ES.Framework.Core.DTOs;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.DTOs
{
    public class CustomerTransferSlipDetailDto : BaseModel<Guid>
    {
        public Guid CustomerTransferId { get; set; }
        public string ItemType { get; set; }
        public string SubItemType { get; set; }
        public string LineType { get; set; }
        public Guid ItemId { get; set; }
        public string ItemSerialNumber { get; set; }
        public string ItemName { get; set; }
        public string ItemDescription { get; set; }
        public Guid? UsageId { get; set; }
        public Guid? LocationId { get; set; }
        public string LocationName { get; set; }
        public Guid? SizeId { get; set; }
        public string SizeValue { get; set; }
        public Guid? LobeId { get; set; }
        public string Lobe { get; set; }
        public Guid? StageId { get; set; }
        public string Stage { get; set; }
        public decimal? QuantityShipped { get; set; }
        public string Comments { get; set; }
        public bool? NonInventoryItem { get; set; }
        public bool? IsDisplayOnPrint { get; set; }
        public Guid? TopConnJointTypeId { get; set; }
        public string TopConnJointTypeDesc { get; set; }
        public Guid? TopConnTypeId { get; set; }
        public string TopConnTypeDesc { get; set; }
        public Guid? BottomConnJointTypeId { get; set; }
        public string BottomConnJointTypeDesc { get; set; }
        public Guid? BottomConnTypeId { get; set; }
        public string BottomConnTypeDesc { get; set; }
        public string LeasingType { get; set; }
        public string Currency { get; set; }
        public decimal? ItemValue { get; set; }
        public int? CommunityFlag { get; set; }
        public string FieldTicket { get; set; }
        public string RotorHeatNumber { get; set; }
        public string StatorHeatNumber { get; set; }
        public double? RotorOD { get; set; }
        public double? StatorID { get; set; }
        public bool? IsIntendedUseOnLand { get; set; }
        public string BitType { get; set; }
        public string HTS { get; set; }
        public string ErrorMessage { get; set; }
        public string PartNumber { get; set; }
        public string PartDescription { get; set; }
        public string NewPartNumber { get; set; }
        public string NewPartDescription { get; set; }
        public int SequenceNumber { get; set; }
        public bool? IsThresholdOverride { get; set; }
        public string ThresholdOverridenBy { get; set; }
        public string ErpDocType { get; set; }
        public string ErpDocNumber { get; set; }
        public string ErpLocation { get; set; }
        public string ErpLocationZone { get; set; }
        public string ErpLotStatus { get; set; }
        public Guid? LastErpSoftCommitmentId { get; set; }
        public bool? LastActionCompleted { get; set; }
        public bool? IsCompleted { get; set; }
        public Guid? StationaryValvePlateSizeId { get; set; }
        public Guid? OscilaltingValvePlateSizeId { get; set; }
        public virtual CustomerTransferSlipDto CustomerTransferSlipDto { get; set; }
    }
}
