﻿using NOV.ES.Framework.Core.Entities;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.DTOs
{
    public class CustomerTransferSnapShotDto : BaseEntity<Guid>
    {
        public Guid EventId { get; set; }
        public Guid CustomerTransferId { get; set; }
        public string PreviousData { get; set; }
        public string CurrentData { get; set; }
        public string ChangedData { get; set; }
    }
}
