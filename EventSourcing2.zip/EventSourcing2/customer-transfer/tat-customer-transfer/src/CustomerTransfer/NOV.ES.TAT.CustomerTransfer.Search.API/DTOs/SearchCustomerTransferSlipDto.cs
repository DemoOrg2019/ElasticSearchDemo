﻿using NOV.ES.Framework.Core.DTOs;

namespace NOV.ES.TAT.CustomerTransfer.API.DTOs
{
    public class SearchCustomerTransferSlipDto
    {
        public int CustomerTransferSlip { get; set; } //CustomerTransferNumber
        public DateTime Slipdate { get; set; } // SlipDate
        public DateTime Dateout { get; set; } // UsageDate
        public string Company { get; set; } // CompanyName      if NULL call MDM.Company matching with CompanyId
        public string RevenueBU { get; set; } //BusinessUnit  if NULL call MDM.BusinessUnit matching with BusinessUnitId. “(BU Code) BU Name” (Eg: (5316553) DH CA NISKU)
        public string Customer { get; set; } //CustomerName “Customer Name (Customer Code)” (Eg: Obsidian Energy ltd (156182))
        public string RigName { get; set; } //RigName
        public string Operator { get; set; } // OilCompanyName
        public string SendingBU { get; set; } // SendingBuName   “(BU Code) BU Name” (Eg: (5316553) DH CA NISKU)
        public string ItemCount { get; set; }  // Take Count of Details
        public string Createdby { get; set; }  // ModifiedBy
        public string Status { get; set; }  //  IsCompleted
        public string NOVJob { get; set; }  //  ErpJobNumber
        public List<SearchCustomerTransferSlipDetailDto> SearchCustomerTransferSlipDetailDtos { get; set; }
    }
}
