﻿using NOV.ES.Framework.Core.DTOs;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.DTOs
{
    public class CustomerTransferSlipDetailSearchDto
    {
        public Guid Id { get; set; }
        public Guid CustomerTransferId { get; set; }
        public string ItemType { get; set; }
        public string Name { get; set; }  
        public string Part { get; set; }  
        public string Serial { get; set; }  
        public string Quantity { get; set; }  
        public string Size { get; set; } 
        public string UsageNumber { get; set; } 
    }
}
