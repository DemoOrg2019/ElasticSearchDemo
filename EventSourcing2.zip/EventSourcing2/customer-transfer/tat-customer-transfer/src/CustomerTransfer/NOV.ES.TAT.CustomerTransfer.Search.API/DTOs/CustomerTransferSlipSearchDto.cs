﻿using NOV.ES.Framework.Core.DTOs;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.DTOs
{
    public class CustomerTransferSlipSearchDto
    {
        public Guid Id { get; set; }
        public int CustomerTransferSlipNumber { get; set; } 
        public DateTime SlipDate { get; set; } 
        public DateTime DateOut { get; set; } 
        public string Company { get; set; }
        public string CompanyCode { get; set; }
        public string RevenueBu { get; set; }
        public string RevenueBuCode { get; set; }
        public string Customer { get; set; }
        public Int64 CustomerCode { get; set; }
        public string RigName { get; set; }
        public string ContractorName { get; set; }
        public string Operator { get; set; } 
        public string SendingBu { get; set; }
        public string SendingBuCode { get; set; }
        public string ItemCount { get; set; } 
        public string CreatedBy { get; set; } 
        public string Status { get; set; } 
        public string NOVJob { get; set; }  
        public List<CustomerTransferSlipDetailSearchDto> CustomerTransferSlipDetails { get; set; }
    }
}
