﻿using NOV.ES.Framework.Core.DTOs;

namespace NOV.ES.TAT.CustomerTransfer.API.DTOs
{
    public class SearchCustomerTransferSlipDetailDto
    {
        public Guid Id { get; set; }

        public string ItemType { get; set; }
        public string Name { get; set; }  //  ItemType
        public string Part { get; set; }  //  PartNumber
        public string Serial { get; set; }  //  ItemSerialNumber
        public string Quantity { get; set; }  //  QuantityShipped
        public string Size { get; set; }  //  SizeValue
        public string UsageNumber { get; set; }  //  UsageId
    }
}
