﻿using AutoMapper;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure.Helper;

namespace NOV.ES.TAT.CustomerTransfer.Search.API.Helper
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<CustomerTransferSlipDetail, CustomerTransferSlipDetailDto>();
            CreateMap<CustomerTransferSlipDetailDto, CustomerTransferSlipDetail>();
            CreateMap<PagedResult<CustomerTransferSlipDetail>, PagedResult<CustomerTransferSlipDetailDto>>();
            CreateMap<CustomerTransferSlip, CustomerTransferSlipDto>();
            CreateMap<CustomerTransferSlipDto, CustomerTransferSlip>();
            CreateMap<PagedResult<CustomerTransferSlip>, PagedResult<CustomerTransferSlipDto>>();

            CreateMap<CustomerTransferSnapShot, CustomerTransferSnapShotDto>();
            CreateMap<CustomerTransferSnapShotDto, CustomerTransferSnapShot>();
            CreateMap<PagedResult<CustomerTransferSnapShot>, PagedResult<CustomerTransferSnapShotDto>>();


            CreateMap<CustomerTransferSlip, CustomerTransferSlipSearchDto>()
                .ForMember(dest => dest.CustomerTransferSlipNumber, orig => orig.MapFrom(row => row.CustomerTransferNumber))
                .ForMember(dest => dest.SlipDate, orig => orig.MapFrom(row => row.SlipDate))
                .ForMember(dest => dest.DateOut, orig => orig.MapFrom(row => row.UsageDate))
                .ForMember(dest => dest.Company, orig => orig.MapFrom(row => "(" + row.CompanyCode + ") " + row.CompanyName))
                .ForMember(dest => dest.RevenueBu, orig => orig.MapFrom(row => "(" + row.BusinessUnitCode + ") " + row.BusinessUnitName))
                .ForMember(dest => dest.Customer, orig => orig.MapFrom(row => "(" + row.CustomerCode + ") " + row.CustomerName))
                .ForMember(dest => dest.RigName, orig => orig.MapFrom(row => row.ContractorName + " (" + row.RigName + ")"))
                .ForMember(dest => dest.Operator, orig => orig.MapFrom(row => row.OilCompanyName))
                .ForMember(dest => dest.SendingBu, orig => orig.MapFrom(row => "(" + row.SendingBuCode + ") " + row.SendingBuName))
                .ForMember(dest => dest.CreatedBy, orig => orig.MapFrom(row => row.ModifiedBy))
                .ForMember(dest => dest.Status, orig => orig.MapFrom(row => row.IsCompleted == true ? "Completed" : "Open"))
                .ForMember(dest => dest.NOVJob, orig => orig.MapFrom(row => row.ErpJobNumber))
                .ForMember(dest => dest.ItemCount, orig => orig.MapFrom(row => row.CustomerTransferSlipDetails.Count))
                .ForMember(dest => dest.CustomerTransferSlipDetails, orig => orig.MapFrom(row => row.CustomerTransferSlipDetails));

            CreateMap<CustomerTransferSlipDetail, CustomerTransferSlipDetailSearchDto>()
               .ForMember(dest => dest.ItemType, orig => orig.MapFrom(row => row.ItemType))
               .ForMember(dest => dest.Name, orig => orig.MapFrom(row => row.ItemName))
               .ForMember(dest => dest.Part, orig => orig.MapFrom(row => row.PartNumber))
               .ForMember(dest => dest.Serial, orig => orig.MapFrom(row => row.ItemSerialNumber))
               .ForMember(dest => dest.Quantity, orig => orig.MapFrom(row => row.QuantityShipped))
               .ForMember(dest => dest.UsageNumber, orig => orig.MapFrom(row => row.UsageId))
               .ForMember(dest => dest.Size, orig => orig.MapFrom(row => row.SizeValue));

            CreateMap<PagedResult<CustomerTransferSlip>, PagedResult<CustomerTransferSlipSearchDto>>();
            CreateMap<PagedResult<CustomerTransferSlipDetail>, PagedResult<CustomerTransferSlipSearchDto>>();
        }
    }
}
