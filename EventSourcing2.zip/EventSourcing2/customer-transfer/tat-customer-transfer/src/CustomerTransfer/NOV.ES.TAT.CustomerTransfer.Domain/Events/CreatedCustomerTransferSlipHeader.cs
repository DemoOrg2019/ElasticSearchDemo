﻿using NOV.ES.Framework.Core.Domain;
using NOV.ES.TAT.CustomerTransfer.Domain.WriteModels;

namespace NOV.ES.TAT.CustomerTransfer.Domain.Events
{
    public class CreatedCustomerTransferSlipHeader 
        : DomainEvent<Guid>
    {
        public CustomerTransferSlipHeader Header { get; private set; }
        public CreatedCustomerTransferSlipHeader(CustomerTransferSlipHeader header, string actionBy)
            : base(header.CustomerTransferSlipId)
        {
             EventType = this.GetType().FullName + ", " + this.GetType().Assembly.GetName().Name;
            //EventType = this.GetType().Name;
            Header = header;
            ActionBy = actionBy;
        }
    }
}
