﻿using NOV.ES.Framework.Core.Domain;
using NOV.ES.TAT.CustomerTransfer.Domain.WriteModels;

namespace NOV.ES.TAT.CustomerTransfer.Domain.Events
{
    public class AddedItemsToCustomerTransferSlip
        : DomainEvent<Guid>
    {
        public CustomerTransferSlipDetail Detail { get; private set; }
        public AddedItemsToCustomerTransferSlip(CustomerTransferSlipDetail detail, long aggregateVersion)
            : base(detail.CustomerTransferSlipId, aggregateVersion)
        {
            EventType = this.GetType().FullName + ", " + this.GetType().Assembly.GetName().Name;
            Detail = detail;
        }
    }
}
