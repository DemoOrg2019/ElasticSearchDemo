﻿namespace NOV.ES.TAT.CustomerTransfer.Domain.WriteModels
{
    public class CommericialInfo
    {
        public string Currency { get; set; }
        public string Verbiage { get; set; }
        public string VatNo { get; set; }
        public string Comments { get; set; }

        public CommericialInfo()
        {
        }
    }
}
