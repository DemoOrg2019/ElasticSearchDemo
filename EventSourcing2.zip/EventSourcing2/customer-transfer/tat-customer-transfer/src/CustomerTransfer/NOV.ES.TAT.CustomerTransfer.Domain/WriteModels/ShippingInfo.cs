﻿using NOV.ES.Framework.Core.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NOV.ES.TAT.CustomerTransfer.Domain.WriteModels
{
    public class ShippingInfo
    {
        public string PreparedBy { get; set; }
        public string BillOfLading { get; set; }
        public string CheckedBy { get; set; }
        public string WayBill { get; set; }
        public Guid FreightTypeId { get; set; }
        public string FreightType { get; set; }
        public string FieldTicket { get; set; }
        public string ShippingInstruction { get; set; }
        public string ForwardingInstruction { get; set; }

        public ShippingInfo()
        {

        }

    }
}
