﻿namespace NOV.ES.TAT.CustomerTransfer.Domain.WriteModels
{
    public class CustomerSalesInfo
    {
        public int? ErpJobNumber { get; set; }
        public Guid CompanyId { get; set; }
        public Guid RevenuBuId { get; set; } // OilCompanyId
        public Guid SendingBuId { get; set; } // 
        public int SendingLocationId { get; set; } //        
        public Guid CustomerId { get; set; }
        public string ShipTo { get; set; } // Ship To Address
        public Guid? ActualCustomerId { get; set; } // EffectiveCustomerId
        public Guid SalesZoneId { get; set; }
        public string CustomerPONumber { get; set; }
        public string CustomerContactPerson { get; set; }
        public string CustomerContactNumber { get; set; }
        public string CustomerJobNumber { get; set; }
        public Guid? SalesPersonId { get; set; }
        public DateTime SlipDate { get; set; }
        public string RentalAgreement { get; set; }
        public CommericialInfo CommericialInfo { get; set; }
        public CustomerSalesInfo()
        {
        }
    }
}
