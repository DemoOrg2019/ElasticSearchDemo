﻿using NOV.ES.Framework.Core.Domain;
using NOV.ES.Framework.Core.Entities;
using NOV.ES.TAT.CustomerTransfer.Domain.Events;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NOV.ES.TAT.CustomerTransfer.Domain.WriteModels
{
    public class CustomerTransferSlip : AggregateRoot<Guid>
    {
        public CustomerTransferSlipHeader Header { get; private set; }
        public CustomerTransferSlipDetail Detail { get; private set; }
        public CustomerTransferSlip()
        {

        }

        public CustomerTransferSlip(Guid aggregateRootId)
            : base()
        {
            Id = aggregateRootId;
            Detail = new CustomerTransferSlipDetail();
            Detail.CustomerTransferSlipId = aggregateRootId;
        }

        public void CreateHeader(CustomerTransferSlipHeader header)
        {
            Id = header.CustomerTransferSlipId;
            Header = header;
            Apply(new CreatedCustomerTransferSlipHeader(Header, "tatuser@nov.com"));
        }

        public void AddItems(CustomerTransferSlipDetail detail, long aggregateVersion)
        {
            LastEventSequence = aggregateVersion;
            if(Detail == null)
            {
                Detail = new CustomerTransferSlipDetail(detail.CustomerTransferSlipId);
            }

            Detail.Items.AddRange(detail.Items);

            Apply(new AddedItemsToCustomerTransferSlip(Detail, aggregateVersion));
        }
    }
}