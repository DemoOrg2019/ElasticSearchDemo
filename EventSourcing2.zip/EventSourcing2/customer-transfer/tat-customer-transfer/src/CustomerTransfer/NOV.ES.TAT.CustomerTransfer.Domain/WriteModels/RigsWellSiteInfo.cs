﻿namespace NOV.ES.TAT.CustomerTransfer.Domain.WriteModels
{
    public class RigsWellSiteInfo
    {
        public int? RigId { get; set; }
        public string RigJDEName { get; set; }
        public bool IsUseIntendOnLand { get; set; }
        public int? WellSiteId { get; set; }
        public string CountyLsd { get; set; }
        public Guid Operator { get; set; } // Oil Company Id
        public string OcsgNumber { get; set; }
        public Guid? DrillingApplicationId { get; set; }
        public Guid? BillingApplicationId { get; set; }

        public RigsWellSiteInfo()
        {
        }

    }
}
