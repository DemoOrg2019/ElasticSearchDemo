﻿using NOV.ES.Framework.Core.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NOV.ES.TAT.CustomerTransfer.Domain.WriteModels
{
    public class CustomerTransferSlipDetail 
    {
        public Guid CustomerTransferSlipId { get; set; }
        public List<CustomerTransferSlipItem> Items { get; set; }

        public CustomerTransferSlipDetail()
        {
            Items = new List<CustomerTransferSlipItem>();
        }

        public CustomerTransferSlipDetail(Guid customerTransferSlipId)
            :this()
        {
            CustomerTransferSlipId = customerTransferSlipId;
        }

    }

    public enum ItemType
    {
        T,
        M,
        C,
        J
    }

    public class CustomerTransferSlipItem
    {
        public Guid ItemId { get; set; }
        public ItemType? ItemType { get; set; }
        public int QuantityShipped { get; set; }
        public int SequenceNumber { get; set; }
        public bool IsCompleted { get; set; }

    }
}
