﻿namespace NOV.ES.TAT.CustomerTransfer.Domain.WriteModels
{
    public class CustomerTransferSlipHeader
    {
        public Guid CustomerTransferSlipId { get; set; }
        public CustomerSalesInfo CustomerSalesInfo { get; set; }
        public RigsWellSiteInfo RigsWellSiteInfo { get; set; }
        public ShippingInfo ShippingInfo { get; set; }
        public CustomerTransferSlipHeader()
        {
        }
    }
}
