﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.CustomerTransfer.Domain.ReadModels
{
    public class CustomerTransferSlipHeaderCreatedEventDetail
    {
        public Guid CustomerTransferSlipId { get; }
        public string ChangeDetailJson { get; }
        public DateTime EventDate { get; }
        public string ActionBy { get; }

        public CustomerTransferSlipHeaderCreatedEventDetail(
            Guid customerTransferSlipId,
            string changeDetailJson,
            DateTime eventDate,
            string actionBy
            )
        {
            CustomerTransferSlipId = customerTransferSlipId;
            ChangeDetailJson = changeDetailJson;
            EventDate = eventDate;
            ActionBy = actionBy;
        }
    }
}
