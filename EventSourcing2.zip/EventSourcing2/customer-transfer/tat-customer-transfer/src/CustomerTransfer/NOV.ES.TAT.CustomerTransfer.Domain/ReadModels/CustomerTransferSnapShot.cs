﻿using NOV.ES.Framework.Core.Entities;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using System.ComponentModel.DataAnnotations.Schema;

namespace NOV.ES.TAT.CustomerTransfer.Domain.ReadModels
{
    [Table("CustomerTransferSnapShot")]
    public class CustomerTransferSnapShot : BaseEntity<Guid>
    {
        public Guid EventId { get; set; }
        public Guid CustomerTransferId { get; set; }
        public string PreviousData { get; set; }
        public string CurrentData { get; set; }
        public string ChangedData { get; set; }
        [ForeignKey("CustomerTransferId")]
        public virtual CustomerTransferSlip CustomerTransferSlip { get; set; }
    }
}
