﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.CustomerTransfer.Domain.ReadModels
{
    [Table("CustomerTransferSlipAuditLog")]
    public class CustomerTransferSlipAuditLog
    {
        [Required]
        public Guid Id { get; set; }
        [Required]
        public Guid CustomerTransferSlipId { get; set; }
        [Required]
        public long Version { get; set; }

        [Required]
        [Column(TypeName = "varchar(MAX)")]
        public string CurrentStateJson { get; set; }

        [Required]
        [Column(TypeName = "varchar(MAX)")]
        public string ChangeDataJson { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }

        [Required]
        public string ActionBy { get; set; }
    }
}
