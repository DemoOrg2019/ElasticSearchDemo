﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.Domain;
using NOV.ES.Framework.Core.EventStore;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.Framework.Core.Serializer;
using NOV.ES.TAT.CustomerTransfer.Domain.Events;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.Projection.DomainService.PublishEvents;
using NOV.ES.TAT.CustomerTransfer.Projection.Infrastructure;

namespace NOV.ES.TAT.CustomerTransfer.Projection.DomainService
{
    public class CustomerTransferSlipProjectionService
         : ICustomerTransferSlipProjectionService
    {
        private readonly ILogger<CustomerTransferSlipProjectionService> logger;
        private readonly IEventStore eventStore;
        private readonly ICustomerTransferSlipProjectionRepository customerTransferSlipProjectionRepository;
        private readonly IIntegrationEventBus integrationEventBus;

        private readonly Dictionary<string,
            Func<DomainEvent<Guid>,
                Domain.ReadModels.CustomerTransferSlip,
                bool,
                Domain.ReadModels.CustomerTransferSlip>> eventProcessors =
            new Dictionary<string,
                Func<DomainEvent<Guid>,
                    Domain.ReadModels.CustomerTransferSlip,
                    bool,
                     Domain.ReadModels.CustomerTransferSlip>>();
        public CustomerTransferSlipProjectionService(
            ILogger<CustomerTransferSlipProjectionService> logger,
            IEventStore eventStore,
            ICustomerTransferSlipProjectionRepository customerTransferSlipProjectionRepository,
            IIntegrationEventBus integrationEventBus)
        {
            this.logger = logger;
            this.eventStore = eventStore;
            this.customerTransferSlipProjectionRepository = customerTransferSlipProjectionRepository;
            this.integrationEventBus = integrationEventBus;
            InitEventProcessors();
        }

        private void InitEventProcessors()
        {
            eventProcessors.Add(GetTypeName(typeof(CreatedCustomerTransferSlipHeader)), ProcessCreatedCustomerTransferSlipHeader);
            eventProcessors.Add(GetTypeName(typeof(AddedItemsToCustomerTransferSlip)), ProcessAddedItemsToCustomerTransferSlip);
        }

        private string GetTypeName(Type type)
        {
            return type.FullName + ", " + type.Assembly.GetName().Name;
        }

        public Task CreateCustomerTransferProjectionAsync(Guid customerTransferSlipId)
        {
            // TODO: Ensure a single instnace/Process will be processing CustomerTransferSlipId -- Maintain Status in Table as Processing with TimeStamp
            var existingCustomerTransferSlip = customerTransferSlipProjectionRepository.GetById(customerTransferSlipId).Result;
            var lastSequence = existingCustomerTransferSlip == null ? 0 : existingCustomerTransferSlip.AggregateVersion;

            var events = eventStore.GetEvents(customerTransferSlipId, lastSequence);
            Domain.ReadModels.CustomerTransferSlip customerTransferSlip = existingCustomerTransferSlip;
            bool isNewCustomerTransferSlip = existingCustomerTransferSlip == null;

            if (events != null)
            {
                var sequentialEvents = events.OrderBy(e => e.AggregateVersion);

                foreach (var domainEvent in sequentialEvents)
                {
                    if (eventProcessors.ContainsKey(domainEvent.EventType))
                    {
                        customerTransferSlip = eventProcessors[domainEvent.EventType](domainEvent, 
                            customerTransferSlip, isNewCustomerTransferSlip);                        
                        isNewCustomerTransferSlip = customerTransferSlip == null;
                    }
                }
            }

            

            return Task.CompletedTask;
        }

        private Domain.ReadModels.CustomerTransferSlip Save(Domain.ReadModels.CustomerTransferSlip customerTransferSlip, bool isNewCustomerTransferSlip)
        {
            if (customerTransferSlip == null)
            {
                return null;
            }

            if (isNewCustomerTransferSlip)
            {
                customerTransferSlipProjectionRepository.Create(customerTransferSlip);

            }
            else
            {
                customerTransferSlipProjectionRepository.UpdateCustomerTransferSlip(customerTransferSlip);
            }

            customerTransferSlipProjectionRepository.SaveChanges();

            return customerTransferSlipProjectionRepository.GetById(customerTransferSlip.Id).Result;
        }

        private void SaveAuditLog(Domain.ReadModels.CustomerTransferSlip customerTransferSlip, DomainEvent<Guid> domainEvent)
        {
            if(customerTransferSlip != null)
            {
                var auditLog = new CustomerTransferSlipAuditLog
                {
                    CustomerTransferSlipId = customerTransferSlip.Id,
                    Version = customerTransferSlip.AggregateVersion,
                    CurrentStateJson = JsonConvert.SerializeObject(customerTransferSlip, 
                    Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        ReferenceLoopHandling = ReferenceLoopHandling.Serialize
                    }),
                    ChangeDataJson = JsonConvert.SerializeObject(domainEvent,
                    Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        ReferenceLoopHandling = ReferenceLoopHandling.Serialize
                    }),
                    CreatedDate = customerTransferSlip.DateModified,
                    ActionBy = customerTransferSlip.ModifiedBy ?? customerTransferSlip.CreatedBy

                };

                customerTransferSlipProjectionRepository.CreateAuditLog(auditLog);
                customerTransferSlipProjectionRepository.SaveChanges();
            }
        }

        private void SaveProjectionAndAudit(DomainEvent<Guid> domainEvent, CustomerTransferSlip customerTransferSlip, bool isNewCustomerTransferSlip)
        {
            // Save Projection
            customerTransferSlip = Save(customerTransferSlip, isNewCustomerTransferSlip);

            // Save AuditLog
            SaveAuditLog(customerTransferSlip, domainEvent);
        }

        protected Domain.ReadModels.CustomerTransferSlip ProcessCreatedCustomerTransferSlipHeader(DomainEvent<Guid> domainEvent,
            Domain.ReadModels.CustomerTransferSlip customerTransferSlip,
            bool isNewCustomerTransferSlip)
        {
            var newCustomerTransferSlip = new Domain.ReadModels.CustomerTransferSlip();
            CreatedCustomerTransferSlipHeader headerEvent = domainEvent as CreatedCustomerTransferSlipHeader;

            // Do Mapping
            MapHeaderEventToCustomerTransferSlip(newCustomerTransferSlip, headerEvent);

            // Save Projection and AuditLog
            SaveProjectionAndAudit(domainEvent, newCustomerTransferSlip, isNewCustomerTransferSlip);

            // Publish CustmerTransferHeaderCreatedProjectionSuccess

            CustomerTransferSlipHeaderCreatedEventDetail ctsHeadetCreatedEventDetail =
                new(newCustomerTransferSlip.Id,
                "{}",
                newCustomerTransferSlip.DateModified,
                newCustomerTransferSlip.ModifiedBy
                );

            CreatedCustomerTransferHeaderProjectionAuditSaveSuccess success =
            new(
                newCustomerTransferSlip.Id,
                Guid.NewGuid(),
                JsonConvert.SerializeObject(ctsHeadetCreatedEventDetail),
                newCustomerTransferSlip.DateModified,
                SagaEventExecutionResult.Success,
                newCustomerTransferSlip.ModifiedBy
                );

            integrationEventBus.Publish(success);

            return newCustomerTransferSlip;
        }

       

        private void MapHeaderEventToCustomerTransferSlip(CustomerTransferSlip newCustomerTransferSlip, CreatedCustomerTransferSlipHeader headerEvent)
        {
            if (headerEvent != null)
            {
                newCustomerTransferSlip.Id = headerEvent.Header.CustomerTransferSlipId;
                newCustomerTransferSlip.AggregateVersion = headerEvent.AggregateVersion;
                newCustomerTransferSlip.CustomerTransferNumber = 1;
                newCustomerTransferSlip.CompanyId = headerEvent.Header.CustomerSalesInfo.CompanyId;
                newCustomerTransferSlip.CompanyName = "";
                newCustomerTransferSlip.SlipDate = headerEvent.Header.CustomerSalesInfo.SlipDate;
                newCustomerTransferSlip.UsageDate = DateTime.Now;
                newCustomerTransferSlip.OilCompanyId = headerEvent.Header.CustomerSalesInfo.SendingBuId;
                newCustomerTransferSlip.OilCompanyName = "";
                newCustomerTransferSlip.ErpJobNumber = headerEvent.Header.CustomerSalesInfo.ErpJobNumber;
                newCustomerTransferSlip.CustomerJobNumber = headerEvent.Header.CustomerSalesInfo.CustomerJobNumber;
                newCustomerTransferSlip.CustomerId = headerEvent.Header.CustomerSalesInfo.CustomerId;
                newCustomerTransferSlip.CustomerName = "";
                newCustomerTransferSlip.EffectiveCustomerId = headerEvent.Header.CustomerSalesInfo.ActualCustomerId;
                newCustomerTransferSlip.EffectiveCustomerName = "";

                newCustomerTransferSlip.BusinessUnitId = headerEvent.Header.CustomerSalesInfo.SendingBuId;
                newCustomerTransferSlip.BusinessUnitName = "";

                newCustomerTransferSlip.HeaderAddress = "";
                newCustomerTransferSlip.HeaderPhone = "";
                newCustomerTransferSlip.HeaderFax = "";
                newCustomerTransferSlip.CustomerContact = headerEvent.Header.CustomerSalesInfo.CustomerContactPerson;
                newCustomerTransferSlip.CustomerPhoneNumber = headerEvent.Header.CustomerSalesInfo.CustomerContactNumber;



                newCustomerTransferSlip.RigId = headerEvent.Header.RigsWellSiteInfo.RigId;
                newCustomerTransferSlip.CorpRigId = null;
                newCustomerTransferSlip.RigName = "";
                newCustomerTransferSlip.RigJDEName = headerEvent.Header.RigsWellSiteInfo.RigJDEName;
                newCustomerTransferSlip.WellSiteId = headerEvent.Header.RigsWellSiteInfo.WellSiteId;
                newCustomerTransferSlip.CorpWellSiteId = null;
                newCustomerTransferSlip.WellName = "";
                newCustomerTransferSlip.WellLocation = "";
                newCustomerTransferSlip.WellNameSource = "";
                newCustomerTransferSlip.DrillingApplicationId = headerEvent.Header.RigsWellSiteInfo.DrillingApplicationId;
                newCustomerTransferSlip.DrillingApplicationName = "";
                newCustomerTransferSlip.BillingApplicationId = headerEvent.Header.RigsWellSiteInfo.BillingApplicationId;
                newCustomerTransferSlip.BillingApplicationName = "";


                newCustomerTransferSlip.ShipVia = "";
                newCustomerTransferSlip.ShippedBy = "";


                newCustomerTransferSlip.FreightTypeId = headerEvent.Header.ShippingInfo.FreightTypeId;
                newCustomerTransferSlip.FreightType = headerEvent.Header.ShippingInfo.FreightType;
                newCustomerTransferSlip.BillOfLading = headerEvent.Header.ShippingInfo.BillOfLading;
                newCustomerTransferSlip.WayBill = headerEvent.Header.ShippingInfo.WayBill;
                newCustomerTransferSlip.GLCode = "";

                newCustomerTransferSlip.SalesPersonId = headerEvent.Header.CustomerSalesInfo.SalesPersonId;
                newCustomerTransferSlip.SalesPersonName = "";
                newCustomerTransferSlip.CheckedBy = headerEvent.Header.ShippingInfo.CheckedBy;
                newCustomerTransferSlip.SendingLocationId = null;
                newCustomerTransferSlip.SendingLocationName = "";
                newCustomerTransferSlip.SendingBuId = headerEvent.Header.CustomerSalesInfo.SendingBuId;
                newCustomerTransferSlip.SendingBuName = "";
                newCustomerTransferSlip.SendingBuTempId = null;
                newCustomerTransferSlip.SendingBuTempName = "";
                newCustomerTransferSlip.LsdCounty = headerEvent.Header.RigsWellSiteInfo.CountyLsd;
                newCustomerTransferSlip.OcsgNumber = headerEvent.Header.RigsWellSiteInfo.OcsgNumber;
                newCustomerTransferSlip.Verbiage = "";
                newCustomerTransferSlip.Comments = headerEvent.Header.CustomerSalesInfo.CommericialInfo.Comments;
                newCustomerTransferSlip.Currency = headerEvent.Header.CustomerSalesInfo.CommericialInfo?.Currency;
                newCustomerTransferSlip.VatNo = headerEvent.Header.CustomerSalesInfo.CommericialInfo?.VatNo;
                newCustomerTransferSlip.SlipType = "";
                newCustomerTransferSlip.ErrorMessage = "";
                newCustomerTransferSlip.CustomerPoAfe = "";
                newCustomerTransferSlip.ShipToAddress = "";
                newCustomerTransferSlip.OtherDocInfo = "";
                newCustomerTransferSlip.OtherDocNumber = "";
                newCustomerTransferSlip.IsIntendedUseOnLand = headerEvent.Header.RigsWellSiteInfo.IsUseIntendOnLand;
                newCustomerTransferSlip.RentalAgreement = "";
                newCustomerTransferSlip.ShowChildItemOnCommercialInvoice = null;
                newCustomerTransferSlip.SalesZoneId = headerEvent.Header.CustomerSalesInfo?.SalesZoneId;
                newCustomerTransferSlip.Consignee = headerEvent.Header.ShippingInfo.ShippingInstruction;
                newCustomerTransferSlip.ForwardingInstruction = headerEvent.Header.ShippingInfo?.ForwardingInstruction;
                newCustomerTransferSlip.ErpDocType = "";
                newCustomerTransferSlip.ErpDocNumber = "";
                newCustomerTransferSlip.IsCompleted = false;

            }
        }

        protected Domain.ReadModels.CustomerTransferSlip ProcessAddedItemsToCustomerTransferSlip(DomainEvent<Guid> domainEvent,
            Domain.ReadModels.CustomerTransferSlip customerTransferSlip,
            bool isNewCustomerTransferSlip)
        {
            AddedItemsToCustomerTransferSlip addedItemsToCustomerTransferSlip = domainEvent as AddedItemsToCustomerTransferSlip;
            customerTransferSlip.AggregateVersion = addedItemsToCustomerTransferSlip.AggregateVersion;
            
            // Do Mapping
            MapAddItemsToCustomerTransferSlipDetails(customerTransferSlip, addedItemsToCustomerTransferSlip);

            // Save Projection and AuditLog
            SaveProjectionAndAudit(domainEvent, customerTransferSlip, isNewCustomerTransferSlip);

            return customerTransferSlip;
        }

        private void MapAddItemsToCustomerTransferSlipDetails(CustomerTransferSlip customerTransferSlip, AddedItemsToCustomerTransferSlip addedItemsToCustomerTransferSlip)
        {
            if (customerTransferSlip.CustomerTransferSlipDetails == null)
            {
                customerTransferSlip.CustomerTransferSlipDetails = new List<Domain.ReadModels.CustomerTransferSlipDetail>();
            }

            foreach (var item in addedItemsToCustomerTransferSlip.Detail.Items)
            {
                var customerTransferSlipDetail = new Domain.ReadModels.CustomerTransferSlipDetail();
                customerTransferSlipDetail.CustomerTransferId = addedItemsToCustomerTransferSlip.Detail.CustomerTransferSlipId;
                customerTransferSlipDetail.ItemId = item.ItemId;
                customerTransferSlipDetail.ErrorMessage = "";
                customerTransferSlipDetail.IsCompleted = item.IsCompleted;
                customerTransferSlipDetail.ItemType = "T";
                customerTransferSlipDetail.LineType = "";

                customerTransferSlip.CustomerTransferSlipDetails.Add(customerTransferSlipDetail);
            }
        }
    }
}