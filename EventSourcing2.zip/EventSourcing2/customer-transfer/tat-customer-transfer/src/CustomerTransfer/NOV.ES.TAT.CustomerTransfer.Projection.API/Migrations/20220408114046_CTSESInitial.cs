﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NOV.ES.TAT.CustomerTransfer.Projection.API.Migrations
{
    public partial class CTSESInitial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CustomerTransferSlip",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false, defaultValueSql: "NEWID()"),
                    CustomerTransferNumber = table.Column<int>(type: "int", nullable: false),
                    CompanyId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    CompanyName = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    CompanyCode = table.Column<string>(type: "nvarchar(28)", maxLength: 28, nullable: true),
                    SlipDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UsageDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    OilCompanyId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    OilCompanyName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    RigId = table.Column<int>(type: "int", nullable: true),
                    CorpRigId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    RigName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    RigJDEName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ContractorName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    WellSiteId = table.Column<int>(type: "int", nullable: true),
                    CorpWellSiteId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    WellName = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    WellLocation = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    WellNameSource = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    ErpJobNumber = table.Column<int>(type: "int", nullable: true),
                    CustomerJobNumber = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    ShipVia = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ShippedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CustomerId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CustomerName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CustomerCode = table.Column<long>(type: "bigint", nullable: false),
                    EffectiveCustomerId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    EffectiveCustomerName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    DrillingApplicationId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    DrillingApplicationName = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    BillingApplicationId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    BillingApplicationName = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    BusinessUnitId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    BusinessUnitName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    BusinessUnitCode = table.Column<string>(type: "nvarchar(24)", maxLength: 24, nullable: true),
                    HeaderAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    HeaderPhone = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    HeaderFax = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CustomerContact = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    CustomerPhoneNumber = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    FreightTypeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    FreightType = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    BillOfLading = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    WayBill = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    GLCode = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    SalesPersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SalesPersonName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    CheckedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    SendingLocationId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SendingLocationName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    SendingBuId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SendingBuName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    SendingBuCode = table.Column<string>(type: "nvarchar(24)", maxLength: 24, nullable: true),
                    SendingBuTempId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SendingBuTempName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    LsdCounty = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    OcsgNumber = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    Verbiage = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    Comments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Currency = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    VatNo = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: true),
                    SlipType = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: true),
                    ErrorMessage = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CustomerPoAfe = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: true),
                    ShipToAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OtherDocInfo = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: true),
                    OtherDocNumber = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: true),
                    IsIntendedUseOnLand = table.Column<bool>(type: "bit", nullable: true),
                    RentalAgreement = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    ShowChildItemOnCommercialInvoice = table.Column<bool>(type: "bit", nullable: true),
                    SalesZoneId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Consignee = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ForwardingInstruction = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ErpDocType = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    ErpDocNumber = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: true),
                    IsCompleted = table.Column<bool>(type: "bit", nullable: true),
                    AggregateVersion = table.Column<long>(type: "bigint", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValueSql: "1"),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    DateModified = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreatedSource = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    ModifiedSource = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CustomerTransferSlip", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CustomerTransferSlipAuditLog",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false, defaultValueSql: "NEWID()"),
                    CustomerTransferSlipId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Version = table.Column<long>(type: "bigint", nullable: false),
                    CurrentStateJson = table.Column<string>(type: "varchar(MAX)", nullable: false),
                    ChangeDataJson = table.Column<string>(type: "varchar(MAX)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ActionBy = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CustomerTransferSlipAuditLog", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CustomerTransferSlipDetail",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false, defaultValueSql: "NEWID()"),
                    CustomerTransferId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ItemType = table.Column<string>(type: "nvarchar(1)", maxLength: 1, nullable: false),
                    SubItemType = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: true),
                    LineType = table.Column<string>(type: "nvarchar(1)", maxLength: 1, nullable: false),
                    ItemId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ItemSerialNumber = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    ItemName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ItemDescription = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    UsageId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    LocationId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    LocationName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    SizeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SizeValue = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    LobeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Lobe = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    StageId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Stage = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    QuantityShipped = table.Column<decimal>(type: "decimal(11,3)", nullable: true),
                    Comments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NonInventoryItem = table.Column<bool>(type: "bit", nullable: true),
                    IsDisplayOnPrint = table.Column<bool>(type: "bit", nullable: true),
                    TopConnJointTypeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    TopConnJointTypeDesc = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    TopConnTypeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    TopConnTypeDesc = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    BottomConnJointTypeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    BottomConnJointTypeDesc = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    LeasingType = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: true),
                    BottomConnTypeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    BottomConnTypeDesc = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    Currency = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    ItemValue = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    CommunityFlag = table.Column<int>(type: "int", nullable: true),
                    FieldTicket = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    RotorHeatNumber = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    StatorHeatNumber = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    RotorOD = table.Column<double>(type: "float", nullable: true),
                    StatorID = table.Column<double>(type: "float", nullable: true),
                    IsIntendedUseOnLand = table.Column<bool>(type: "bit", nullable: true),
                    BitType = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    HTS = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    ErrorMessage = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PartNumber = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: true),
                    PartDescription = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    NewPartNumber = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: true),
                    NewPartDescription = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    SequenceNumber = table.Column<int>(type: "int", nullable: false),
                    IsThresholdOverride = table.Column<bool>(type: "bit", nullable: true),
                    ThresholdOverridenBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ErpDocType = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: true),
                    ErpDocNumber = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: true),
                    ErpLocation = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: true),
                    ErpLocationZone = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    ErpLotStatus = table.Column<string>(type: "nvarchar(1)", maxLength: 1, nullable: true),
                    LastErpSoftCommitmentId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    LastActionCompleted = table.Column<bool>(type: "bit", nullable: true),
                    IsCompleted = table.Column<bool>(type: "bit", nullable: true),
                    StationaryValvePlateSizeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    OscilaltingValvePlateSizeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValueSql: "1"),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    DateModified = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreatedSource = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    ModifiedSource = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CustomerTransferSlipDetail", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CustomerTransferSlipDetail_CustomerTransferSlip_CustomerTransferId",
                        column: x => x.CustomerTransferId,
                        principalTable: "CustomerTransferSlip",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_CustomerTransferSlipDetail_CustomerTransferId",
                table: "CustomerTransferSlipDetail",
                column: "CustomerTransferId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CustomerTransferSlipAuditLog");

            migrationBuilder.DropTable(
                name: "CustomerTransferSlipDetail");

            migrationBuilder.DropTable(
                name: "CustomerTransferSlip");
        }
    }
}
