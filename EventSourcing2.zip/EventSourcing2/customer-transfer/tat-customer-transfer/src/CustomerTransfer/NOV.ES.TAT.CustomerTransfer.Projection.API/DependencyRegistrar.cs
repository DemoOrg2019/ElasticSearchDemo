﻿using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.Framework.Core.CQRS.Events;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.EventStore;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Serializer;
using NOV.ES.Infrastructure.EventStore.EFCore;
using NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq;
using NOV.ES.TAT.CustomerTransfer.Projection.API;
using NOV.ES.TAT.CustomerTransfer.Projection.API.Application.IntegrationEvents;
using NOV.ES.TAT.CustomerTransfer.Projection.DomainService;
using NOV.ES.TAT.CustomerTransfer.Projection.Infrastructure;
using Swashbuckle.AspNetCore.Filters;
using System.Reflection;

namespace NOV.ES.TAT.CustomerTransfer.Projection
{
    public static class DependencyRegistrar
    {
        public static IServiceCollection AddCustomMvc(this IServiceCollection services)
        {
            services.AddControllers(
           // options => options.Filters.Add(typeof(HttpGlobalExceptionFilter))
           ).AddNewtonsoftJson(
               joptions =>
               {
                   joptions.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                   joptions.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                   joptions.SerializerSettings.Converters.Add(new StringEnumConverter());
               }
           );
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                    .SetIsOriginAllowed((host) => true)
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });
            return services;
        }
        public static IServiceCollection AddHealthChecks(this IServiceCollection services, IConfiguration configuration)
        {
            var hcBuilder = services.AddHealthChecks();
            hcBuilder.AddCheck("self", () => HealthCheckResult.Healthy());
            return services;
        }
        public static IServiceCollection AddCustomDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<CustomerTransferSlipProjectionDbContext>(options =>
            {
                options.UseSqlServer(configuration["CustomerTransferDBConnString"],
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
                        sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                    });
            },
            ServiceLifetime.Transient,
            ServiceLifetime.Singleton
            );
            return services;
        }
        public static IServiceCollection AddCustomSwagger(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "TAT Customer Transfer REST API",
                    Version = "v1",
                    Description = "The Customer Transfer Service REST API"
                });
                options.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
                {
                    Description = "Standard Authorization header using the Bearer scheme. Example: \"bearer {token}\"",
                    In = ParameterLocation.Header,
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey
                });

                options.OperationFilter<SecurityRequirementsOperationFilter>();
            });
            return services;
        }
        public static IServiceCollection AddDomainCoreDependecy(this IServiceCollection services)
        {
            services.AddTransient<ICommandBus, CommandBus>();
            services.AddTransient<IQueryBus, QueryBus>();
            services.AddTransient<IEventBus, EventBus>();
            services.AddTransient<ICustomerTransferSlipProjectionRepository, CustomerTransferSlipProjectionRepository>();
            services.AddTransient<ICustomerTransferSlipProjectionService, CustomerTransferSlipProjectionService>();

            services.AddTransient<CreatedCustomerTransferSlipHeaderIntegrationEventHandler>();
            services.AddTransient<AddedItemsToCustomerTransferSlipNotificationHandler>();


            return services;
        }
        public static IServiceCollection RegistorMediatR(this IServiceCollection services)
        {
            services.AddMediatR(typeof(Startup).GetTypeInfo().Assembly);
            services.AddValidatorsFromAssembly(typeof(Startup).Assembly);
            return services;
        }
        public static IServiceCollection AddAutoMapper(this IServiceCollection services)
        {
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            return services;
        }

        public static IServiceCollection AddEventStoreConfiguration(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<EventStoreContext>(options =>
            {
                options.UseSqlServer(configuration["CustomerTransferDBConnString"],
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
                        sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                    });
            },
            ServiceLifetime.Transient,
            ServiceLifetime.Singleton
            );

            services.AddTransient<IDomainEventSerializer<Guid>, JsonDomainEventSerializer<Guid>>();
            services.AddTransient<IEventStore, EFEventStore>();
            return services;
        }

        public static IServiceCollection AddIntegrationEventBus(this IServiceCollection services)
        {
            services.AddSingleton<IIntegrationEventBus, EventBusRabbitMq>();
            return services;
        }
    }
}
