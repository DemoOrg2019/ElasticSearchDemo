﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NOV.ES.TAT.Common.Exception;
using NOV.ES.TAT.CustomerTransfer.Projection.DomainService;
using System.Net;

namespace NOV.ES.TAT.CustomerTransfer.Projection.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectionController : ControllerBase
    {
        private readonly ICustomerTransferSlipProjectionService customerTransferSlipProjectionService;
        public ProjectionController(ICustomerTransferSlipProjectionService customerTransferSlipProjectionService)
        {
            this.customerTransferSlipProjectionService = customerTransferSlipProjectionService;
        }

        [HttpPost]
        [Route("projections")]
        [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult> CreateProjection([FromBody] Guid customerTransferSlipId)
        {
            await customerTransferSlipProjectionService.CreateCustomerTransferProjectionAsync(customerTransferSlipId);
            return Ok();
        }
    }
}
