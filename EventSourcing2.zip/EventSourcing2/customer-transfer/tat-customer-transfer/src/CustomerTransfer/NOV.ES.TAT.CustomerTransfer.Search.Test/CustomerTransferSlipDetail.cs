﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.Controllers;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.DomainService;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure;
using NOV.ES.TAT.CustomerTransfer.Search.Test;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NOV.ES.TAT.Admin.Test
{
    [TestClass]
    public class CustomerTransferSlipDetailTest : TestBase
    {
        private readonly ICustomerTransferSlipDetailService customerTransferSlipDetailService;
        private Paging pagingParameters;
        private CustomerTransferSlipDetailsController customerTransferSlipDetailsController;
        private readonly ILogger<CustomerTransferSlipDetailsController> logger;
        private IEnumerable<CustomerTransferSlipDetailDto> customerTransferSlipDetailDtos = new List<CustomerTransferSlipDetailDto>();
        private IEnumerable<CustomerTransferSlipDto> customerTransferSlipDtos = new List<CustomerTransferSlipDto>();
        public CustomerTransferSlipDetailTest() : base()
        {
            customerTransferSlipDetailService = new CustomerTransferSlipDetailService
                (new CustomerTransferSlipDetailQueryRepository(CustomerTransferSlipDBContext));
            pagingParameters = new Paging();

            logger = new Mock<ILogger<CustomerTransferSlipDetailsController>>().Object;
            IQueryBus queryBus = new Mock<IQueryBus>().Object;

            customerTransferSlipDetailsController = new CustomerTransferSlipDetailsController(logger, queryBus);
        }

        [TestInitialize]
        public void SetUp()
        {
            ClearAndSeedTestData();
        }

        #region Controller unit Tests

        [TestMethod]
        public void ShouldReturnsServiceNameWithOkStatus_ServiceName()
        {
            var result = customerTransferSlipDetailsController.ServiceName();

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            Assert.AreEqual("CustomerTransferSlipDetails CustomerTransfer Service.", ((OkObjectResult)result).Value);
        }

        [TestMethod]
        public async Task ShouldReturnsEmptyListofCustomerTransferSlipDetailsWithOkStatus_GetCustomerTransferSlipDetails()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();
            customerTransferSlipDetailDtos = new List<CustomerTransferSlipDetailDto>();
            mockQueryBus.Setup(x => x.Send<GetPaginationCustomerTransferSlipDetailsQuery, PagedResult<CustomerTransferSlipDetailDto>>(It.IsAny<GetPaginationCustomerTransferSlipDetailsQuery>()))
                .ReturnsAsync(new PagedResult<CustomerTransferSlipDetailDto>(customerTransferSlipDetailDtos, customerTransferSlipDetailDtos.Count(), pagingParameters));

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipDetailsController = new CustomerTransferSlipDetailsController(logger, queryBus);

            customerTransferSlipDetailsController.ControllerContext.HttpContext = new DefaultHttpContext();
            customerTransferSlipDetailsController.ControllerContext.HttpContext.Request.QueryString = new QueryString();
            var result = await customerTransferSlipDetailsController.GetCustomerTransferSlipDetails(new Paging());

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsListofCustomerTransferSlipDetailsWithOkStatus_GetCustomerTransferSlipDetails()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();

            mockQueryBus.Setup(x => x.Send<GetPaginationCustomerTransferSlipDetailsQuery, PagedResult<CustomerTransferSlipDetailDto>>(It.IsAny<GetPaginationCustomerTransferSlipDetailsQuery>()))
                .ReturnsAsync(new PagedResult<CustomerTransferSlipDetailDto>(customerTransferSlipDetailDtos, customerTransferSlipDetailDtos.Count(), new Paging()));

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipDetailsController = new CustomerTransferSlipDetailsController(logger, queryBus);

            customerTransferSlipDetailsController.ControllerContext.HttpContext = new DefaultHttpContext();
            customerTransferSlipDetailsController.ControllerContext.HttpContext.Request.QueryString = new QueryString();

            var result = await customerTransferSlipDetailsController.GetCustomerTransferSlipDetails(new Paging());
            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsNotFoundResult_GetCustomerTransferSlipDetailById()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();
            /*
            * suppressed Possible null reference return warning ,
            * test case intended to check returning null value by method
            * */
            mockQueryBus.Setup(x => x.Send<GetCustomerTransferSlipDetailByIdQuery, CustomerTransferSlipDetailDto>(It.IsAny<GetCustomerTransferSlipDetailByIdQuery>()))
#pragma warning disable CS8603 // Possible null reference return.
                .ReturnsAsync(() => null);
#pragma warning restore CS8603 // Possible null reference return.

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipDetailsController = new CustomerTransferSlipDetailsController(logger, queryBus);
            var result = await customerTransferSlipDetailsController.GetCustomerTransferSlipDetailById(Guid.Parse("94DA11D8-72C7-49BC-B191-5E7106498D63"));

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(NotFoundObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsCustomerTransferSlipDetailWithOkStatus_GetCustomerTransferSlipDetailId()
        {
            Mock<IQueryBus> mockQueryBus = new();

            Guid id = customerTransferSlipDetailDtos.First().Id;
            var customerTransferSlipDetailDto = customerTransferSlipDetailDtos.FirstOrDefault(o => o.Id == id);

            Assert.IsNotNull(customerTransferSlipDetailDto);

            mockQueryBus.Setup(x => x.Send<GetCustomerTransferSlipDetailByIdQuery, CustomerTransferSlipDetailDto>(It.IsAny<GetCustomerTransferSlipDetailByIdQuery>()))
                .ReturnsAsync(customerTransferSlipDetailDto);

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipDetailsController = new CustomerTransferSlipDetailsController(logger, queryBus);
            var result = await customerTransferSlipDetailsController.GetCustomerTransferSlipDetailById(id);

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));

            OkObjectResult actualResult = ((OkObjectResult)result.Result);
            Assert.IsNotNull(actualResult.Value);
            Assert.AreEqual(typeof(CustomerTransferSlipDetailDto), actualResult.Value.GetType());
        }

        [TestMethod]
        public async Task ShouldReturnsNotFoundResult_GetCustomerTransferSlipDetailsByCustomerTransferId()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();
            /*
            * suppressed Possible null reference return warning ,
            * test case intended to check returning null value by method
            * */
            mockQueryBus.Setup(x => x.Send<GetCustomerTransferSlipDetailByCustomerTransferIdQuery, IEnumerable<CustomerTransferSlipDetailDto>>(It.IsAny<GetCustomerTransferSlipDetailByCustomerTransferIdQuery>()))
#pragma warning disable CS8603 // Possible null reference return.
                .ReturnsAsync(() => null);
#pragma warning restore CS8603 // Possible null reference return.

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipDetailsController = new CustomerTransferSlipDetailsController(logger, queryBus);
            var result = await customerTransferSlipDetailsController.GetCustomerTransferSlipDetailsByCustomerTransferId(Guid.Parse("94DA11D8-72C7-49BC-B191-5E7106498D63"));

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(NotFoundObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsCustomerTransferSlipDetailWithOkStatus_GetCustomerTransferSlipDetailsByCustomerTransferId()
        {
            Mock<IQueryBus> mockQueryBus = new();

            Guid customerTransferId = customerTransferSlipDetailDtos.First().CustomerTransferId;
            IEnumerable<CustomerTransferSlipDetailDto> customerTransferSlipDetailDto = customerTransferSlipDetailDtos.ToList();
            Assert.IsNotNull(customerTransferSlipDetailDto);

            mockQueryBus.Setup(x => x.Send<GetCustomerTransferSlipDetailByCustomerTransferIdQuery, IEnumerable<CustomerTransferSlipDetailDto>>(It.IsAny<GetCustomerTransferSlipDetailByCustomerTransferIdQuery>()))
                .ReturnsAsync(customerTransferSlipDetailDto);

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSlipDetailsController = new CustomerTransferSlipDetailsController(logger, queryBus);
            var result = await customerTransferSlipDetailsController.GetCustomerTransferSlipDetailsByCustomerTransferId(customerTransferId);

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));

            OkObjectResult actualResult = ((OkObjectResult)result.Result);
            Assert.IsNotNull(actualResult.Value);
            Assert.AreEqual(typeof(List<CustomerTransferSlipDetailDto>), actualResult.Value.GetType());
        }
        #endregion

        #region DomainService unit tests
        [TestMethod]
        public void ShouldReturnAllCustomerTransferSlipDetails_GetCustomerTransferSlipDetails()
        {
            var customerTransferSlipDetails = customerTransferSlipDetailService.GetCustomerTransferSlipDetails(null);
            var customerTransferSlipDetail = customerTransferSlipDetails.FirstOrDefault();

            Assert.IsNotNull(customerTransferSlipDetail);
            Assert.AreEqual(3, customerTransferSlipDetails.Count());
            Assert.IsNotNull(customerTransferSlipDetail);
            Assert.AreEqual(Guid.Parse("2C9BCF6A-0DF4-4F0A-ABF2-9BA87B3F5894"), customerTransferSlipDetail.Id);
            Assert.AreEqual("T", customerTransferSlipDetail.ItemType);
            Assert.AreEqual("U", customerTransferSlipDetail.LineType);
            Assert.AreEqual("T1", customerTransferSlipDetail.ItemSerialNumber);
            Assert.AreEqual(1, customerTransferSlipDetail.SequenceNumber);
        }

        [TestMethod]
        public void ShouldReturnCustomerTransferSlipDetailForGivenId_GetCustomerTransferSlipDetailById()
        {
            var customerTransferSlipDetail = customerTransferSlipDetailService.GetCustomerTransferSlipDetailById(new Guid("2C9BCF6A-0DF4-4F0A-ABF2-9BA87B3F5894"));

            Assert.IsNotNull(customerTransferSlipDetail);
            Assert.AreEqual(Guid.Parse("2C9BCF6A-0DF4-4F0A-ABF2-9BA87B3F5894"), customerTransferSlipDetail.Id);
            Assert.AreEqual("T", customerTransferSlipDetail.ItemType);
            Assert.AreEqual("T1", customerTransferSlipDetail.ItemSerialNumber);
            Assert.AreEqual(Guid.Parse("80B0DEEE-DEF7-47B2-B8EF-AE84F90C944F"), customerTransferSlipDetail.ItemId);
        }

        [TestMethod]
        public void ShouldReturnCustomerTransferSlipDetailForGivenId_GetCustomerTransferSlipDetailByCustomerTransferId()
        {
            var customerTransferSlipDetails = customerTransferSlipDetailService.GetCustomerTransferSlipDetailsByCustomerTransferId(new Guid("9CE0C723-1345-4D6D-A700-098BBD1D90CD"));
            var customerTransferSlipDetail = customerTransferSlipDetails.FirstOrDefault();
            Assert.IsNotNull(customerTransferSlipDetail);
            Assert.AreEqual(Guid.Parse("9CE0C723-1345-4D6D-A700-098BBD1D90CD"), customerTransferSlipDetail.CustomerTransferId);
            Assert.AreEqual("T", customerTransferSlipDetail.ItemType);
            Assert.AreEqual("T1", customerTransferSlipDetail.ItemSerialNumber);
            Assert.AreEqual(Guid.Parse("80B0DEEE-DEF7-47B2-B8EF-AE84F90C944F"), customerTransferSlipDetail.ItemId);
        }

        #region Pagination
        /// <summary>
        ///  test Pagination with valid pagingParameters
        /// </summary>
        [TestMethod]
        public void ShouldReturnsCustomerTransferSlipDetails_GetCustomerTransferSlipDetails()
        {
            pagingParameters = new Paging()
            {
                PageIndex = 1,
                PageSize = 2,
                SortColumn = "Id"
            };

            var customerTransferSlipDetails = customerTransferSlipDetailService.GetCustomerTransferSlipDetails(pagingParameters);
            var customerTransferSlipDetail = customerTransferSlipDetails.FirstOrDefault();

            Assert.IsNotNull(customerTransferSlipDetail);
            Assert.AreEqual(1, customerTransferSlipDetails.Count());
            Assert.AreEqual(3, customerTransferSlipDetails.TotalNumberOfItems);
            Assert.AreEqual(2, customerTransferSlipDetails.TotalNumberOfPages);
            Assert.IsNotNull(customerTransferSlipDetail);
            Assert.AreEqual(Guid.Parse("FD1374FA-629F-4951-A587-3CB5262004B6"), customerTransferSlipDetail.Id);
            Assert.AreEqual("U", customerTransferSlipDetail.ItemType);
            Assert.AreEqual("U", customerTransferSlipDetail.LineType);
            Assert.AreEqual(3, customerTransferSlipDetail.SequenceNumber);
            Assert.AreEqual("T3", customerTransferSlipDetail.ItemSerialNumber);
        }

        /// <summary>
        /// test Pagination with invalid SortColumn   .
        /// <returns>
        /// ArgumentException("Value does not have matching column");
        /// </returns>
        /// </summary>
        [TestMethod]
        public void ShouldThrowArgumentExceptionForGivenInvalidSortColumn_GetCustomerTransferSlipDetails()
        {
            pagingParameters = new Paging()
            {
                SortColumn = "SortColumn"
            };
            try
            {
                customerTransferSlipDetailService.GetCustomerTransferSlipDetails(pagingParameters);
                Assert.Fail();
            }
            catch (ArgumentException argumentException)
            {
                Assert.AreEqual("Sort column SortColumn does not exist.", argumentException.Message);
            }
        }

        #endregion

        #endregion

        [TestCleanup]
        public void TestCleanup()
        {
            Dispose();
        }

        private void ClearAndSeedTestData()
        {
            CustomerTransferSlipDBContext.Database.EnsureDeleted();
            CustomerTransferSlipDBContext.Database.EnsureCreated();

            string jsonFilePath = Path.Combine(".", "TestData", "CustomerTransferSlipDetailsSeed.json");
            var customerTransferSlipDetails = DeserializeJsonToObject<CustomerTransferSlipDetail>(jsonFilePath);
            customerTransferSlipDetailDtos = DeserializeJsonToObject<CustomerTransferSlipDetailDto>(jsonFilePath);
            CustomerTransferSlipDBContext.CustomerTransferSlipDetails.AddRange(customerTransferSlipDetails);

            jsonFilePath = Path.Combine(".", "TestData", "CustomerTransferSlipsSeed.json");
            var customerTransferSlips = DeserializeJsonToObject<CustomerTransferSlip>(jsonFilePath);
            customerTransferSlipDtos = DeserializeJsonToObject<CustomerTransferSlipDto>(jsonFilePath);
            CustomerTransferSlipDBContext.CustomerTransferSlips.AddRange(customerTransferSlips);


            CustomerTransferSlipDBContext.SaveChanges();
        }
    }
}