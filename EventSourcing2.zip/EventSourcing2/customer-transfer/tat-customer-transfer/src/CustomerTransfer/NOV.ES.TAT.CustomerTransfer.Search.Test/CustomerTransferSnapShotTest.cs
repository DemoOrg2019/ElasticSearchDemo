﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Search.API.Application.Queries;
using NOV.ES.TAT.CustomerTransfer.Search.API.Controllers;
using NOV.ES.TAT.CustomerTransfer.Search.API.DTOs;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.DomainService;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure;
using NOV.ES.TAT.CustomerTransfer.Search.Test;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NOV.ES.TAT.Admin.Test
{
    [TestClass]
    public class CustomerTransferSnapShotTest : TestBase
    {
        private readonly ICustomerTransferSnapShotService customerTransferSnapShotService;
        private Paging pagingParameters;
        private CustomerTransferSnapShotsController customerTransferSnapShotsController;
        private readonly ILogger<CustomerTransferSnapShotsController> logger;
        private IEnumerable<CustomerTransferSnapShotDto> customerTransferSnapShotDtos = new List<CustomerTransferSnapShotDto>();
        private IEnumerable<CustomerTransferSlipDto> customerTransferSlipDtos = new List<CustomerTransferSlipDto>();
        public CustomerTransferSnapShotTest() : base()
        {
            customerTransferSnapShotService = new CustomerTransferSnapShotService
                (new CustomerTransferSnapShotQueryRepository(CustomerTransferSlipDBContext));
            pagingParameters = new Paging();

            logger = new Mock<ILogger<CustomerTransferSnapShotsController>>().Object;
            IQueryBus queryBus = new Mock<IQueryBus>().Object;

            customerTransferSnapShotsController = new CustomerTransferSnapShotsController(logger, queryBus);
        }

        [TestInitialize]
        public void SetUp()
        {
            ClearAndSeedTestData();
        }

        #region Controller unit Tests

        [TestMethod]
        public void ShouldReturnsServiceNameWithOkStatus_ServiceName()
        {
            var result = customerTransferSnapShotsController.ServiceName();

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            Assert.AreEqual("CustomerTransferSnapShots CustomerTransfer Service.", ((OkObjectResult)result).Value);
        }

        [TestMethod]
        public async Task ShouldReturnsEmptyListofCustomerTransferSnapShotsWithOkStatus_GetCustomerTransferSnapShots()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();
            customerTransferSnapShotDtos = new List<CustomerTransferSnapShotDto>();
            mockQueryBus.Setup(x => x.Send<GetPaginationCustomerTransferSnapShotsQuery, PagedResult<CustomerTransferSnapShotDto>>(It.IsAny<GetPaginationCustomerTransferSnapShotsQuery>()))
                .ReturnsAsync(new PagedResult<CustomerTransferSnapShotDto>(customerTransferSnapShotDtos, customerTransferSnapShotDtos.Count(), pagingParameters));

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSnapShotsController = new CustomerTransferSnapShotsController(logger, queryBus);

            customerTransferSnapShotsController.ControllerContext.HttpContext = new DefaultHttpContext();
            customerTransferSnapShotsController.ControllerContext.HttpContext.Request.QueryString = new QueryString();
            var result = await customerTransferSnapShotsController.GetCustomerTransferSnapShots(new Paging());

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsListofCustomerTransferSnapShotsWithOkStatus_GetCustomerTransferSnapShots()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();

            mockQueryBus.Setup(x => x.Send<GetPaginationCustomerTransferSnapShotsQuery, PagedResult<CustomerTransferSnapShotDto>>(It.IsAny<GetPaginationCustomerTransferSnapShotsQuery>()))
                .ReturnsAsync(new PagedResult<CustomerTransferSnapShotDto>(customerTransferSnapShotDtos, customerTransferSnapShotDtos.Count(), new Paging()));

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSnapShotsController = new CustomerTransferSnapShotsController(logger, queryBus);

            customerTransferSnapShotsController.ControllerContext.HttpContext = new DefaultHttpContext();
            customerTransferSnapShotsController.ControllerContext.HttpContext.Request.QueryString = new QueryString();

            var result = await customerTransferSnapShotsController.GetCustomerTransferSnapShots(new Paging());
            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsNotFoundResult_GetCustomerTransferSnapShotById()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();
            /*
            * suppressed Possible null reference return warning ,
            * test case intended to check returning null value by method
            * */
            mockQueryBus.Setup(x => x.Send<GetCustomerTransferSnapShotByIdQuery, CustomerTransferSnapShotDto>(It.IsAny<GetCustomerTransferSnapShotByIdQuery>()))
#pragma warning disable CS8603 // Possible null reference return.
                .ReturnsAsync(() => null);
#pragma warning restore CS8603 // Possible null reference return.

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSnapShotsController = new CustomerTransferSnapShotsController(logger, queryBus);
            var result = await customerTransferSnapShotsController.GetCustomerTransferSnapShotById(Guid.Parse("94DA11D8-72C7-49BC-B191-5E7106498D63"));

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(NotFoundObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsCustomerTransferSnapShotWithOkStatus_GetCustomerTransferSnapShotId()
        {
            Mock<IQueryBus> mockQueryBus = new();

            Guid id = customerTransferSnapShotDtos.First().Id;
            var customerTransferSnapShotDto = customerTransferSnapShotDtos.FirstOrDefault(o => o.Id == id);

            Assert.IsNotNull(customerTransferSnapShotDto);

            mockQueryBus.Setup(x => x.Send<GetCustomerTransferSnapShotByIdQuery, CustomerTransferSnapShotDto>(It.IsAny<GetCustomerTransferSnapShotByIdQuery>()))
                .ReturnsAsync(customerTransferSnapShotDto);

            IQueryBus queryBus = mockQueryBus.Object;
            customerTransferSnapShotsController = new CustomerTransferSnapShotsController(logger, queryBus);
            var result = await customerTransferSnapShotsController.GetCustomerTransferSnapShotById(id);

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));

            OkObjectResult actualResult = ((OkObjectResult)result.Result);
            Assert.IsNotNull(actualResult.Value);
            Assert.AreEqual(typeof(CustomerTransferSnapShotDto), actualResult.Value.GetType());
        }

       

       
        #endregion

        #region DomainService unit tests
        [TestMethod]
        public void ShouldReturnAllCustomerTransferSnapShots_GetCustomerTransferSnapShots()
        {
            var customerTransferSnapShots = customerTransferSnapShotService.GetCustomerTransferSnapShots(null);
            var customerTransferSnapShot = customerTransferSnapShots.FirstOrDefault();

            Assert.IsNotNull(customerTransferSnapShot);
            Assert.AreEqual(3, customerTransferSnapShots.Count());
            Assert.IsNotNull(customerTransferSnapShot);
            Assert.AreEqual(Guid.Parse("752ec010-ac1b-4cd4-a9c4-9662bb30cab3"), customerTransferSnapShot.Id);
            Assert.AreEqual(Guid.Parse("37777802-5d20-4c1a-8e3a-ca9732443f66"), customerTransferSnapShot.EventId);
            Assert.AreEqual(Guid.Parse("58b0b9b9-6548-4785-a687-8103383fc01a"), customerTransferSnapShot.CustomerTransferId);
            Assert.AreEqual("test data", customerTransferSnapShot.PreviousData);
            Assert.AreEqual("test data", customerTransferSnapShot.CurrentData);
            Assert.AreEqual("test data", customerTransferSnapShot.ChangedData);
        }

        [TestMethod]
        public void ShouldReturnCustomerTransferSnapShotForGivenId_GetCustomerTransferSnapShotById()
        {
            var customerTransferSnapShot = customerTransferSnapShotService.GetCustomerTransferSnapShotById(new Guid("DB85E780-EAB6-439F-BCC1-18D948D740C3"));

            Assert.IsNotNull(customerTransferSnapShot);
            Assert.AreEqual(Guid.Parse("DB85E780-EAB6-439F-BCC1-18D948D740C3"), customerTransferSnapShot.Id);
            Assert.AreEqual(Guid.Parse("879E5F00-FBA4-4A9C-A739-7D2AABFB94AB"), customerTransferSnapShot.EventId);
            Assert.AreEqual(Guid.Parse("9CE0C723-1345-4D6D-A700-098BBD1D90CD"), customerTransferSnapShot.CustomerTransferId);
            Assert.AreEqual("test data3", customerTransferSnapShot.PreviousData);
            Assert.AreEqual("test data3", customerTransferSnapShot.CurrentData);
            Assert.AreEqual("test data3", customerTransferSnapShot.ChangedData);
        }       

        #region Pagination
        /// <summary>
        ///  test Pagination with valid pagingParameters
        /// </summary>
        [TestMethod]
        public void ShouldReturnsCustomerTransferSnapShots_GetCustomerTransferSnapShots()
        {
            pagingParameters = new Paging()
            {
                PageIndex = 1,
                PageSize = 2,
                SortColumn = "Id"
            };

            var customerTransferSnapShots = customerTransferSnapShotService.GetCustomerTransferSnapShots(pagingParameters);
            var customerTransferSnapShot = customerTransferSnapShots.FirstOrDefault();

            Assert.IsNotNull(customerTransferSnapShot);
            Assert.AreEqual(1, customerTransferSnapShots.Count());
            Assert.AreEqual(3, customerTransferSnapShots.TotalNumberOfItems);
            Assert.AreEqual(2, customerTransferSnapShots.TotalNumberOfPages);
            Assert.IsNotNull(customerTransferSnapShot);
            Assert.AreEqual(Guid.Parse("DB85E780-EAB6-439F-BCC1-18D948D740C3"), customerTransferSnapShot.Id);
            Assert.AreEqual(Guid.Parse("879E5F00-FBA4-4A9C-A739-7D2AABFB94AB"), customerTransferSnapShot.EventId);
            Assert.AreEqual(Guid.Parse("9CE0C723-1345-4D6D-A700-098BBD1D90CD"), customerTransferSnapShot.CustomerTransferId);
            Assert.AreEqual("test data3", customerTransferSnapShot.PreviousData);
            Assert.AreEqual("test data3", customerTransferSnapShot.CurrentData);
            Assert.AreEqual("test data3", customerTransferSnapShot.ChangedData);
        }

        /// <summary>
        /// test Pagination with invalid SortColumn   .
        /// <returns>
        /// ArgumentException("Value does not have matching column");
        /// </returns>
        /// </summary>
        [TestMethod]
        public void ShouldThrowArgumentExceptionForGivenInvalidSortColumn_GetCustomerTransferSnapShots()
        {
            pagingParameters = new Paging()
            {
                SortColumn = "SortColumn"
            };
            try
            {
                customerTransferSnapShotService.GetCustomerTransferSnapShots(pagingParameters);
                Assert.Fail();
            }
            catch (ArgumentException argumentException)
            {
                Assert.AreEqual("Sort column SortColumn does not exist.", argumentException.Message);
            }
        }

        #endregion

        #endregion

        [TestCleanup]
        public void TestCleanup()
        {
            Dispose();
        }

        private void ClearAndSeedTestData()
        {
            CustomerTransferSlipDBContext.Database.EnsureDeleted();
            CustomerTransferSlipDBContext.Database.EnsureCreated();

            string jsonFilePath = Path.Combine(".", "TestData", "CustomerTransferSlipsSeed.json");
            var customerTransferSlips = DeserializeJsonToObject<CustomerTransferSlip>(jsonFilePath);
            customerTransferSlipDtos = DeserializeJsonToObject<CustomerTransferSlipDto>(jsonFilePath);
            CustomerTransferSlipDBContext.CustomerTransferSlips.AddRange(customerTransferSlips);

            jsonFilePath = Path.Combine(".", "TestData", "CustomerTransferSnapShotsSeed.json");
            var customerTransferSnapShots = DeserializeJsonToObject<CustomerTransferSnapShot>(jsonFilePath);
            customerTransferSnapShotDtos = DeserializeJsonToObject<CustomerTransferSnapShotDto>(jsonFilePath);
            CustomerTransferSlipDBContext.CustomerTransferSnapShots.AddRange(customerTransferSnapShots);

            CustomerTransferSlipDBContext.SaveChanges();
        }
    }
}