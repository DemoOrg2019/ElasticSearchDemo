﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Projection.API.Controllers;
using NOV.ES.TAT.CustomerTransfer.Projection.DomainService;
using System;
using System.Net;
using System.Net.Mime;
using System.Threading.Tasks;

namespace NOV.ES.TAT.CustomerTransfer.Projection.Test
{
    [TestClass]
    public class ProjectionTest : TestBase
    {
        private readonly ProjectionController projectionController;
        public ProjectionTest() : base()
        {
            projectionController = new ProjectionController(new Mock<ICustomerTransferSlipProjectionService>().Object);
        }

        [TestInitialize]
        public void SetUp()
        {
            ClearAndSeedTestData();
        }

        #region Controller unit Tests

        [TestMethod]
        public async Task ShouldReturnsOkObjectResultForGivenValidInput_CreateProjection()
        {
            var result = await projectionController.CreateProjection(Guid.NewGuid());
            Assert.IsInstanceOfType(result, typeof(OkResult));
        }

        #endregion

        [TestCleanup]
        public void TestCleanup()
        {
            Dispose();
        }

        private void ClearAndSeedTestData()
        {
            customerTransferSlipProjectionDbContext.Database.EnsureDeleted();
            customerTransferSlipProjectionDbContext.Database.EnsureCreated();
            customerTransferSlipProjectionDbContext.SaveChanges();
        }
    }
}