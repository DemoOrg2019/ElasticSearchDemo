﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.Data;
using NOV.ES.TAT.CustomerTransfer.Projection.Infrastructure;
using System;
using System.Collections.Generic;
using System.IO;

namespace NOV.ES.TAT.CustomerTransfer.Projection.Test
{
    public class TestBase : IDisposable
    {
        public CustomerTransferSlipProjectionDbContext customerTransferSlipProjectionDbContext { get; set; }
        public TestBase()
        {
            customerTransferSlipProjectionDbContext = CreateDbContext();
        }

        private CustomerTransferSlipProjectionDbContext CreateDbContext()
        {
            return new CustomerTransferSlipProjectionDbContext(CreateDbContextOptions<CustomerTransferSlipProjectionDbContext>());
        }

        public DbContextOptions<T> CreateDbContextOptions<T>() where T : BaseContext
        {
            var connection = new SqliteConnection("DataSource=:memory:");
            connection.Open();
            connection.CreateFunction("newid", () => { return Guid.NewGuid(); });
            return new DbContextOptionsBuilder<T>().UseSqlite(connection).Options;

        }
        public IEnumerable<T> DeserializeJsonToObject<T>(string jsonDataPath)
        {
            return JsonConvert.DeserializeObject<List<T>>
                           (File.ReadAllText(jsonDataPath)) ?? new List<T>();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            customerTransferSlipProjectionDbContext.Dispose();
        }
    }

}
