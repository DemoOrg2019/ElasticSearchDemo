﻿namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.Infrastructure;

public interface IIdentityService
{
    string GetUserIdentity();

    string GetUserName();
}

