﻿using NOV.ES.Framework.Core.CQRS.Events;
using NOV.ES.Framework.Core.Domain;
using NOV.ES.Framework.Core.EventStore;

namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.Infrastructure
{
    public class CustomerTransferSlipEventSourcingRepository
        : ICustomerTransferSlipEventSourcingRepository
    {
        private readonly IEventStore eventStore;
        private readonly IEventBus eventBus;

        public CustomerTransferSlipEventSourcingRepository(
            IEventStore eventStore,
            IEventBus eventBus)
        {
            this.eventStore = eventStore;
            this.eventBus = eventBus;
        }

        public long GetAggregateVersion(Guid aggregateRootId, long startSequence)
        {
            long ver = 0;
            var result = eventStore.GetEvents(aggregateRootId, startSequence);

            if(result != null && result.Count() > 0)
            {
                ver = result.OrderByDescending(x => x.AggregateVersion).First().AggregateVersion;
            }
            return ver;
        }

        public void Save(AggregateRoot<Guid> aggregateRoot)
        {
            var domainEvents = aggregateRoot.UncommittedEvents;
            UpdateRequestDetails(domainEvents);
            eventStore.Insert(domainEvents);

            eventBus.Publish(domainEvents.ToArray());

            aggregateRoot.CommitEvents();
        }

        private void UpdateRequestDetails(IEnumerable<DomainEvent<Guid>> domainEvents)
        {
            foreach(var domainEvent in domainEvents)
            {
                domainEvent.RequestId = Guid.NewGuid();
                domainEvent.ClientAppId = Guid.NewGuid();
                domainEvent.ActionBy = "tat.system1@nov.com";
            }
        }
    }
}
