﻿using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure.Helper;

namespace NOV.ES.TAT.CustomerTransfer.DomainService
{
    public interface ICustomerTransferSnapShotService
    {
        PagedResult<CustomerTransferSnapShot> GetCustomerTransferSnapShots(Paging pagingParameters);
        CustomerTransferSnapShot GetCustomerTransferSnapShotById(Guid id);
    }
}
