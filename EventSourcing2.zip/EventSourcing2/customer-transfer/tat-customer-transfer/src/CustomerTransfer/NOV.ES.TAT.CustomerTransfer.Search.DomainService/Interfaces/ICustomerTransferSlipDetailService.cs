﻿using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;

namespace NOV.ES.TAT.CustomerTransfer.DomainService
{
    public interface ICustomerTransferSlipDetailService
    {
        PagedResult<CustomerTransferSlipDetail> GetCustomerTransferSlipDetails(Paging pagingParameters);
        CustomerTransferSlipDetail GetCustomerTransferSlipDetailById(Guid id);
        List<CustomerTransferSlipDetail> GetCustomerTransferSlipDetailsByCustomerTransferId(Guid? customerTransferId);

    }
}
