﻿using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure.Helper;

namespace NOV.ES.TAT.CustomerTransfer.DomainService
{
    public interface ICustomerTransferSlipService
    {
        PagedResult<CustomerTransferSlip> GetCustomerTransferSlips(Paging pagingParameters);
        CustomerTransferSlip GetCustomerTransferSlipById(Guid id);
        List<CustomerTransferSlip> GetCustomerTransferSlipDetailsById(Guid id);
        List<CustomerTransferSlip> GetCustomerTransferSlipsByNumber(int customerTransferNumber);
        List<string> GetCreatedBy();
        PagedResult<CustomerTransferSlip> GetCustomerTransferSlipsSearch(Paging pagingParameters, SearchRequest searchRequest);
        bool DeleteCustomerTransferSlip(Guid customerTransferSlipId);
    }
}
