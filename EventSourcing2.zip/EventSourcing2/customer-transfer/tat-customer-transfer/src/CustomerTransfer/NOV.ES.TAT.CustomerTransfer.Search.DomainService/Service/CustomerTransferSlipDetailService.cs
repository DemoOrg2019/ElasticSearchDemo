﻿using NOV.ES.Framework.Core.Data;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure;

namespace NOV.ES.TAT.CustomerTransfer.DomainService
{
    public class CustomerTransferSlipDetailService : ICustomerTransferSlipDetailService
    {
        private readonly ICustomerTransferSlipDetailQueryRepository customerTransferSlipDetailQueryRepository;
        public CustomerTransferSlipDetailService(ICustomerTransferSlipDetailQueryRepository customerTransferSlipDetailQueryRepository)
        {
            this.customerTransferSlipDetailQueryRepository = customerTransferSlipDetailQueryRepository;
        }
        public CustomerTransferSlipDetail GetCustomerTransferSlipDetailById(Guid id)
        {
            var filter = PredicateBuilder.Create<CustomerTransferSlipDetail>(x => x.Id == id && x.IsActive);
            return customerTransferSlipDetailQueryRepository.Get(filter, null, null).FirstOrDefault();
        }
        public PagedResult<CustomerTransferSlipDetail> GetCustomerTransferSlipDetails(Paging pagingParameters)
        {
            var filter = PredicateBuilder.Create<CustomerTransferSlipDetail>(x => x.IsActive);
            var result = customerTransferSlipDetailQueryRepository.Get(filter, null, null).ToList();
            return PagingExtensions.GetPagedResult(result.AsQueryable(), pagingParameters);
        }
        public List<CustomerTransferSlipDetail> GetCustomerTransferSlipDetailsByCustomerTransferId(Guid? customerTransferId)
        {
            var filter = PredicateBuilder.Create<CustomerTransferSlipDetail>(x => x.CustomerTransferId == customerTransferId && x.IsActive);
            return customerTransferSlipDetailQueryRepository.Get(filter, null, null).ToList();
        }
    }
}
