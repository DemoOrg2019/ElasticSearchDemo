﻿using NOV.ES.Framework.Core.Data;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure.Helper;

namespace NOV.ES.TAT.CustomerTransfer.DomainService
{
    public class CustomerTransferSlipService : ICustomerTransferSlipService
    {
        private readonly ICustomerTransferSlipQueryRepository customerTransferSlipQueryRepository;
        private readonly ICustomerTransferSlipCommandRepository customerTransferSlipCommandRepository;
        public CustomerTransferSlipService(ICustomerTransferSlipQueryRepository customerTransferSlipQueryRepository
            , ICustomerTransferSlipCommandRepository customerTransferSlipCommandRepository)
        {
            this.customerTransferSlipQueryRepository = customerTransferSlipQueryRepository;
            this.customerTransferSlipCommandRepository = customerTransferSlipCommandRepository; 
        }
        public CustomerTransferSlip GetCustomerTransferSlipById(Guid id)//Only Header
        {
            var filter = PredicateBuilder.Create<CustomerTransferSlip>(x => x.Id == id && x.IsActive);
            return customerTransferSlipQueryRepository.Get(filter, null, "CustomerTransferSlipDetails").FirstOrDefault();
        }
        public PagedResult<CustomerTransferSlip> GetCustomerTransferSlips(Paging pagingParameters)
        {
            var filter = PredicateBuilder.Create<CustomerTransferSlip>(x => x.IsActive);
            var result = customerTransferSlipQueryRepository.Get(filter, null, "CustomerTransferSlipDetails").ToList();
            return PagingExtensions.GetPagedResult(result.AsQueryable(), pagingParameters);
        }
        public List<CustomerTransferSlip> GetCustomerTransferSlipDetailsById(Guid id)//Header + Details by Id
        {
            var filter = PredicateBuilder.Create<CustomerTransferSlip>(x => x.Id == id && x.IsActive);
            return customerTransferSlipQueryRepository.Get(filter, null, "CustomerTransferSlipDetails").ToList();
        }
        public List<CustomerTransferSlip> GetCustomerTransferSlipsByNumber(int customerTransferNumber)//Header + Details by Number
        {
            var filter = PredicateBuilder.Create<CustomerTransferSlip>(x => x.CustomerTransferNumber == customerTransferNumber && x.IsActive);
            return customerTransferSlipQueryRepository.Get(filter, null, "CustomerTransferSlipDetails").ToList();
        }

        public List<string> GetCreatedBy()
        {
            return customerTransferSlipQueryRepository.GetDistinctCreatedBy().ToList();
        }
        
        public PagedResult<CustomerTransferSlip> GetCustomerTransferSlipsSearch(Paging pagingParameters, SearchRequest searchRequest)
        {
            var result = customerTransferSlipQueryRepository.GetCustomerTransferSlip(searchRequest);
            return PagingExtensions.GetPagedResult(result, pagingParameters);
        }
        
        public bool DeleteCustomerTransferSlip(Guid customerTransferSlipId)
        {
            var filter = PredicateBuilder.Create<CustomerTransferSlip>(x => x.Id == customerTransferSlipId && x.IsActive);
            var customerTransferSlip = customerTransferSlipQueryRepository.Get(filter, null, "CustomerTransferSlipDetails").FirstOrDefault();
            if (customerTransferSlip.CustomerTransferSlipDetails != null && customerTransferSlip.CustomerTransferSlipDetails.Count > 0)
                throw new ArgumentException("Record Cannot be deleted as it consists customer transfer details");
            customerTransferSlipCommandRepository.Delete(customerTransferSlipId);
            customerTransferSlipCommandRepository.SaveChanges();
            return true;
        }
    }
}
