﻿using NOV.ES.Framework.Core.Data;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.CustomerTransfer.Domain.ReadModels;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure;
using NOV.ES.TAT.CustomerTransfer.Search.Infrastructure.Helper;

namespace NOV.ES.TAT.CustomerTransfer.DomainService
{
    public class CustomerTransferSnapShotService : ICustomerTransferSnapShotService
    {
        private readonly ICustomerTransferSnapShotQueryRepository customerTransferSnapShotQueryRepository;
        public CustomerTransferSnapShotService(ICustomerTransferSnapShotQueryRepository customerTransferSnapShotQueryRepository)
        {
            this.customerTransferSnapShotQueryRepository = customerTransferSnapShotQueryRepository;
        }
        public CustomerTransferSnapShot GetCustomerTransferSnapShotById(Guid id)
        {
            var filter = PredicateBuilder.Create<CustomerTransferSnapShot>(x => x.Id == id && x.IsActive);
            return customerTransferSnapShotQueryRepository.Get(filter, null, null).FirstOrDefault();
        }

        public PagedResult<CustomerTransferSnapShot> GetCustomerTransferSnapShots(Paging pagingParameters)
        {
            var filter = PredicateBuilder.Create<CustomerTransferSnapShot>(x => x.IsActive);
            var result = customerTransferSnapShotQueryRepository.Get(filter, null, null).ToList();
            return PagingExtensions.GetPagedResult(result.AsQueryable(), pagingParameters);
        }     
    }
}
