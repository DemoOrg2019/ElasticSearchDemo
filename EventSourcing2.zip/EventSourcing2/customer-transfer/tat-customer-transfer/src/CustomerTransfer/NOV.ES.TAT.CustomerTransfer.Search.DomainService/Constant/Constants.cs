﻿namespace NOV.ES.TAT.CustomerTransfer.DomainService
{
    public static class Constants
    {
        public const string NAME = "Name";
    }
}
