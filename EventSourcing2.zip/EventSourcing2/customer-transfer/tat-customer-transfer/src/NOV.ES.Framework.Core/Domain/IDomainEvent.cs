﻿using NOV.ES.Framework.Core.CQRS.Events;

namespace NOV.ES.Framework.Core.Domain
{
    public interface IDomainEvent<T> : IEvent
    {
        /// <summary>
        /// The event identifier
        /// </summary>
        Guid EventId { get; }

        string EventType { get; set; }

        /// <summary>
        /// The identifier of the aggregate which has generated the event
        /// </summary>
        T AggregateRootId { get; set; }

        /// <summary>
        /// The version of the aggregate when the event has been generated
        /// </summary>
        long AggregateVersion { get; set; }

        /// <summary>
        /// DateTime Stamp when an event has been generated
        /// </summary>
        DateTime EventDate { get; }

        /// <summary>
        /// Request Raised By
        /// </summary>
        string ActionBy { get; set; }

        /// <summary>
        /// Client Application Id from which request has been raised
        /// </summary>
        Guid? ClientAppId { get; set; }

        /// <summary>
        /// Request Id to ensure Idempotency
        /// </summary>
        Guid? RequestId { get; set; }
    }
}
