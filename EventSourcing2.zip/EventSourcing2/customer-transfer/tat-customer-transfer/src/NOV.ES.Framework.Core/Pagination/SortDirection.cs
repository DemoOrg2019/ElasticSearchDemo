﻿using System.Runtime.Serialization;

namespace NOV.ES.Framework.Core.Pagination
{
    [DataContract]
    public enum SortDirection
    {
        [EnumMember]
        Ascending,

        [EnumMember]
        Descending
    }
}
