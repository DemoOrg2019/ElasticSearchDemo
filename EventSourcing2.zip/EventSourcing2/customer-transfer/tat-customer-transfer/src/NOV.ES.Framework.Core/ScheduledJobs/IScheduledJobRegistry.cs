﻿namespace NOV.ES.Framework.Core.ScheduledJobs
{
    public interface IScheduledJobRegistry
    {
        void AddScheduledJobDefinition(Type type);
        bool TryGetDefinition(string name, int version, out ScheduledJobDefinition definition);
        ScheduledJobDefinition GetScheduledJobDefinition(string name, int version);
        ScheduledJobDefinition GetScheduledDefinition(Type type);
    }
}
