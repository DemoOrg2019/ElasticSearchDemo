﻿namespace NOV.ES.Framework.Core.ScheduledJobs
{
    public interface IScheduledJobRunner
    {
        void Execute(string scheduledJobName, int version, string job);

        void Execute(string scheduledJobName, int version, string json, CancellationToken cancellationToken);

        Task ExecuteAsync(string scheduledJobName, int version, string json, CancellationToken cancellationToken);
    }
}
