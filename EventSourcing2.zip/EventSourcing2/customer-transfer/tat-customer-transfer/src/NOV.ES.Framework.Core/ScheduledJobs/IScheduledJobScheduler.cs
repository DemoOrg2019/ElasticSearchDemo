﻿namespace NOV.ES.Framework.Core.ScheduledJobs
{
    public interface IScheduledJobScheduler
    {
        Task<Guid> ScheduleNowAsync(IScheduledJob scheduledJob, CancellationToken cancellationToken);
        Task<Guid> ScheduleAsync(IScheduledJob scheduledJob, DateTimeOffset runAt, CancellationToken cancellationToken);
        Task<Guid> ScheduleAsync(IScheduledJob scheduledJob, TimeSpan delay, CancellationToken cancellationToken);
    }
}
