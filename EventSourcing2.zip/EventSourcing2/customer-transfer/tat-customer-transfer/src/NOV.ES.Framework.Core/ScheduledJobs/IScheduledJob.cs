﻿namespace NOV.ES.Framework.Core.ScheduledJobs
{
    public interface IScheduledJob
    {
        Task ExecuteAsync(CancellationToken cancellationToken);
    }
}
