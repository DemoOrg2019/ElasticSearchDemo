﻿using Newtonsoft.Json;

namespace NOV.ES.Framework.Core.ScheduledJobs
{
    public class ScheduledJobRunner : IScheduledJobRunner
    {
        private readonly IScheduledJobRegistry scheduledJobRegistry;

        public ScheduledJobRunner(IScheduledJobRegistry scheduledJobRegistry)
        {
            this.scheduledJobRegistry = scheduledJobRegistry;
        }
        public void Execute(string scheduledJobName, int version, string job)
        {
            Execute(scheduledJobName, version, job, CancellationToken.None);
        }

        public void Execute(string scheduledJobName, int version, string json, CancellationToken cancellationToken)
        {
            var a = ExecuteAsync(scheduledJobName, version, json, cancellationToken);
        }

        public Task ExecuteAsync(string scheduledJobName, int version, string json, CancellationToken cancellationToken)
        {
            ScheduledJobDefinition jobDefinition;
            if (!scheduledJobRegistry.TryGetDefinition(scheduledJobName, version, out jobDefinition))
            {
                throw new Exception(); //UnknownJobException.With(scheduledJobName, version);
            }

            var jsonSerializerSettings = new JsonSerializerSettings()
            {
                TypeNameHandling = TypeNameHandling.All
            };

            var executeCommandJob = (IScheduledJob)JsonConvert.DeserializeObject(json, jobDefinition.Type);
            return executeCommandJob.ExecuteAsync(cancellationToken);
        }
    }
}
