﻿using NOV.ES.Framework.Core.ScheduledJobs.Attributes;
using System.Collections.Concurrent;
using System.Reflection;
using System.Text.RegularExpressions;

namespace NOV.ES.Framework.Core.ScheduledJobs
{
    public class ScheduledJobRegistry : IScheduledJobRegistry
    {
        private static readonly Regex NameRegex = new Regex(
           @"^(Old){0,1}(?<name>[\p{L}\p{Nd}]+?)(V(?<version>[0-9]+)){0,1}$",
           RegexOptions.Compiled);

        private readonly ConcurrentDictionary<Type, List<ScheduledJobDefinition>> _definitionsByType = new ConcurrentDictionary<Type, List<ScheduledJobDefinition>>();
        private readonly ConcurrentDictionary<string, Dictionary<int, ScheduledJobDefinition>> _definitionByNameAndVersion = new ConcurrentDictionary<string, Dictionary<int, ScheduledJobDefinition>>();

        public ScheduledJobRegistry()
        {

        }

        public void AddScheduledJobDefinition(Type type)
        {
            if (!typeof(IScheduledJob).GetTypeInfo().IsAssignableFrom(type))
            {
                return;
            }

            var definitions = _definitionsByType.GetOrAdd(type, _ => new List<ScheduledJobDefinition>());
            var definition = CreateDefinitionFromAttribute(type);
            definitions.Add(definition);

            if (!_definitionByNameAndVersion.TryGetValue(definition.Name, out var versions))
            {
                versions = new Dictionary<int, ScheduledJobDefinition>();
                _definitionByNameAndVersion.TryAdd(definition.Name, versions);
            }

            if (!versions.ContainsKey(definition.Version))
            {
                versions.Add(definition.Version, definition);
            }

        }

        public bool TryGetDefinitions(Type type, out IReadOnlyCollection<ScheduledJobDefinition> definitions)
        {
            if (type == null) throw new ArgumentNullException(nameof(type));

            if (!_definitionsByType.TryGetValue(type, out var list))
            {
                definitions = default(IReadOnlyCollection<ScheduledJobDefinition>);
                return false;
            }

            definitions = list;
            return true;
        }

        public bool TryGetDefinition(Type type, out ScheduledJobDefinition definition)
        {
            if (!TryGetDefinitions(type, out var definitions))
            {
                definition = default(ScheduledJobDefinition);
                return false;
            }

            if (definitions.Count > 1)
            {
                throw new InvalidOperationException($"Type '{type.GetGenericTypeDefinition()}' has multiple definitions: {string.Join(", ", definitions.Select(d => d.ToString()))}");
            }

            definition = definitions.Single();
            return true;
        }

        public bool TryGetDefinition(string name, int version, out ScheduledJobDefinition definition)
        {
            if (_definitionByNameAndVersion.TryGetValue(name, out var versions))
            {
                return versions.TryGetValue(version, out definition);
            }

            definition = null;

            return false;
        }

        public ScheduledJobDefinition GetScheduledDefinition(Type type)
        {
            if (!TryGetDefinition(type, out var definition))
            {
                throw new ArgumentException($"No definition for type '{type.GetGenericTypeDefinition()}', have you remembered to load it during EventFlow initialization");
            }

            return definition;
        }

        public ScheduledJobDefinition GetScheduledJobDefinition(string name, int version)
        {
            if (!TryGetDefinition(name, version, out var definition))
            {
                throw new ArgumentException($"No versioned type definition for '{name}' with version {version} in '{GetType().GetGenericTypeDefinition()}'");
            }

            return definition;
        }

        protected ScheduledJobDefinition CreateDefinition(int version, Type type, string name)
        {
            return new ScheduledJobDefinition(version, type, name);
        }

        private ScheduledJobDefinition CreateDefinitionFromAttribute(Type type)
        {
            var attribute = type
                .GetTypeInfo()
                .GetCustomAttributes()
                .OfType<ScheduledJobAttribute>()
                .FirstOrDefault();

            return CreateDefinition(attribute.Version, type, attribute.Name);
        }
    }
}
