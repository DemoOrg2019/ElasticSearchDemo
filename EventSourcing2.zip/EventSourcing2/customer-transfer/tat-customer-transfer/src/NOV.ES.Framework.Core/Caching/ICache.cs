﻿namespace NOV.ES.Framework.Core.Caching
{
    public interface ICache
    {
        /// <summary>
        /// Adds a value to cache with a given key
        /// </summary>
        /// <param name="key">key</param>
        /// <param name="value">value</param>
        /// <param name="expiration">Expire time (Use TimeSpan.Zero to hold value with no expiration)</param>
        void Add(string key, object value, TimeSpan expiration);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void Add(string key, object value);

        /// <summary>
        /// Reads the value with specified key from the local cache.</summary>
        /// <typeparam name="TItem">Data type</typeparam>
        /// <param name="key">Key</param>
        TItem Get<TItem>(string key);

        /// <summary>
        /// Removes the value with specified key from the local cache. If the value doesn't exist, no error is raised.
        /// </summary>
        /// <param name="cacheKey">Key</param>
        bool Remove(string key);

        /// <summary>
        /// Removes all items from the cache (avoid expect unit tests).
        /// </summary>
        void RemoveAll();

        /// <summary>
        /// it will remove based on serverType Prefix.
        /// </summary>
        /// <param name="serverTypePrefix"></param>
        void RemoveAll(string serverTypePrefix);
    }
}
