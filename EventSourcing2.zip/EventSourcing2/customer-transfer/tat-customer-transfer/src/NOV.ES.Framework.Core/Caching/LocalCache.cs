﻿//using Microsoft.Extensions.Caching.Memory;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace NOV.ES.Framework.Core.Caching
//{
//    public class LocalCache : ICache
//    {
//        private static MemoryCache cache;
//        static readonly object padlock = new object();

//        /// <summary>
//        /// 
//        /// </summary>
//        static LocalCache()
//        {
//            cache = new MemoryCache();
//        }

//        /// <summary>
//        /// 
//        /// </summary>
//        /// <param name="key"></param>
//        /// <param name="value"></param>
//        /// <param name="expiration"></param>
//        public void Add(string key, object value, TimeSpan expiration)
//        {
//            lock (padlock)
//            {
//                cache.Add(key, value, DateTimeOffset.MaxValue);
//            }
//        }

//        /// <summary>
//        /// 
//        /// </summary>
//        /// <param name="key"></param>
//        /// <param name="value"></param>
//        public void Add(string key, object value)
//        {
//            lock (padlock)
//            {
//                cache.Add(key, value, DateTimeOffset.MaxValue);
//            }
//        }

//        /// <summary>
//        /// 
//        /// </summary>
//        /// <typeparam name="TItem"></typeparam>
//        /// <param name="key"></param>
//        /// <returns></returns>
//        public TItem Get<TItem>(string key)
//        {
//            object obj = cache.Get(key);
//            TItem t = (TItem)obj;
//            return t;
//        }

//        public bool Remove(string key)
//        {
//            return true;
//        }

//        public void RemoveAll()
//        {
//            throw new NotImplementedException();
//        }


//        public void RemoveAll(string serverTypePrefix)
//        {
//            throw new NotImplementedException();
//        }
//    }
//}
