﻿using Newtonsoft.Json;

namespace NOV.ES.Framework.Core.Messaging.IntegrationEvents
{
    public class IntegrationEvent
    {
        [JsonProperty]
        public Guid Id { get; set; }

        [JsonProperty]
        public Guid KeyId { get; set; }

        [JsonProperty]
        public DateTime CreationDate { get; set; }
        public string ActionBy { get; set; }

        public IntegrationEvent()
        {
            Id = Guid.NewGuid();
            CreationDate = DateTime.UtcNow;
        }

        [JsonConstructor]
        public IntegrationEvent(Guid keyId, DateTime createDate, string actionBy)            
        {
            Id = Guid.NewGuid();
            KeyId = keyId;
            CreationDate = createDate;
            ActionBy = actionBy;
        }
        
    }
}

