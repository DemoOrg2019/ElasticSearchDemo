﻿namespace NOV.ES.Framework.Core.Messaging.IntegrationEvents
{
    public class IntegrationEventBusConfig
    {
        public string BrokerName { get; set; }
        public string ExchangeType { get; set; }
        public string QueueName { get; set; }
        public string Topic { get; set; }
    }
}

