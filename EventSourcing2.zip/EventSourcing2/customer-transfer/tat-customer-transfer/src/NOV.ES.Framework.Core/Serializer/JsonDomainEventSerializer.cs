﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Domain;
using System.Runtime.Serialization.Formatters.Binary;

namespace NOV.ES.Framework.Core.Serializer
{
    public class JsonDomainEventSerializer<T>
        : IDomainEventSerializer<T>
        where T : new()
    {
        public DomainEvent<T> Deserialize(Type targetType, string serializedDomainEvent)
        {
            return (DomainEvent<T>)JsonConvert.DeserializeObject(serializedDomainEvent, targetType);
        }

        public string Serialize(DomainEvent<T> domainEvent)
        {
            //var jsonSerializerSettings = new JsonSerializerSettings()
            //{
            //    TypeNameHandling = TypeNameHandling.All
            //};

            //return JsonConvert.SerializeObject(domainEvent, jsonSerializerSettings);
            return JsonConvert.SerializeObject(domainEvent);
        }
    }

    public class BinaryDomainEventSerializer<T>
        : IDomainEventSerializer<T>
        where T : new()
    {
        public string Serialize(DomainEvent<T> domainEvent)
        {
            var formatter = new BinaryFormatter();
            using (var stream = new MemoryStream())
            {
#pragma warning disable SYSLIB0011 // Type or member is obsolete
                formatter.Serialize(stream, domainEvent);
#pragma warning restore SYSLIB0011 // Type or member is obsolete
                stream.Flush();
                stream.Position = 0;
                return Convert.ToBase64String(stream.ToArray());
            }
        }

        public DomainEvent<T> Deserialize(Type targetType, string serializedDomainEvent)
        {
            var formatter = new BinaryFormatter();
            using (var stream = new MemoryStream(Convert.FromBase64String(serializedDomainEvent)))
            {
#pragma warning disable SYSLIB0011 // Type or member is obsolete
                return (DomainEvent<T>)formatter.Deserialize(stream);
#pragma warning restore SYSLIB0011 // Type or member is obsolete
            }
        }
    }
}
