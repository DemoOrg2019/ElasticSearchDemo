﻿using NOV.ES.Framework.Core.Domain;

namespace NOV.ES.Framework.Core.Serializer
{
    public interface IDomainEventSerializer<T> where T : new()
    {
        string Serialize(DomainEvent<T> domainEvent);
        DomainEvent<T> Deserialize(Type targetType, string serializedDomainEvent);
    }
}
