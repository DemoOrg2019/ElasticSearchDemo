﻿namespace NOV.ES.Framework.Core.Sagas.Store
{
    public enum SagaRunningStatus
    {
        New = 0,
        Running,
        CompletedWithSuccess,
        CompletedWithFailure,
        Closed
    }

    public class SagaEventEntity
    {
        public long RowId { get; set; }
        public Guid CorelationId { get; private set; }
        public Guid SourceEventId { get; private set; }
        public Guid KeyId { get; private set; }
        public string SagaEventTypeName { get; private set; }
        public string Data { get; private set; }
        public SagaEventExecutionResult ExecutionResult { get; private set; }
        public SagaRunningStatus Status { get; private set; }
        public DateTime TimeStamp { get; private set; }
        public string ActionBy { get; private set; }

        public SagaEventEntity()
        {
        }

        public SagaEventEntity(SagaEvent @event, SagaRunningStatus status)
        {
            CorelationId = @event.CorelationId;
            SourceEventId = @event.Id;
            KeyId = @event.KeyId;
            SagaEventTypeName = @event.GetType().Name;
            Data = @event.JsonStringData;
            ExecutionResult = @event.SagaEventExecutionResult;
            Status = status;
            TimeStamp = DateTime.UtcNow;
            ActionBy = @event.ActionBy;
        }
    }
}
