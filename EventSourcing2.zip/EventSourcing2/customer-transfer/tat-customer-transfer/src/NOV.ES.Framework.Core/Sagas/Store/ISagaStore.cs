﻿namespace NOV.ES.Framework.Core.Sagas.Store
{
    public interface ISagaStore
    {
        Task SaveSagaEvent(SagaEventEntity eventEntry);
        Task<IEnumerable<SagaEventEntity>> GetSagaEvent(Guid sagaEventId);
    }
}
