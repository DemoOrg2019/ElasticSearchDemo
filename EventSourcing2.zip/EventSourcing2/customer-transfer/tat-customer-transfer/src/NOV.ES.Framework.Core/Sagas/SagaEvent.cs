﻿using NOV.ES.Framework.Core.Messaging.IntegrationEvents;

namespace NOV.ES.Framework.Core.Sagas
{
    public enum SagaEventExecutionResult
    {
        Failure = 0,
        Success
    }

    public class SagaEvent : IntegrationEvent
    {
        public Guid CorelationId { get; set; }

        public string JsonStringData { get; set; }

        public SagaEventExecutionResult SagaEventExecutionResult { get; set; }

        public SagaEvent() : base()
        {

        }

        public SagaEvent(Guid corelationId,
            string jsonStringData) : this()
        {
            CorelationId = corelationId;
            JsonStringData = jsonStringData;
        }

        public SagaEvent(Guid keyId, Guid corelationId,
            string jsonStringData, DateTime createDate, string actionBy = "") : base(keyId, createDate, actionBy)
        {
            CorelationId = corelationId;
            JsonStringData = jsonStringData;
        }
    }


}
