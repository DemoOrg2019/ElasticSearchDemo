﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.Framework.Core.Constants
{
    public class PagingConstants
    {
        public const int DEFAULT_PAGE_SIZE = 100;

        public const int DEFAULT_PAGE_INDEX = 0;
    }
}
