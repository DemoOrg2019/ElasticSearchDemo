﻿using NOV.ES.Framework.Core.Domain;

namespace NOV.ES.Framework.Core.EventStore
{
    public interface IEventStore
    {
        IEnumerable<DomainEvent<Guid>> GetEvents(Guid aggregateRootId, long startSequence);
        void Insert(IEnumerable<DomainEvent<Guid>> domainEvents);
        IEnumerable<DomainEvent<Guid>> GetEventsByEventTypes(IEnumerable<Type> domainEventTypes);
        IEnumerable<DomainEvent<Guid>> GetEventsByEventTypes(IEnumerable<Type> domainEventTypes, Guid aggregateRootId);
        IEnumerable<DomainEvent<Guid>> GetEventsByEventTypes(IEnumerable<Type> domainEventTypes, DateTime startDate, DateTime endDate);
    }
}
