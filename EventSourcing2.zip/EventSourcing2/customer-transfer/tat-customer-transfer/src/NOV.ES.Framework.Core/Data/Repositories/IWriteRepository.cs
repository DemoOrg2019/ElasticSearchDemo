﻿namespace NOV.ES.Framework.Core.Data.Repositories
{
    public interface IWriteRepository<TEntity>
            where TEntity : class
    {
        void Create(TEntity entity);

        void Update(TEntity entity);

        void Delete(object id);

        void Delete(TEntity entity);

        void RemoveRange(IEnumerable<TEntity> entities);
    }
}
