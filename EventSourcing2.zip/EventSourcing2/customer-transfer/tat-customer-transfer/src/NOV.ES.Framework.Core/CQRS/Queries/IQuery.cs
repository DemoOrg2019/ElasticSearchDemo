﻿using MediatR;

namespace NOV.ES.Framework.Core.CQRS.Queries
{
    public interface IQuery<out TResponse> : IRequest<TResponse>
    {
    }
}
