﻿using MediatR;

namespace NOV.ES.Framework.Core.CQRS.Commands
{
    public interface ICommandHandler<T> : IRequestHandler<T>
        where T : ICommand
    {
    }

    public interface ICommandHandler<in TCommand, TResponse> : IRequestHandler<TCommand, TResponse>
          where TCommand : ICommand<TResponse>
    {
    }
}
