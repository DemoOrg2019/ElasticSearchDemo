﻿namespace NOV.ES.Framework.Core.Entities
{
    public interface IEntity<T>
        where T : new()
    {
        T Id { get; set; }
    }
}
