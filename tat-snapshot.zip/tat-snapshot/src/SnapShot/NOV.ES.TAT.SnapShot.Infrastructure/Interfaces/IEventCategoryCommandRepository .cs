﻿using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.SnapShot.Domain;

namespace NOV.ES.TAT.SnapShot.Infrastructure
{
    public interface IEventCategoryCommandRepository
        : IWriteRepository<EventCategory>
    {
        public int SaveChanges();
        public Task<int> SaveChangesAsync(CancellationToken cancellationToken);
    }
}