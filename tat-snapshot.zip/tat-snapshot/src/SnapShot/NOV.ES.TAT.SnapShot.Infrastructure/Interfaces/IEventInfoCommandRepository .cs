﻿using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.SnapShot.Domain;

namespace NOV.ES.TAT.SnapShot.Infrastructure
{
    public interface IEventInfoCommandRepository
        : IWriteRepository<EventInfo>
    {
        public int SaveChanges();
        public Task<int> SaveChangesAsync(CancellationToken cancellationToken);
    }
}