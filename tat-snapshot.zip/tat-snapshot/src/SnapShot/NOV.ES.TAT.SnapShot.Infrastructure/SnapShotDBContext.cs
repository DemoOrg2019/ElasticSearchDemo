﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using NOV.ES.Framework.Core.Data;
using NOV.ES.TAT.SnapShot.Domain;

namespace NOV.ES.TAT.SnapShot.Infrastructure
{
    public class SnapShotDBContext : BaseContext
    {
        public SnapShotDBContext(DbContextOptions<SnapShotDBContext> dbContextOptions, IHttpContextAccessor httpContextAccessor)
            : base(dbContextOptions)
        {
            UserProvider = "tat.system@nov.com";

            if (httpContextAccessor != null && httpContextAccessor.HttpContext != null)
            {
                IIdentityService identityService = new IdentityService(httpContextAccessor);
                UserProvider = identityService.GetUserName();
            }
        }
        public virtual DbSet<ClientRequest> ClientRequests { get; set; }
        public virtual DbSet<EventInfo> EventInfos { get; set; }
        public virtual DbSet<EventMaster> EventMasters { get; set; }
        public virtual DbSet<EventCategory> EventCategories { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EventMaster>().Property(x => x.Id).HasDefaultValueSql("NEWID()");
            modelBuilder.Entity<EventMaster>().Property(x => x.IsActive).HasDefaultValueSql("1");
            modelBuilder.Entity<EventMaster>().Property(x => x.DateCreated).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<EventMaster>().Property(x => x.DateModified).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<EventInfo>().Property(x => x.Id).HasDefaultValueSql("NEWID()");
            modelBuilder.Entity<EventInfo>().Property(x => x.IsActive).HasDefaultValueSql("1");
            modelBuilder.Entity<EventInfo>().Property(x => x.DateCreated).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<EventInfo>().Property(x => x.DateModified).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<EventCategory>().Property(x => x.Id).HasDefaultValueSql("NEWID()");
            modelBuilder.Entity<EventCategory>().Property(x => x.IsActive).HasDefaultValueSql("1");
            modelBuilder.Entity<EventCategory>().Property(x => x.DateCreated).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<EventCategory>().Property(x => x.DateModified).HasDefaultValueSql("GETUTCDATE()");
        }
    }
}
