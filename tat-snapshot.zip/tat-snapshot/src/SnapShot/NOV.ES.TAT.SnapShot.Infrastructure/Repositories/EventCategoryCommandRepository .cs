﻿using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.SnapShot.Domain;

namespace NOV.ES.TAT.SnapShot.Infrastructure
{
    public class EventCategoryCommandRepository
        : GenericWriteRepository<EventCategory>
        , IEventCategoryCommandRepository
    {
        private readonly SnapShotDBContext snapShotDBContext;

        public EventCategoryCommandRepository(SnapShotDBContext snapShotDBContext)
            : base(snapShotDBContext)
        {
            this.snapShotDBContext = snapShotDBContext;
        }

        public int SaveChanges()
        {
            return snapShotDBContext.SaveChanges();
        }

        public Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            return snapShotDBContext.SaveChangesAsync(cancellationToken);
        }
    }
}