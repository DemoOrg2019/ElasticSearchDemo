﻿using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.TAT.SnapShot.Domain;

namespace NOV.ES.TAT.SnapShot.Infrastructure
{
    public class EventCategoryQueryRepository : GenericReadRepository<EventCategory>, IEventCategoryQueryRepository
    {
        public EventCategoryQueryRepository(SnapShotDBContext snapShotDBContext)
            : base(snapShotDBContext)
        {

        }

    }
}
