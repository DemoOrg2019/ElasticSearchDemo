﻿using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.TAT.SnapShot.Domain;

namespace NOV.ES.TAT.SnapShot.Infrastructure
{
    public class EventInfoQueryRepository : GenericReadRepository<EventInfo>, IEventInfoQueryRepository
    {
        public EventInfoQueryRepository(SnapShotDBContext snapShotDBContext)
            : base(snapShotDBContext)
        {

        }

    }
}
