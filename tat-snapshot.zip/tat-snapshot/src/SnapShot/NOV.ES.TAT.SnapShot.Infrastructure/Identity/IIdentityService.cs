﻿namespace NOV.ES.TAT.SnapShot.Infrastructure;

public interface IIdentityService
{
    string GetUserIdentity();
    string GetUserName();
}

