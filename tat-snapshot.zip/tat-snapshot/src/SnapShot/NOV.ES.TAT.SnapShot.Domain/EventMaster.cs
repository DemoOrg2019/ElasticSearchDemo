﻿using NOV.ES.Framework.Core.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NOV.ES.TAT.SnapShot.Domain
{
    [Table("EventMaster")]
    public class EventMaster : BaseEntity<Guid>
    {
        [Required, MaxLength(120)]
        public string EventName { get; set; }
        [MaxLength(10)]
        public string EventTypeCode { get; set; }
    }
}
