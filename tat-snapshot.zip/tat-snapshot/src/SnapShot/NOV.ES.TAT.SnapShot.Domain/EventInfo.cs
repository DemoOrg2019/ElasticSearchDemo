﻿using NOV.ES.Framework.Core.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NOV.ES.TAT.SnapShot.Domain
{
	[Table("EventInfo")]
	public class EventInfo : BaseEntity<Guid>
	{
		public Guid? ItemId { get; set; }
		public Guid EventMasterId { get; set; }
		public DateTime EventDateTime { get; set; }

		[MaxLength(100), Required]
		public string UserName { get; set; }
		public string Description { get; set; }
		public int? Key { get; set; }
	}
}