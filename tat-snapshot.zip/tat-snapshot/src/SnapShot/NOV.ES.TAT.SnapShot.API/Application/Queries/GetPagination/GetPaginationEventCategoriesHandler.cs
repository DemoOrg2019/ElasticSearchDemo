﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.API.DTOs;
using NOV.ES.TAT.SnapShot.API.Helper;
using NOV.ES.TAT.SnapShot.Domain;
using NOV.ES.TAT.SnapShot.DomainService;

namespace NOV.ES.TAT.SnapShot.API.Application.Queries
{
    public class GetPaginationEventCategoriesHandler
        : IQueryHandler<GetPaginationEventCategoriesQuery, PagedResult<EventCategoryDto>>
    {
        private readonly IMapper mapper;
        private readonly IEventCategoryService eventCategoryService;
        private readonly IHttpContextAccessor httpContextAccessor;
        public GetPaginationEventCategoriesHandler(
            IMapper mapper,
            IEventCategoryService eventCategoryService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.eventCategoryService = eventCategoryService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<EventCategoryDto>> Handle(GetPaginationEventCategoriesQuery request,
          CancellationToken cancellationToken)
        {
            var eventCategories = eventCategoryService.GetEventCategory(request.PagingParameters);
            var result = mapper.Map<PagedResult<EventCategory>, PagedResult<EventCategoryDto>>(eventCategories);
            PagingHelper.AddPagingMetadata<EventCategoryDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}