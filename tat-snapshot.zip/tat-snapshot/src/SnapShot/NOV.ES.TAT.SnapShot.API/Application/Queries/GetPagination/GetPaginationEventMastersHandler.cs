﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.Domain;
using NOV.ES.TAT.SnapShot.API.DTOs;
using NOV.ES.TAT.SnapShot.DomainService;
using NOV.ES.TAT.SnapShot.API.Helper;

namespace NOV.ES.TAT.SnapShot.API.Application.Queries
{
    public class GetPaginationUserEventMastersHandler : IQueryHandler<GetPaginationEventMastersQuery, PagedResult<EventMasterDto>>
    {
        private readonly IMapper mapper;
        private readonly IEventMasterService eventMasterService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationUserEventMastersHandler(
            IMapper mapper,
            IEventMasterService eventMasterService,
            IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.eventMasterService = eventMasterService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<EventMasterDto>> Handle(GetPaginationEventMastersQuery request,
            CancellationToken cancellationToken)
        {
            var eventMasters = eventMasterService.GetEventMasters(request.PagingParameters);
            var result = mapper.Map<PagedResult<EventMaster>, PagedResult<EventMasterDto>>(eventMasters);
            PagingHelper.AddPagingMetadata<EventMasterDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}
