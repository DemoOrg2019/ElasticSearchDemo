﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.API.DTOs;

namespace NOV.ES.TAT.SnapShot.API.Application.Queries
{
    public class GetPaginationEventMastersQuery : IQuery<PagedResult<EventMasterDto>>
    {
        public Paging PagingParameters { get; private set; }

        public GetPaginationEventMastersQuery(Paging pagingParameters)
        {
            this.PagingParameters = pagingParameters;
        }
    }
    
}
