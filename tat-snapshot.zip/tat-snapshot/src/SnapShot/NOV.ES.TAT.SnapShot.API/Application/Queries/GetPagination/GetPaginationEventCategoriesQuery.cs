﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.API.DTOs;

namespace NOV.ES.TAT.SnapShot.API.Application.Queries
{
    public class GetPaginationEventCategoriesQuery : IQuery<PagedResult<EventCategoryDto>>
    {
        public Paging PagingParameters { get; private set; }

        public GetPaginationEventCategoriesQuery(Paging pagingParameters)
        {
            this.PagingParameters = pagingParameters;
        }
    }
}