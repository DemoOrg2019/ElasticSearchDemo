﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.API.DTOs;

namespace NOV.ES.TAT.SnapShot.API.Application.Queries
{
    public class GetPaginationEventInfoQuery : IQuery<PagedResult<EventInfoDto>>
    {
        public Paging PagingParameters { get; private set; }

        public GetPaginationEventInfoQuery(Paging pagingParameters)
        {
            this.PagingParameters = pagingParameters;
        }
    }
}