﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.API.DTOs;
using NOV.ES.TAT.SnapShot.API.Helper;
using NOV.ES.TAT.SnapShot.Domain;
using NOV.ES.TAT.SnapShot.DomainService;

namespace NOV.ES.TAT.SnapShot.API.Application.Queries
{
    public class GetPaginationEventInfoHandler
        : IQueryHandler<GetPaginationEventInfoQuery, PagedResult<EventInfoDto>>
    {
        private readonly IMapper mapper;
        private readonly IEventInfoService eventInfoService;
        private readonly IHttpContextAccessor httpContextAccessor;
        public GetPaginationEventInfoHandler(
            IMapper mapper,
            IEventInfoService eventInfoService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.eventInfoService = eventInfoService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<EventInfoDto>> Handle(GetPaginationEventInfoQuery request,
          CancellationToken cancellationToken)
        {
            var eventInfo = eventInfoService.GetEventInfo(request.PagingParameters);
            var result = mapper.Map<PagedResult<EventInfo>, PagedResult<EventInfoDto>>(eventInfo);
            PagingHelper.AddPagingMetadata<EventInfoDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}