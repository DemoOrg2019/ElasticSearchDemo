﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.SnapShot.API.DTOs;
using NOV.ES.TAT.SnapShot.Domain;
using NOV.ES.TAT.SnapShot.DomainService;

namespace NOV.ES.TAT.SnapShot.API.Application.Queries
{
    public class GetEventCategoryByIdHandler : IQueryHandler<GetEventCategoryByIdQuery, EventCategoryDto>
    {
        private readonly IMapper mapper;
        private readonly IEventCategoryService eventCategoryService;

        public GetEventCategoryByIdHandler(
            IMapper mapper,
            IEventCategoryService eventCategoryService)
        {
            this.mapper = mapper;
            this.eventCategoryService = eventCategoryService;
        }

        public Task<EventCategoryDto> Handle(GetEventCategoryByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var eventCategory = eventCategoryService.GetEventCategoryById(request.Id);
            var result = mapper.Map<EventCategory, EventCategoryDto>(eventCategory);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetEventCategoryByIdQuery request)
        {
            return (request != null && request.Id != Guid.Empty);            
        }
    }
}
