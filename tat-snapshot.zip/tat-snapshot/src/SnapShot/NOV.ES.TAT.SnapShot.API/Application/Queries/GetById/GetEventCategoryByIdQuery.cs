﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.SnapShot.API.DTOs;

namespace NOV.ES.TAT.SnapShot.API.Application.Queries
{
    public class GetEventCategoryByIdQuery : IQuery<EventCategoryDto>
    {
        public Guid Id { get; private set; }
        public GetEventCategoryByIdQuery(Guid id)
        {
            this.Id = id;
        }
    }
}
