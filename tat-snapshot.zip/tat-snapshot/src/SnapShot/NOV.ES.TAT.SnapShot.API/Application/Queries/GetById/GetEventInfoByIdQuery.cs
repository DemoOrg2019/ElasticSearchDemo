﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.SnapShot.API.DTOs;

namespace NOV.ES.TAT.SnapShot.API.Application.Queries
{
    public class GetEventInfoByIdQuery : IQuery<EventInfoDto>
    {
        public Guid Id { get; private set; }
        public GetEventInfoByIdQuery(Guid id)
        {
            this.Id = id;
        }
    }
}
