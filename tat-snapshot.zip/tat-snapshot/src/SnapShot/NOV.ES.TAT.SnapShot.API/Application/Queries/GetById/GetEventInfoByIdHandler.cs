﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.SnapShot.API.DTOs;
using NOV.ES.TAT.SnapShot.Domain;
using NOV.ES.TAT.SnapShot.DomainService;

namespace NOV.ES.TAT.SnapShot.API.Application.Queries
{
    public class GetEventInfoByIdHandler : IQueryHandler<GetEventInfoByIdQuery, EventInfoDto>
    {
        private readonly IMapper mapper;
        private readonly IEventInfoService eventInfoService;

        public GetEventInfoByIdHandler(
            IMapper mapper,
            IEventInfoService eventInfoService)
        {
            this.mapper = mapper;
            this.eventInfoService = eventInfoService;
        }

        public Task<EventInfoDto> Handle(GetEventInfoByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var eventInfo = eventInfoService.GetEventInfoById(request.Id);
            var result = mapper.Map<EventInfo, EventInfoDto>(eventInfo);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetEventInfoByIdQuery request)
        {
            return (request != null && request.Id != Guid.Empty);            
        }
    }
}
