﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.SnapShot.API.DTOs;
using NOV.ES.TAT.SnapShot.Domain;
using NOV.ES.TAT.SnapShot.DomainService;

namespace NOV.ES.TAT.SnapShot.API.Application.Queries
{
    public class GetEventMasterByIdQueryHandler : IQueryHandler<GetEventMasterByIdQuery, EventMasterDto>
    {
        private readonly IMapper mapper;
        private readonly IEventMasterService eventMasterService;

        public GetEventMasterByIdQueryHandler(
            IMapper mapper,
            IEventMasterService eventMasterService)
        {
            this.mapper = mapper;
            this.eventMasterService = eventMasterService;
        }

        public Task<EventMasterDto> Handle(GetEventMasterByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException("Value can not be null or Empty");

            var eventMaster = eventMasterService.GetEventMasterById(request.EventMasterId);
            return Task.FromResult(mapper.Map<EventMaster, EventMasterDto>(eventMaster));
        }

        private static bool IsValidRequest(GetEventMasterByIdQuery request)
        {
            if (request != null && request.EventMasterId != Guid.Empty)
                return true;
            return false;

        }
    }
}
