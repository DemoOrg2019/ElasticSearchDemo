﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.SnapShot.API.DTOs;


namespace NOV.ES.TAT.SnapShot.API.Application.Queries
{
    public class GetEventMasterByIdQuery : IQuery<EventMasterDto>
    {
        public Guid EventMasterId { get; private set; }
        public GetEventMasterByIdQuery(Guid eventMasterId)
        {
            this.EventMasterId = eventMasterId;
        }
    }
}
