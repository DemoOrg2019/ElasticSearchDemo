﻿using Microsoft.AspNetCore.Mvc;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.SnapShot.Infrastructure;

namespace NOV.ES.TAT.SnapShot.API.Application.Commands;
public class IdempotencyCommandHandler : ICommandHandler<IdempotencyCommand, ContentResult>
{
    private readonly ICommandBus commandBus;
    private readonly IRequestManager requestManager;
    public IdempotencyCommandHandler( ICommandBus commandBus, IRequestManager requestManager)
    {
        this.commandBus = commandBus;
        this.requestManager = requestManager;
    }
    protected virtual ContentResult CreateResultForDuplicateRequest()
    {
        return new ContentResult()
        {
            StatusCode = StatusCodes.Status200OK
        };
    }
    public async Task<ContentResult> Handle(IdempotencyCommand message, CancellationToken cancellationToken)
    {
        var alreadyExists = await requestManager.ExistAsync(message.Id);
        if (alreadyExists)
        {
            return CreateResultForDuplicateRequest();
        }
        else
        {
            await requestManager.CreateRequestForCommandAsync<ICommand>(message.Id);

            var command = message.Command;

            return await commandBus.Send<ICommand<ContentResult>, ContentResult>(command);
        }
    }
}
