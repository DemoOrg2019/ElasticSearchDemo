﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Sagas;

namespace NOV.ES.TAT.SnapShot.API.Application.IntegrationEvents
{
    public class CustomerTransferSlipHeaderCreatedEventDetail
    {
        public Guid CustomerTransferSlipId { get; }
        public string ChangeDetailJson { get; }
        public DateTime EventDate { get; }
        public string ActionBy { get; }

        public CustomerTransferSlipHeaderCreatedEventDetail(
            Guid customerTransferSlipId,
            string changeDetailJson,
            DateTime eventDate,
            string actionBy
            )
        {
            CustomerTransferSlipId = customerTransferSlipId;
            ChangeDetailJson = changeDetailJson;
            EventDate = eventDate;
            ActionBy = actionBy;
        }
    }

    public class CreateCustomerTransferHeaderEventInfo
        : SagaEvent
    {
        public CreateCustomerTransferHeaderEventInfo(Guid corelationId,
            string jsonStringData)
        {
            this.CorelationId = corelationId;
            this.JsonStringData = jsonStringData;
            this.SagaEventExecutionResult = SagaEventExecutionResult.Success;
        }

        [JsonConstructor]
        public CreateCustomerTransferHeaderEventInfo(Guid corelationId,
            string jsonStringData,
            SagaEventExecutionResult executionResult)
        {
            this.CorelationId = corelationId;
            this.JsonStringData = jsonStringData;
            this.SagaEventExecutionResult = executionResult;
        }
    }
}
