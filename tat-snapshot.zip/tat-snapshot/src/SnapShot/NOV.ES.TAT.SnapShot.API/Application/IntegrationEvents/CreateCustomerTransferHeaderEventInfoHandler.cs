﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.TAT.SnapShot.Domain;
using NOV.ES.TAT.SnapShot.DomainService;

namespace NOV.ES.TAT.SnapShot.API.Application.IntegrationEvents
{
    public class CreateCustomerTransferHeaderEventInfoHandler
        : IIntegrationEventHandler<CreateCustomerTransferHeaderEventInfo>
    {
        private ILogger<CreateCustomerTransferHeaderEventInfoHandler> logger;
        private readonly IEventInfoService eventInfoService;

        public CreateCustomerTransferHeaderEventInfoHandler(
            ILogger<CreateCustomerTransferHeaderEventInfoHandler> logger,
            IEventInfoService eventInfoService
            )
        {
            this.logger = logger;
            this.eventInfoService = eventInfoService;
        }

        public Task Handle(CreateCustomerTransferHeaderEventInfo @event)
        {
            logger.LogInformation("----- Consuming Event: Customer Transfer Slip Created Integration Event");
            logger.LogInformation("----- CorelationId is {id}", @event.CorelationId);
            logger.LogInformation("----- Event Detail is {info}", @event.JsonStringData);

            CustomerTransferSlipHeaderCreatedEventDetail eventDetail =
                JsonConvert.DeserializeObject<CustomerTransferSlipHeaderCreatedEventDetail>(@event.JsonStringData);

            logger.LogInformation("----- Customer Trnasfer Slip id is {id}", eventDetail.CustomerTransferSlipId);

            EventInfo eventInfo = new EventInfo
            {
                EventMasterId = Guid.Parse("68AA5CCF-E3D9-4D52-BD57-AC9C61BAD405"),
                EventDateTime = eventDetail.EventDate,
                UserName = eventDetail.ActionBy,
                Description = $"{eventDetail.CustomerTransferSlipId}"
            };

            eventInfoService.AddEventInfo(eventInfo);

            return Task.CompletedTask;
            
        }
    }
}
