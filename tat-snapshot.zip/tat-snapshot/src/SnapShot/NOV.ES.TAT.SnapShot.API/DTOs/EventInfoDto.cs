﻿using NOV.ES.Framework.Core.DTOs;

namespace NOV.ES.TAT.SnapShot.API.DTOs
{
    public class EventInfoDto : BaseModel<Guid>
    {

        public Guid? ItemId { get; set; }
        public Guid EventMasterId { get; set; }
        public DateTime EventDateTime { get; set; }
        public string UserName { get; set; }
        public string Description { get; set; }
        public int? Key { get; set; }

    }
}
