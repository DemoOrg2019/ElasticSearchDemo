﻿using NOV.ES.Framework.Core.DTOs;

namespace NOV.ES.TAT.SnapShot.API.DTOs
{
    public class EventMasterDto: BaseModel<Guid>
    {
        public string EventName { get; set; }
        public string EventTypeCode { get; set; }
    }
}
