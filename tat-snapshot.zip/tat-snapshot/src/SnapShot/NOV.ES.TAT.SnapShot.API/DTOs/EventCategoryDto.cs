﻿using NOV.ES.Framework.Core.DTOs;

namespace NOV.ES.TAT.SnapShot.API.DTOs
{
    public class EventCategoryDto : BaseModel<Guid>
    {
		public string Code { get; set; }
		public string Name { get; set; }

	}
}
