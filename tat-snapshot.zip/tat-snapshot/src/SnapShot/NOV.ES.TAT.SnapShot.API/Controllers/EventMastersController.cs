﻿using Microsoft.AspNetCore.Mvc;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.API.Application.Queries;
using NOV.ES.TAT.SnapShot.API.DTOs;
using NOV.ES.TAT.Common.Exception;
using System.Net;
using Microsoft.AspNetCore.Authorization;

namespace NOV.ES.TAT.SnapShot.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EventMastersController : ControllerBase
    {
        private readonly IQueryBus queryBus;
        public EventMastersController(
            IQueryBus queryBus)
        {
            this.queryBus = queryBus;
        }

        /// <summary>
        /// This method returns service name.
        /// </summary>
        /// <returns>ServiceName</returns>
        [HttpGet]
        [Route("ServiceName")]
        public IActionResult ServiceName()
        {
            return Ok("EventMasters SnapShot Service.");
        }

        /// <summary>
        /// This method returns EventMaster as per id.
        /// </summary>
        /// <param name="id">Guid</param>
        /// <returns>EventMaster as per id.</returns>
        [HttpGet]
        [Route("{id:Guid}")]
        [ProducesResponseType(typeof(EventMasterDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<EventMasterDto>> GetEventMasterById([FromRoute] Guid id)
        {
            GetEventMasterByIdQuery getEventMasterByIdQuery = new GetEventMasterByIdQuery(id);
            var result = await queryBus.Send<GetEventMasterByIdQuery, EventMasterDto>(getEventMasterByIdQuery);
            if (result == null)
                return NotFound($"EventMaster with id:{id} not found");

            return Ok(result);
        }

        /// <summary>
        /// This method returns all EventMaster
        /// </summary>
        /// <param name="pagingParameters">Paging</param>
        /// <returns>list of EventMaster</returns>
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<EventMasterDto>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IAsyncEnumerable<EventMasterDto>>> GetEventMasters([FromQuery] Paging pagingParameters)
        {
            GetPaginationEventMastersQuery getPaginationEventMasterQuery
                = new(HttpContext.Request.Query.Count == 0 ? null : pagingParameters);

            PagedResult<EventMasterDto> result = await queryBus.Send<GetPaginationEventMastersQuery
                , PagedResult<EventMasterDto>>(getPaginationEventMasterQuery);

            if (result == null || !result.Any())
            {
                List<EventMasterDto> emptyEventMasterDtos = new();
                result = new PagedResult<EventMasterDto>(emptyEventMasterDtos, emptyEventMasterDtos.Count, null);
            }
            return Ok(result.Items);
        }
    }
}
