﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Common.Exception;
using NOV.ES.TAT.SnapShot.API.Application.Queries;
using NOV.ES.TAT.SnapShot.API.DTOs;
using System.Net;

namespace NOV.ES.TAT.SnapShot.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EventCategoriesController : ControllerBase
    {
        private readonly IQueryBus queryBus;
        private readonly ICommandBus commandBus;

        public EventCategoriesController(
            ICommandBus commandBus,
            IQueryBus queryBus)
        {
            this.commandBus = commandBus;
            this.queryBus = queryBus;
        }

        /// <summary>
        /// This method returns service name.
        /// </summary>
        /// <returns>ServiceName</returns>
        [HttpGet]
        [Route("ServiceName")]
        public IActionResult ServiceName()
        {
            return Ok("EventCategory snapShot Service.");
        }

        /// <summary>
        /// This method returns all EventCategory
        /// </summary>
        /// <param name="pagingParameters">Paging</param>
        /// <returns>list of EventCategory</returns>
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<EventCategoryDto>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IAsyncEnumerable<EventCategoryDto>>> GetEventCategory([FromQuery] Paging pagingParameters)
        {
            GetPaginationEventCategoriesQuery getPaginationEventCategoriesQuery
                = new GetPaginationEventCategoriesQuery(HttpContext.Request.Query.Count == 0 ? null : pagingParameters);

            PagedResult<EventCategoryDto> result = await queryBus.Send<GetPaginationEventCategoriesQuery
                , PagedResult<EventCategoryDto>>(getPaginationEventCategoriesQuery);

            if (result == null || !result.Any())
            {
                List<EventCategoryDto> EventCategoryDtos = new List<EventCategoryDto>();
                result = new PagedResult<EventCategoryDto>(EventCategoryDtos, EventCategoryDtos.Count, null);
            }
            return Ok(result.Items);
        }

        /// <summary>
        ///  This method returns EventCategory as per id.
        /// </summary>
        /// <param name="id">Guid</param>
        /// <returns>EventCategory as per Id</returns>
        [HttpGet]
        [Route("{id:Guid}")]
        [ProducesResponseType(typeof(EventCategoryDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<EventCategoryDto>> GetEventCategoryById([FromRoute] Guid id)
        {
            GetEventCategoryByIdQuery getEventCategoryByIdQuery = new GetEventCategoryByIdQuery(id);
            var result = await queryBus.Send<GetEventCategoryByIdQuery, EventCategoryDto>(getEventCategoryByIdQuery);

            if (result == null)
                return NotFound($"EventCategory with id:{id} not found");
            return Ok(result);
        }
    }
}