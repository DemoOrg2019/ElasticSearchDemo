﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Common.Exception;
using NOV.ES.TAT.SnapShot.API.Application.Queries;
using NOV.ES.TAT.SnapShot.API.DTOs;
using System.Net;

namespace NOV.ES.TAT.SnapShot.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EventInfoController : ControllerBase
    {
        private readonly IQueryBus queryBus;
        private readonly ICommandBus commandBus;

        public EventInfoController(
            ICommandBus commandBus,
            IQueryBus queryBus)
        {
            this.commandBus = commandBus;
            this.queryBus = queryBus;
        }

        /// <summary>
        /// This method returns service name.
        /// </summary>
        /// <returns>ServiceName</returns>
        [HttpGet]
        [Route("ServiceName")]
        public IActionResult ServiceName()
        {
            return Ok("EventInfo snapShot Service.");
        }

        /// <summary>
        /// This method returns all EventInfo
        /// </summary>
        /// <param name="pagingParameters">Paging</param>
        /// <returns>list of EventInfo</returns>
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<EventInfoDto>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IAsyncEnumerable<EventInfoDto>>> GetEventInfo([FromQuery] Paging pagingParameters)
        {
            GetPaginationEventInfoQuery getPaginationEventInfoQuery
                = new GetPaginationEventInfoQuery(HttpContext.Request.Query.Count == 0 ? null : pagingParameters);

            PagedResult<EventInfoDto> result = await queryBus.Send<GetPaginationEventInfoQuery
                , PagedResult<EventInfoDto>>(getPaginationEventInfoQuery);

            if (result == null || !result.Any())
            {
                List<EventInfoDto> EventInfoDtos = new List<EventInfoDto>();
                result = new PagedResult<EventInfoDto>(EventInfoDtos, EventInfoDtos.Count, null);
            }
            return Ok(result.Items);
        }

        /// <summary>
        ///  This method returns EventInfo as per id.
        /// </summary>
        /// <param name="id">Guid</param>
        /// <returns>EventInfo as per Id</returns>
        [HttpGet]
        [Route("{id:Guid}")]
        [ProducesResponseType(typeof(EventInfoDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<EventInfoDto>> GetEventInfoById([FromRoute] Guid id)
        {
            GetEventInfoByIdQuery getEventInfoByIdQuery = new GetEventInfoByIdQuery(id);
            var result = await queryBus.Send<GetEventInfoByIdQuery, EventInfoDto>(getEventInfoByIdQuery);

            if (result == null)
                return NotFound($"EventInfo with id:{id} not found");
            return Ok(result);
        }         
    }
}