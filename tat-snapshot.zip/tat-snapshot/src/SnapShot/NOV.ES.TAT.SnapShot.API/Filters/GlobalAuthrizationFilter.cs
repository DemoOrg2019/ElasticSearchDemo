﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace NOV.ES.TAT.SnapShot.API.Filters
{
    public class GlobalAuthorizationFilter : IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var viewRequest = context.HttpContext.Request.Method.Equals(HttpMethod.Get.Method);
            if (viewRequest)
                return;

            ///Check roles and permissions in Redis cache
            /// If roles and permissions not available in Redis cache , call UPM service and add it into redis cache
            GetRolesAndPermissions();

            ///authorization
            bool addRequest = context.HttpContext.Request.Method.Equals(HttpMethod.Post.Method);
            if (addRequest)
            {
                //Check proper roles, permissions and feature 
                return;
            }

            bool editRequest = context.HttpContext.Request.Method.Equals(HttpMethod.Put.Method);

            if (editRequest)
            {
                //Check proper roles, permissions and feature 
                return;
            }

            bool deleteRequest = context.HttpContext.Request.Method.Equals(HttpMethod.Delete.Method);

            if (deleteRequest)
            {
                //Check proper roles, permissions and feature
                return;
            }
            context.Result = new JsonResult(new { message = "Unauthorized" }) { StatusCode = StatusCodes.Status401Unauthorized };
        }

        private static void GetRolesAndPermissions()
        {
            ///var url = configuration["UPM_gRpc_URL"]?? string.Empty;
            ///var accessToken = httpContextAccessor.HttpContext.Items["access_token"];

            /// get roles and permissions from UPM service 
            ///Input AppId and AppTenantId-- pass it in header
            ///output Roles and permissions 
            /// add roles and permissions to the Redis cache
        }
    }
}
