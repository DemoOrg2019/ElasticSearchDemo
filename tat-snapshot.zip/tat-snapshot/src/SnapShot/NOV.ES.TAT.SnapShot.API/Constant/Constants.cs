﻿namespace NOV.ES.TAT.SnapShot.API
{
    public static class Constants
    {
        #region ValidatorMessages
        public const string EMPTY_MESSAGE = "{0} cannot be empty.";
        #endregion
    }
}
