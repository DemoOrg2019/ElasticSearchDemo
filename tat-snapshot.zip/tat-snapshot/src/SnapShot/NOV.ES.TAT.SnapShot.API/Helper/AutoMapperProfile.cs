﻿using AutoMapper;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.API.DTOs;
using NOV.ES.TAT.SnapShot.Domain;

namespace NOV.ES.TAT.SnapShot.API.Helper
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<EventMaster, EventMasterDto>();
            CreateMap<EventMasterDto, EventMaster>();
            CreateMap<PagedResult<EventMaster>, PagedResult<EventMasterDto>>();
            CreateMap<EventInfo, EventInfoDto>();
            CreateMap<EventInfoDto, EventInfo>();
            CreateMap<PagedResult<EventInfo>, PagedResult<EventInfoDto>>();
            CreateMap<EventCategory, EventCategoryDto>();
            CreateMap<EventCategoryDto, EventCategory>();
            CreateMap<PagedResult<EventCategory>, PagedResult<EventCategoryDto>>();
        }
    }
}
