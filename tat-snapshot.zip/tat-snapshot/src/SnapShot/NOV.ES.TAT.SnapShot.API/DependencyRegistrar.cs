﻿using FluentValidation;
using MediatR;
using IdentityModel.AspNetCore.OAuth2Introspection;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using NOV.ES.Framework.Core.CQRS.Behaviors;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Data;
using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.TAT.SnapShot.API.Controllers;
using NOV.ES.TAT.SnapShot.API.Filters;
using NOV.ES.TAT.SnapShot.Domain;
using NOV.ES.TAT.SnapShot.DomainService;
using NOV.ES.TAT.SnapShot.Infrastructure;
using Polly;
using Polly.Extensions.Http;
using System.IdentityModel.Tokens.Jwt;
using System.Reflection;
using EventInfo = NOV.ES.TAT.SnapShot.Domain.EventInfo;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq;
using NOV.ES.TAT.SnapShot.API.Application.IntegrationEvents;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents.Subscription;

namespace NOV.ES.TAT.SnapShot.API
{
    public static class DependencyRegistrar
    {
        public static IServiceCollection AddCustomMvc(this IServiceCollection services)
        {
            services.AddControllers(
                options =>
                {
                    options.Filters.Add(typeof(HttpGlobalExceptionFilter));
                    options.Filters.Add(typeof(GlobalAuthorizationFilter));
                }
            ).AddNewtonsoftJson(
                joptions =>
                {
                    joptions.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                    joptions.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                    joptions.SerializerSettings.Converters.Add(new StringEnumConverter());
                }
            );
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                    .SetIsOriginAllowed((host) => true)
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });
            return services;
        }
        public static IServiceCollection AddHealthChecks(this IServiceCollection services, IConfiguration configuration)
        {
            var hcBuilder = services.AddHealthChecks();

            hcBuilder.AddCheck("self", () => HealthCheckResult.Healthy());

            return services;
        }
        public static IServiceCollection AddCustomSwagger(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "TAT Snapshot REST API",
                    Version = "v1",
                    Description = "The Snapshot Service REST API"
                });
                options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 12345abcdef\"",
                });
                options.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                          new OpenApiSecurityScheme()
                            {
                                Reference = new OpenApiReference
                                {
                                    Type = ReferenceType.SecurityScheme,
                                    Id = "Bearer"
                                }
                            },
                            new string[] {} 
                    }
                });//NOSONAR
            });

            return services;
        }
        public static IServiceCollection AddCustomAuthentication(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddAuthentication(OAuth2IntrospectionDefaults.AuthenticationScheme)
            .AddOAuth2Introspection(options =>
            {
                options.Authority = configuration["Authority"];
                options.ClientId = configuration["ClientId"];

                options.Events = new OAuth2IntrospectionEvents()
                {
                    OnTokenValidated = context =>
                    {
                        var jwtSecurityToken = new JwtSecurityTokenHandler().ReadToken(context.SecurityToken);
                        context.HttpContext.Items["user_email_id"] = ((JwtSecurityToken)jwtSecurityToken)
                        .Claims.FirstOrDefault(c => c.Type == "sub").Value;
                        context.HttpContext.Items["access_token"] = (JwtSecurityToken)jwtSecurityToken;
                        return Task.CompletedTask;
                    }
                };
            });
            return services;
        }
        public static IServiceCollection AddCustomAuthorization(this IServiceCollection services)
        {
            services.AddAuthorization(options =>
            {
                options.AddPolicy("Get", poblicBuilder => poblicBuilder
                     .RequireAuthenticatedUser()
                     .AddAuthenticationSchemes("client1"));
                options.AddPolicy("Update", poblicBuilder => poblicBuilder
                     .RequireAuthenticatedUser()
                     .RequireClaim("Permission", "canEdit")
                     .RequireRole("update")
                     .RequireRole("SuperUser")
                     .AddAuthenticationSchemes("client1"));
                options.AddPolicy("Create", poblicBuilder => poblicBuilder
                     .RequireAuthenticatedUser()
                     .RequireClaim("Permission", "canAdd")
                     .RequireRole("create")
                     .RequireRole("SuperUser")
                     .AddAuthenticationSchemes("client1"));
                options.AddPolicy("Delete", poblicBuilder => poblicBuilder
                     .RequireAuthenticatedUser()
                     .RequireClaim("Permission", "canDelete")
                     .RequireRole("delete")
                     .RequireRole("SuperUser")
                     .AddAuthenticationSchemes("client1"));

            });
            return services;
        }
        public static IServiceCollection AddCustomDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<SnapShotDBContext>(options =>
            {
                options.UseSqlServer(configuration["SnapShotDBConnString"],
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
                        sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                    });
            },
            ServiceLifetime.Scoped
            );

            return services;
        }    
        public static IServiceCollection AddDomainCoreDependecy(this IServiceCollection services)
        {
            services.AddScoped<ICommandBus, CommandBus>();
            services.AddScoped<IQueryBus, QueryBus>();
            services.AddScoped<BaseContext, SnapShotDBContext>();
            services.AddScoped<IRequestManager, RequestManager>();
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(LoggingBehavior<,>));
            
            services.AddScoped<IEventInfoQueryRepository, EventInfoQueryRepository>();
            services.AddScoped<IEventInfoCommandRepository, EventInfoCommandRepository>();
            services.AddScoped<IEventInfoService, EventInfoService>();

            services.AddScoped<IReadRepository<EventMaster>, GenericReadRepository<EventMaster>>();
            services.AddScoped<IEventMasterService, EventMasterService>();
            services.AddScoped<IReadRepository<EventCategory>, GenericReadRepository<EventCategory>>();
            services.AddScoped<IEventCategoryQueryRepository, EventCategoryQueryRepository>();
            services.AddScoped<IEventCategoryCommandRepository, EventCategoryCommandRepository>();
            services.AddScoped<IEventCategoryService, EventCategoryService>();

            services.AddScoped<CreateCustomerTransferHeaderEventInfoHandler>();

            return services;
        }
        public static IServiceCollection RegistorMediatR(this IServiceCollection services)
        {
            services.AddMediatR(typeof(Startup).GetTypeInfo().Assembly);
            services.AddValidatorsFromAssembly(typeof(Startup).Assembly);

            return services;
        }
        public static IServiceCollection AddAutoMapper(this IServiceCollection services)
        {
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            return services;
        }
        public static IServiceCollection AddPolly(this IServiceCollection services, IConfiguration configuration)
        {
            #region PollyImplementation
            ////Note: Need to install Microsoft.Extensions.Http.Polly

            services.AddHttpClient<EventInfoController>()
            .SetHandlerLifetime(TimeSpan.FromMinutes(Convert.ToInt32(configuration["HandlerLifetimeInMinutes"])))//Sample. Default lifetime is 2 minutes
            .AddPolicyHandler(GetWaitRetryPolicy(configuration))
            .AddPolicyHandler(GetCircuitBreakerPolicy(configuration));
            services.AddHttpClient<EventCategoriesController>()
            .SetHandlerLifetime(TimeSpan.FromMinutes(Convert.ToInt32(configuration["HandlerLifetimeInMinutes"])))//Sample. Default lifetime is 2 minutes
            .AddPolicyHandler(GetWaitRetryPolicy(configuration))
            .AddPolicyHandler(GetCircuitBreakerPolicy(configuration));
            #endregion
            return services;
        }
        private static IAsyncPolicy<HttpResponseMessage> GetWaitRetryPolicy(IConfiguration configuration)
        {
            return HttpPolicyExtensions
            .HandleTransientHttpError()
            .WaitAndRetryAsync(Convert.ToInt32(configuration["RetryCount"])
            , retryAttempt => TimeSpan.FromSeconds(Convert.ToInt32(configuration["RetryCount"])));
        }
        private static IAsyncPolicy<HttpResponseMessage> GetCircuitBreakerPolicy(IConfiguration configuration)
        {
            return HttpPolicyExtensions
            .HandleTransientHttpError()
            .CircuitBreakerAsync(Convert.ToInt32(configuration["RetryCountAllowedCircuitBreaking"])
            , TimeSpan.FromMinutes(Convert.ToInt32(configuration["DurationOfBreakInMinutes"])));
        }

        public static IServiceCollection AddIntegrationEventBus(this IServiceCollection services)
        {
            services.AddSingleton<IEventBusSubscriptionsManager, InMemoryEventBusSubscriptionsManager>();
            services.AddSingleton<IIntegrationEventBus, EventBusRabbitMq>();
            return services;
        }
    }
}
