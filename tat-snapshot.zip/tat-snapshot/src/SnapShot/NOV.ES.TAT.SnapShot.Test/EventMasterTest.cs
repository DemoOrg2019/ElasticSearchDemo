using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.API.Application.Queries;
using NOV.ES.TAT.SnapShot.API.Controllers;
using NOV.ES.TAT.SnapShot.API.DTOs;
using NOV.ES.TAT.SnapShot.Domain;
using NOV.ES.TAT.SnapShot.DomainService;
using NOV.ES.TAT.SnapShot.Infrastructure;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NOV.ES.TAT.SnapShot.Test
{
    [TestClass]
    public class EventMasterTest : TestBase
    {
        private readonly IEventMasterService eventMasterService;
        private Paging pagingParameters;
        private EventMastersController eventMasterController;
        private IEnumerable<EventMasterDto> eventMasterDtos = new List<EventMasterDto>();
        public EventMasterTest() : base()
        {
            eventMasterService = new EventMasterService(new GenericReadRepository<EventMaster>(SnapShotDBContext));
            pagingParameters = new Paging();
            var queryBus = new Mock<IQueryBus>().Object;
            eventMasterController = new EventMastersController(queryBus);
        }

        [TestInitialize]
        public void SetUp()
        {
            ClearAndSeedTestData();
        }

        #region Controller unit Tests

        [TestMethod]
        public void ShouldReturnsServiceNameWithOkStatus_ServiceName()
        {
            var result = eventMasterController.ServiceName();

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            Assert.AreEqual("EventMasters SnapShot Service.", ((OkObjectResult)result).Value);
        }

        [TestMethod]
        public async Task ShouldReturnsEmptyListofEventMasterWithOkStatus_GetEventMasters()
        {
            var mockQueryNus = new Mock<IQueryBus>();
            eventMasterDtos = new List<EventMasterDto>();
            mockQueryNus.Setup(x => x.Send<GetPaginationEventMastersQuery, PagedResult<EventMasterDto>>(It.IsAny<GetPaginationEventMastersQuery>()))
                .ReturnsAsync(new PagedResult<EventMasterDto>(eventMasterDtos, eventMasterDtos.Count(), pagingParameters));

            var queryBus = mockQueryNus.Object;
            eventMasterController = new EventMastersController(queryBus);

            eventMasterController.ControllerContext.HttpContext = new DefaultHttpContext();
            eventMasterController.ControllerContext.HttpContext.Request.QueryString = new QueryString();
            var result = await eventMasterController.GetEventMasters(new Paging());

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsListofEventMasterWithOkStatus_GetEventMasters()
        {
            var mockQueryNus = new Mock<IQueryBus>();

            mockQueryNus.Setup(x => x.Send<GetPaginationEventMastersQuery, PagedResult<EventMasterDto>>(It.IsAny<GetPaginationEventMastersQuery>()))
                .ReturnsAsync(new PagedResult<EventMasterDto>(eventMasterDtos, eventMasterDtos.Count(), new Paging()));

            var queryBus = mockQueryNus.Object;
            eventMasterController = new EventMastersController(queryBus);
            eventMasterController.ControllerContext.HttpContext = new DefaultHttpContext();
            eventMasterController.ControllerContext.HttpContext.Request.QueryString = new QueryString();

            var result = await eventMasterController.GetEventMasters(new Paging());

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsReturnsNotFoundResult_GetEventMasterById()
        {
            var mockQueryBus = new Mock<IQueryBus>();
            /*
            * suppressed Possible null reference return warning ,
            * test case intended to check returning null value by method
            * */
            mockQueryBus.Setup(x => x.Send<GetEventMasterByIdQuery, EventMasterDto>(It.IsAny<GetEventMasterByIdQuery>()))
#pragma warning disable CS8603 // Possible null reference return.
                .ReturnsAsync(() => null);
#pragma warning restore CS8603 // Possible null reference return.

            var queryBus = mockQueryBus.Object;
            eventMasterController = new EventMastersController(queryBus);
            var result = await eventMasterController.GetEventMasterById(Guid.Parse("94DA11D8-72C7-49BC-B191-5E7106498D63"));

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(NotFoundObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsEventMasterWithOkStatus_GetEventMasterId()
        {
            var mockQueryNus = new Mock<IQueryBus>();

            Guid id = eventMasterDtos.First().Id;
            var eventMasterDto = eventMasterDtos.FirstOrDefault(o => o.Id == id);

            Assert.IsNotNull(eventMasterDto);

            mockQueryNus.Setup(x => x.Send<GetEventMasterByIdQuery, EventMasterDto>(It.IsAny<GetEventMasterByIdQuery>()))
                .ReturnsAsync(eventMasterDto);

            var queryBus = mockQueryNus.Object;
            eventMasterController = new EventMastersController(queryBus);
            var result = await eventMasterController.GetEventMasterById(id);

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }
        
        #endregion

        #region DomainService unit tests
        [TestMethod]
        public void ShouldReturnAllEventMaster_GetEventMasters()
        {
            var eventMasters = eventMasterService.GetEventMasters(null);
            var eventMaster = eventMasters.FirstOrDefault();
            Assert.IsNotNull(eventMaster);
            Assert.AreEqual(6, eventMasters.Count());
            Assert.IsNotNull(eventMaster);
            Assert.AreEqual(Guid.Parse("6CBA21B7-7037-48C7-BEBB-088C2C6F1157"), eventMaster.Id);
            Assert.AreEqual("Event1", eventMaster.EventName);
            Assert.AreEqual("Code1", eventMaster.EventTypeCode);
            Assert.AreEqual(true, eventMaster.IsActive);                      
        }

        [TestMethod]
        public void ShouldReturnEventMasterForGivenId_GetEventMasterById()
        {
            var eventMaster = eventMasterService.GetEventMasterById(new Guid("1324D09C-83FC-4580-8043-7713936E15B7"));
            Assert.IsNotNull(eventMaster);
            Assert.AreEqual(Guid.Parse("1324D09C-83FC-4580-8043-7713936E15B7"), eventMaster.Id);
            Assert.AreEqual("Event4", eventMaster.EventName);
            Assert.AreEqual("Code4", eventMaster.EventTypeCode);
            Assert.AreEqual(true, eventMaster.IsActive);
        }

        #region Pagination
        /// <summary>
        ///  test Pagination with valid pagingParameters
        /// </summary>
        [TestMethod]
        public void ShouldReturnsEventMaster_GetEventMasters()
        {
            pagingParameters = new Paging()
            {
                PageIndex = 0,
                PageSize = 2,
                SortColumn = "Id"
            };

            var eventMasters = eventMasterService.GetEventMasters(pagingParameters);
            var eventMaster = eventMasters.Items.FirstOrDefault();

            Assert.IsNotNull(eventMaster);
            Assert.AreEqual(2, eventMasters.Count());
            Assert.AreEqual(6, eventMasters.TotalNumberOfItems);
            Assert.AreEqual(3, eventMasters.TotalNumberOfPages);
            Assert.IsNotNull(eventMaster);
            Assert.AreEqual(Guid.Parse("1324D09C-83FC-4580-8043-7713936E15B7"), eventMaster.Id);
            Assert.AreEqual("Event4", eventMaster.EventName);
            Assert.AreEqual("Code4", eventMaster.EventTypeCode);
            Assert.AreEqual(true, eventMaster.IsActive);
        }

        /// <summary>
        /// test Pagination with invalid SortColumn   .
        /// <returns>
        /// ArgumentException("Value does not have matching column");
        /// </returns>
        /// </summary>
        [TestMethod]
        public void ShouldThrowArgumentExceptionForGivenInvalidSortColumn_GetEventMasters()
        {
            pagingParameters = new Paging()
            {
                SortColumn = "SortColumn"
            };
            try
            {
                eventMasterService.GetEventMasters(pagingParameters);
                Assert.Fail();
            }
            catch (ArgumentException argumentException)
            {
                Assert.AreEqual("Sort column SortColumn does not exist.", argumentException.Message);
            }
        }

        #endregion

        #endregion

        [TestCleanup]
        public void TestCleanup()
        {
            Dispose();
        }

        private void ClearAndSeedTestData()
        {
            SnapShotDBContext.Database.EnsureDeleted();
            SnapShotDBContext.Database.EnsureCreated();
            string jsonFilePath = Path.Combine(".", "TestData", "EventMastersSeed.json");
            var eventMaster = DeserializeJsonToObject<EventMaster>(jsonFilePath);
            eventMasterDtos = DeserializeJsonToObject<EventMasterDto>(jsonFilePath);
            SnapShotDBContext.EventMasters.AddRange(eventMaster);     
            SnapShotDBContext.SaveChanges();                
        }
    }
}
