﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.API.Application.Queries;
using NOV.ES.TAT.SnapShot.API.Controllers;
using NOV.ES.TAT.SnapShot.API.DTOs;
using NOV.ES.TAT.SnapShot.Domain;
using NOV.ES.TAT.SnapShot.DomainService;
using NOV.ES.TAT.SnapShot.Infrastructure;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NOV.ES.TAT.SnapShot.Test
{

    [TestClass]
    public class EventInfoTest : TestBase
    {
        private readonly IEventInfoService eventInfoService;
        private Paging pagingParameters;

        private EventInfoController eventInfoController;
        private IEnumerable<EventInfoDto> eventInfoDtos = new List<EventInfoDto>();
        public EventInfoTest() : base()
        {
            eventInfoService = new EventInfoService
                (new EventInfoQueryRepository(SnapShotDBContext),
                new EventInfoCommandRepository(SnapShotDBContext)
                );
            pagingParameters = new Paging();

            ICommandBus commandBus = new Mock<ICommandBus>().Object;
            IQueryBus queryBus = new Mock<IQueryBus>().Object;

            eventInfoController = new EventInfoController(commandBus, queryBus);
        }

        [TestInitialize]
        public void SetUp()
        {
            ClearAndSeedTestData();
        }

        #region Controller unit Tests

        [TestMethod]
        public void ShouldReturnsServiceNameWithOkStatus_ServiceName()
        {
            var result = eventInfoController.ServiceName();

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            Assert.AreEqual("EventInfo snapShot Service.", ((OkObjectResult)result).Value);
        }

        [TestMethod]
        public async Task ShouldReturnsEmptyListofEventInfosWithOkStatus_GetEventInfo()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();
            eventInfoDtos = new List<EventInfoDto>();
            mockQueryBus.Setup(x => x.Send<GetPaginationEventInfoQuery, PagedResult<EventInfoDto>>(It.IsAny<GetPaginationEventInfoQuery>()))
                .ReturnsAsync(new PagedResult<EventInfoDto>(eventInfoDtos, eventInfoDtos.Count(), pagingParameters));

            IQueryBus queryBus = mockQueryBus.Object;
            ICommandBus commandBus = new Mock<ICommandBus>().Object;
            eventInfoController = new EventInfoController(commandBus, queryBus);

            eventInfoController.ControllerContext.HttpContext = new DefaultHttpContext();
            eventInfoController.ControllerContext.HttpContext.Request.QueryString = new QueryString();

            var result = await eventInfoController.GetEventInfo(new Paging());

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsListofEventInfosWithOkStatus_GetEventInfo()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();

            mockQueryBus.Setup(x => x.Send<GetPaginationEventInfoQuery, PagedResult<EventInfoDto>>
            (It.IsAny<GetPaginationEventInfoQuery>()))
                .ReturnsAsync(new PagedResult<EventInfoDto>(eventInfoDtos, eventInfoDtos.Count(), pagingParameters));

            IQueryBus queryBus = mockQueryBus.Object;
            ICommandBus commandBus = new Mock<ICommandBus>().Object;
            eventInfoController = new EventInfoController(commandBus, queryBus);

            eventInfoController.ControllerContext.HttpContext = new DefaultHttpContext();
            eventInfoController.ControllerContext.HttpContext.Request.QueryString = new QueryString();
            var result = await eventInfoController.GetEventInfo(new Paging());

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsReturnsNotFoundResult_GetEventInfoById()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();

            /*
             * suppressed Possible null reference return warning , 
             * test case intended to check returning null value by method
             * */
            mockQueryBus.Setup(x => x.Send<GetEventInfoByIdQuery, EventInfoDto>(It.IsAny<GetEventInfoByIdQuery>()))
#pragma warning disable CS8603 // Possible null reference return.  
                .ReturnsAsync(() => null);
#pragma warning restore CS8603 // Possible null reference return.

            IQueryBus queryBus = mockQueryBus.Object;
            ICommandBus commandBus = new Mock<ICommandBus>().Object;
            eventInfoController = new EventInfoController(commandBus, queryBus);
            var result = await eventInfoController.GetEventInfoById(Guid.Parse("1367c0fd-ab33-44d8-af68-08d9e572617d"));

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(NotFoundObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsEventInfoWithOkStatus_GetEventInfoById()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();

            Guid id = eventInfoDtos.First().Id;
            var eventInfoDto = eventInfoDtos.FirstOrDefault(o => o.Id == id);

            Assert.IsNotNull(eventInfoDto);
            mockQueryBus.Setup(x => x.Send<GetEventInfoByIdQuery, EventInfoDto>(It.IsAny<GetEventInfoByIdQuery>()))
                .ReturnsAsync(() => eventInfoDto);

            IQueryBus queryBus = mockQueryBus.Object;
            ICommandBus commandBus = new Mock<ICommandBus>().Object;
            eventInfoController = new EventInfoController(commandBus, queryBus);
            var result = await eventInfoController.GetEventInfoById(id);

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        #endregion

        #region DomainService unit tests
        [TestMethod]
        public void ShouldReturnAllEventInfos_GetEventInfos()
        {
            var eventInfos = eventInfoService.GetEventInfo(null);
            var eventInfo = eventInfos.FirstOrDefault(x => x.Id == new Guid("B73D0703-01EE-47B3-9704-B8049D45FFFA"));

            Assert.IsNotNull(eventInfos);
            Assert.AreEqual(2, eventInfos.Count());
            Assert.IsNotNull(eventInfo);
            Assert.AreEqual(new Guid("B73D0703-01EE-47B3-9704-B8049D45FFFA"), eventInfo.Id);
            Assert.AreEqual(new Guid("3FA85F64-5717-4562-B3FC-2C963F66AFA6"), eventInfo.ItemId);
            Assert.AreEqual(new Guid("86F124FC-8A95-481C-9B8F-8ABD988C623B"), eventInfo.EventMasterId);
            Assert.AreEqual("Sheetal", eventInfo.UserName);
            Assert.AreEqual("Developer", eventInfo.Description);
            Assert.AreEqual(2, eventInfo.Key);
        }

        [TestMethod]
        public void ShouldReturnEventInfoForGivenId_GetEventInfoById()
        {
            var eventInfo = eventInfoService.GetEventInfoById(new Guid("B73D0703-01EE-47B3-9704-B8049D45FFFA"));

            Assert.IsNotNull(eventInfo);
            Assert.AreEqual(new Guid("B73D0703-01EE-47B3-9704-B8049D45FFFA"), eventInfo.Id);
            Assert.AreEqual(new Guid("3FA85F64-5717-4562-B3FC-2C963F66AFA6"), eventInfo.ItemId);
            Assert.AreEqual(new Guid("86F124FC-8A95-481C-9B8F-8ABD988C623B"), eventInfo.EventMasterId);
            Assert.AreEqual("Sheetal", eventInfo.UserName);
            Assert.AreEqual("Developer", eventInfo.Description);
            Assert.AreEqual(2, eventInfo.Key);
        }

        #endregion

        #region Pagination
        /// <summary>
        ///  test Pagination with valid pagingParameters
        /// </summary>
        [TestMethod]
        public void ShouldReturnsEventInfos_GetEventInfos()
        {
            pagingParameters = new Paging()
            {
                PageIndex = 0,
                PageSize = 2,
                SortColumn = "Id"
            };

            var eventInfos = eventInfoService.GetEventInfo(pagingParameters);
            var eventInfo = eventInfos.Items.FirstOrDefault();

            Assert.IsNotNull(eventInfos);
            Assert.AreEqual(2, eventInfos.Count());
            Assert.IsNotNull(eventInfo);
            Assert.AreEqual(new Guid("3fefd6da-c4fb-4d55-9183-c993463b9b1c"), eventInfo.Id);
            Assert.AreEqual(new Guid("3FA85F64-5717-4562-B3FC-2C963F66AFA6"), eventInfo.ItemId);
            Assert.AreEqual(new Guid("8e4c56d7-188f-45d0-b4c7-1b90e3db995e"), eventInfo.EventMasterId);
            Assert.AreEqual("Sakshi", eventInfo.UserName);
            Assert.AreEqual("Developer", eventInfo.Description);
            Assert.AreEqual(1, eventInfo.Key);

        }

        /// <summary>
        /// test Pagination with invalid SortColumn   .
        /// <returns>
        /// ArgumentException("Sort column SortColumn does not exist.");
        /// </returns>
        /// </summary>
        [TestMethod]
        public void ShouldThrowArgumentExceptionForGivenInvalidSortColumn_GetEventInfos()
        {
            pagingParameters = new Paging()
            {
                SortColumn = "SortColumn"
            };
            try
            {
                eventInfoService.GetEventInfo(pagingParameters);
                Assert.Fail();
            }
            catch (ArgumentException argumentException)
            {
                Assert.AreEqual("Sort column SortColumn does not exist.", argumentException.Message);
            }
        }

      
        #endregion

        [TestCleanup]
        public void TestCleanup()
        {
            Dispose();
        }

        private void ClearAndSeedTestData()
        {
            SnapShotDBContext.Database.EnsureDeleted();
            SnapShotDBContext.Database.EnsureCreated();
            string jsonFilePath = Path.Combine(".", "TestData", "EventInfoSeed.json");

            IEnumerable<EventInfo> EventInfos = DeserializeJsonToObject<EventInfo>(jsonFilePath);
            eventInfoDtos = DeserializeJsonToObject<EventInfoDto>(jsonFilePath);
            SnapShotDBContext.EventInfos.AddRange(EventInfos);
            SnapShotDBContext.SaveChanges();
            foreach (var entity in SnapShotDBContext.ChangeTracker.Entries())
            {
                entity.State = EntityState.Detached;
            }
        }
    }
}