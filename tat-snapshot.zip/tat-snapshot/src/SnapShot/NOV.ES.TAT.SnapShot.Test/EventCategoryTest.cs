﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.API.Application.Queries;
using NOV.ES.TAT.SnapShot.API.Controllers;
using NOV.ES.TAT.SnapShot.API.DTOs;
using NOV.ES.TAT.SnapShot.Domain;
using NOV.ES.TAT.SnapShot.DomainService;
using NOV.ES.TAT.SnapShot.Infrastructure;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NOV.ES.TAT.SnapShot.Test
{

    [TestClass]
    public class EventCategoryTest : TestBase
    {
        private readonly IEventCategoryService eventCategoryService;
        private Paging pagingParameters;

        private EventCategoriesController eventCategoryController;
        private IEnumerable<EventCategoryDto> eventCategoryDtos = new List<EventCategoryDto>();
        public EventCategoryTest() : base()
        {
            eventCategoryService = new EventCategoryService
                (new EventCategoryQueryRepository(SnapShotDBContext)
                );
            pagingParameters = new Paging();

            ICommandBus commandBus = new Mock<ICommandBus>().Object;
            IQueryBus queryBus = new Mock<IQueryBus>().Object;

            eventCategoryController = new EventCategoriesController(commandBus, queryBus);
        }

        [TestInitialize]
        public void SetUp()
        {
            ClearAndSeedTestData();
        }

        #region Controller unit Tests

        [TestMethod]
        public void ShouldReturnsServiceNameWithOkStatus_ServiceName()
        {
            var result = eventCategoryController.ServiceName();

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            Assert.AreEqual("EventCategory snapShot Service.", ((OkObjectResult)result).Value);
        }

        [TestMethod]
        public async Task ShouldReturnsEmptyListofEventCategorysWithOkStatus_GetEventCategory()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();
            eventCategoryDtos = new List<EventCategoryDto>();
            mockQueryBus.Setup(x => x.Send<GetPaginationEventCategoriesQuery, PagedResult<EventCategoryDto>>(It.IsAny<GetPaginationEventCategoriesQuery>()))
                .ReturnsAsync(new PagedResult<EventCategoryDto>(eventCategoryDtos, eventCategoryDtos.Count(), pagingParameters));

            IQueryBus queryBus = mockQueryBus.Object;
            ICommandBus commandBus = new Mock<ICommandBus>().Object;
            eventCategoryController = new EventCategoriesController(commandBus, queryBus);

            eventCategoryController.ControllerContext.HttpContext = new DefaultHttpContext();
            eventCategoryController.ControllerContext.HttpContext.Request.QueryString = new QueryString();

            var result = await eventCategoryController.GetEventCategory(new Paging());

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsListofEventCategorysWithOkStatus_GetEventCategory()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();

            mockQueryBus.Setup(x => x.Send<GetPaginationEventCategoriesQuery, PagedResult<EventCategoryDto>>
            (It.IsAny<GetPaginationEventCategoriesQuery>()))
                .ReturnsAsync(new PagedResult<EventCategoryDto>(eventCategoryDtos, eventCategoryDtos.Count(), pagingParameters));

            IQueryBus queryBus = mockQueryBus.Object;
            ICommandBus commandBus = new Mock<ICommandBus>().Object;
            eventCategoryController = new EventCategoriesController(commandBus, queryBus);

            eventCategoryController.ControllerContext.HttpContext = new DefaultHttpContext();
            eventCategoryController.ControllerContext.HttpContext.Request.QueryString = new QueryString();
            var result = await eventCategoryController.GetEventCategory(new Paging());

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsReturnsNotFoundResult_GetEventCategoryById()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();

            /*
             * suppressed Possible null reference return warning , 
             * test case intended to check returning null value by method
             * */
            mockQueryBus.Setup(x => x.Send<GetEventCategoryByIdQuery, EventCategoryDto>(It.IsAny<GetEventCategoryByIdQuery>()))
#pragma warning disable CS8603 // Possible null reference return.  
                .ReturnsAsync(() => null);
#pragma warning restore CS8603 // Possible null reference return.

            IQueryBus queryBus = mockQueryBus.Object;
            ICommandBus commandBus = new Mock<ICommandBus>().Object;
            eventCategoryController = new EventCategoriesController(commandBus, queryBus);
            var result = await eventCategoryController.GetEventCategoryById(Guid.Parse("4FCD759F-499E-4C69-813F-99FB21F8FC40"));

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(NotFoundObjectResult));
        }

        [TestMethod]
        public async Task ShouldReturnsEventCategoryWithOkStatus_GetEventCategoryById()
        {
            Mock<IQueryBus> mockQueryBus = new Mock<IQueryBus>();

            Guid id = eventCategoryDtos.First().Id;
            var eventCategoryDto = eventCategoryDtos.FirstOrDefault(o => o.Id == id);

            Assert.IsNotNull(eventCategoryDto);
            mockQueryBus.Setup(x => x.Send<GetEventCategoryByIdQuery, EventCategoryDto>(It.IsAny<GetEventCategoryByIdQuery>()))
                .ReturnsAsync(() => eventCategoryDto);

            IQueryBus queryBus = mockQueryBus.Object;
            ICommandBus commandBus = new Mock<ICommandBus>().Object;
            eventCategoryController = new EventCategoriesController(commandBus, queryBus);
            var result = await eventCategoryController.GetEventCategoryById(id);

            Assert.IsNotNull(result.Result);
            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        #endregion

        #region DomainService unit tests
        [TestMethod]
        public void ShouldReturnAllEventCategorys_GetEventCategorys()
        {
            var eventCategorys = eventCategoryService.GetEventCategory(null);
            var eventCategory = eventCategorys.FirstOrDefault(x => x.Id == new Guid("4FCD759F-499E-4C69-813F-99FB21F8FC40"));

            Assert.IsNotNull(eventCategorys);
            Assert.AreEqual(6, eventCategorys.Count());
            Assert.IsNotNull(eventCategory);
            Assert.AreEqual(new Guid("4FCD759F-499E-4C69-813F-99FB21F8FC40"), eventCategory.Id);
            Assert.AreEqual("PKD", eventCategory.Code);
            Assert.AreEqual("Delete PkSlip", eventCategory.Name);
        }

        [TestMethod]
        public void ShouldReturnEventCategoryForGivenId_GetEventCategoryById()
        {
            var eventCategory = eventCategoryService.GetEventCategoryById(new Guid("4FCD759F-499E-4C69-813F-99FB21F8FC40"));

            Assert.IsNotNull(eventCategory);
            Assert.AreEqual(new Guid("4FCD759F-499E-4C69-813F-99FB21F8FC40"), eventCategory.Id);
            Assert.AreEqual("PKD", eventCategory.Code);
            Assert.AreEqual("Delete PkSlip", eventCategory.Name);
        }

        #endregion

        #region Pagination
        /// <summary>
        ///  test Pagination with valid pagingParameters
        /// </summary>
        [TestMethod]
        public void ShouldReturnsEventCategorys_GetEventCategorys()
        {
            pagingParameters = new Paging()
            {
                PageIndex = 0,
                PageSize = 2,
                SortColumn = "Id"
            };

            var eventCategorys = eventCategoryService.GetEventCategory(pagingParameters);
            var eventCategory = eventCategorys.Items.FirstOrDefault();

            Assert.IsNotNull(eventCategorys);
            Assert.AreEqual(2, eventCategorys.Count());
            Assert.IsNotNull(eventCategory);
            Assert.AreEqual(new Guid("1ef2cf25-5d9b-45d3-a038-e386a11a2d58"), eventCategory.Id);
            Assert.AreEqual("CUU", eventCategory.Code);
            Assert.AreEqual("Update Usage", eventCategory.Name);

        }

        /// <summary>
        /// test Pagination with invalid SortColumn   .
        /// <returns>
        /// ArgumentException("Sort column SortColumn does not exist.");
        /// </returns>
        /// </summary>
        [TestMethod]
        public void ShouldThrowArgumentExceptionForGivenInvalidSortColumn_GetEventCategorys()
        {
            pagingParameters = new Paging()
            {
                SortColumn = "SortColumn"
            };
            try
            {
                eventCategoryService.GetEventCategory(pagingParameters);
                Assert.Fail();
            }
            catch (ArgumentException argumentException)
            {
                Assert.AreEqual("Sort column SortColumn does not exist.", argumentException.Message);
            }
        }

      
        #endregion

        [TestCleanup]
        public void TestCleanup()
        {
            Dispose();
        }

        private void ClearAndSeedTestData()
        {
            SnapShotDBContext.Database.EnsureDeleted();
            SnapShotDBContext.Database.EnsureCreated();
            string jsonFilePath = Path.Combine(".", "TestData", "EventCategorySeed.json");

            IEnumerable<EventCategory> EventCategorys = DeserializeJsonToObject<EventCategory>(jsonFilePath);
            eventCategoryDtos = DeserializeJsonToObject<EventCategoryDto>(jsonFilePath);
            SnapShotDBContext.EventCategories.AddRange(EventCategorys);
            SnapShotDBContext.SaveChanges();
            foreach (var entity in SnapShotDBContext.ChangeTracker.Entries())
            {
                entity.State = EntityState.Detached;
            }
        }
    }
}