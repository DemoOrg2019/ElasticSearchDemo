﻿using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.Domain;

namespace NOV.ES.TAT.SnapShot.DomainService
{
    public interface IEventInfoService
    {
        PagedResult<EventInfo> GetEventInfo(Paging pagingParameters);
        EventInfo GetEventInfoById(Guid eventInfoId);
        bool AddEventInfo(EventInfo eventInfo);


    }
}
