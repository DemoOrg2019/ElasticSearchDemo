﻿using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.Domain;

namespace NOV.ES.TAT.SnapShot.DomainService
{
    public interface IEventCategoryService
    {
        PagedResult<EventCategory> GetEventCategory(Paging pagingParameters);
        EventCategory GetEventCategoryById(Guid eventCategoryId);
       
    }
}
