﻿using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.Domain;

namespace NOV.ES.TAT.SnapShot.DomainService
{
    public interface IEventMasterService
    {
        EventMaster GetEventMasterById(Guid id);
        PagedResult<EventMaster> GetEventMasters(Paging pagingParameters);
    }
}
