﻿using NOV.ES.Framework.Core.Data;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.Domain;
using NOV.ES.TAT.SnapShot.Infrastructure;

namespace NOV.ES.TAT.SnapShot.DomainService
{
    public class EventInfoService : IEventInfoService
    {
        private readonly IEventInfoQueryRepository eventInfoQueryRepository;
        private readonly IEventInfoCommandRepository eventInfoCommandRepository;

        public EventInfoService(IEventInfoQueryRepository eventInfoQueryRepository,
            IEventInfoCommandRepository eventInfoCommandRepository)
        {
            this.eventInfoQueryRepository = eventInfoQueryRepository;
            this.eventInfoCommandRepository = eventInfoCommandRepository;
        }

        public EventInfo GetEventInfoById(Guid eventInfoId)
        {
            var filter = PredicateBuilder.Create<EventInfo>(x => x.Id == eventInfoId && x.IsActive);
            return eventInfoQueryRepository.Get(filter, null, null).FirstOrDefault();
        }

        public PagedResult<EventInfo> GetEventInfo(Paging pagingParameters)
        {
            var filter = PredicateBuilder.Create<EventInfo>(x => x.Id != Guid.Empty && x.IsActive);
            var result = eventInfoQueryRepository.Get(filter, null, null);
            return PagingExtensions.GetPagedResult(result, pagingParameters);
        }

        public bool AddEventInfo(EventInfo eventInfo)
        {
            eventInfoCommandRepository.Create(eventInfo);
            var result = eventInfoCommandRepository.SaveChanges();
            return result >= 1 ? true : false;
        }
    }
}
