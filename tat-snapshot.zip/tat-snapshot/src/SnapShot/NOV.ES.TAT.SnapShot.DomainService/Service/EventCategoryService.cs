﻿using NOV.ES.Framework.Core.Data;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.Domain;
using NOV.ES.TAT.SnapShot.Infrastructure;

namespace NOV.ES.TAT.SnapShot.DomainService
{
    public class EventCategoryService : IEventCategoryService
    {
        private readonly IEventCategoryQueryRepository eventCategoryQueryRepository;

        public EventCategoryService(IEventCategoryQueryRepository eventCategoryQueryRepository)
        {
            this.eventCategoryQueryRepository = eventCategoryQueryRepository;
          
        }

        public EventCategory GetEventCategoryById(Guid eventCategoryId)
        {
            var filter = PredicateBuilder.Create<EventCategory>(x => x.Id == eventCategoryId && x.IsActive);
            return eventCategoryQueryRepository.Get(filter, null, null).FirstOrDefault();
        }

        public PagedResult<EventCategory> GetEventCategory(Paging pagingParameters)
        {
            var filter = PredicateBuilder.Create<EventCategory>(x => x.Id != Guid.Empty && x.IsActive);
            var result = eventCategoryQueryRepository.Get(filter, null, null);
            return PagingExtensions.GetPagedResult(result, pagingParameters);
        }
    }
}
