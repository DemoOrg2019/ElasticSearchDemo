﻿using NOV.ES.Framework.Core.Data;
using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.SnapShot.Domain;

namespace NOV.ES.TAT.SnapShot.DomainService
{
    public class EventMasterService : IEventMasterService
    {
        private readonly IReadRepository<EventMaster> eventMasterQueryRepository;
        public EventMasterService(IReadRepository<EventMaster> eventMasterQueryRepository)
        {
            this.eventMasterQueryRepository = eventMasterQueryRepository;
        }
        public EventMaster GetEventMasterById(Guid id)
        {
            var filter = PredicateBuilder.Create<EventMaster>(x => x.Id == id && x.IsActive);
            return eventMasterQueryRepository.Get(filter, null, null).FirstOrDefault();
        }
        public PagedResult<EventMaster> GetEventMasters(Paging pagingParameters)
        {
            var filter = PredicateBuilder.Create<EventMaster>(x => x.Id != Guid.Empty && x.IsActive);
            var result = eventMasterQueryRepository.Get(filter, null, null);
            return PagingExtensions.GetPagedResult(result, pagingParameters);
        }
    }
}
